//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TitleBar.rc
//
#define IDD_TITLEBAR_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDB_HELP_FOCUS                  129
#define IDB_HELP_NORMAL                 130
#define IDB_MAX_FOCUS                   131
#define IDB_MAX_NORMAL                  132
#define IDB_MIN_FOCUS                   133
#define IDB_MIN_NORMAL                  134
#define IDB_RESTORE_FOCUS               135
#define IDB_RESTORE_NORMAL              136
#define IDB_EXIT_FOCUS                  137
#define IDB_EXIT_NORMAL                 138

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
