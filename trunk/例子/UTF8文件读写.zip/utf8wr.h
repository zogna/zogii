#ifndef UTF8WR_H
#define UTF8WR_H

#include <stdio.h>
#include <malloc.h>
#include <tchar.h>
#include <windows.h>

size_t utf8_encode(const TCHAR *lpszBuffer,TCHAR *lpszContext);
size_t utf8_decode(const TCHAR *lpszBuffer,TCHAR *lpszContext);

size_t utf8_write(const char *lpszFile,const TCHAR *lpszBuffer);
size_t utf8_read(const char *lpszFile,TCHAR *lpszBuffer);

#endif