// XSuperTooltipTestDlg.h : header file
//

#ifndef XSUPERTOOLTIPTESTDLG_H
#define XSUPERTOOLTIPTESTDLG_H

#include "CheckFrm.h"
#include "xskinbutton.h"
#include "XSuperTooltip.h"
#include "XColourPicker.h"
#include "picture.h"

struct COLOR_SCHEME
{
	TCHAR *		lpszName;
	COLORREF	rgbStart;
	COLORREF	rgbMiddle;
	COLORREF	rgbEnd;
	COLORREF	rgbText;
};

/////////////////////////////////////////////////////////////////////////////
// CXSuperTooltipTestDlg dialog

class CXSuperTooltipTestDlg : public CDialog
{
// Construction
public:
	CXSuperTooltipTestDlg(CWnd* pParent = NULL);	// standard constructor
	~CXSuperTooltipTestDlg();

// Dialog Data
	//{{AFX_DATA(CXSuperTooltipTestDlg)
	enum { IDD = IDD_XSUPERTOOLTIPTEST_DIALOG };
	CComboBox		m_comboColor;
	CButton			m_checkDisablePreview;
	CButton			m_checkAllowDisabled;
	CButton			m_checkBodyImage;
	CButton			m_checkHeaderLine;
	CButton			m_checkFooterLine;
	CButton			m_checkFooter;
	CButton			m_checkHeader;
	CxSkinButton	m_Preview;
	int				m_nPredefined;
	int				m_nSize;
	int				m_nSizeX;
	int				m_nStyle;
	CXColourPicker	m_ctlStart;
	CXColourPicker	m_ctlMiddle;
	CXColourPicker	m_ctlEnd;
	CString			m_strHeader;
	CString			m_strFooter;
	CString			m_strBody;
	//}}AFX_DATA
	CXSuperTooltip	m_tooltip;
	CPicture		m_Picture;
	CCheckFrame		m_HeaderFrame;
	CCheckFrame		m_FooterFrame;
	UINT			m_nFooterImage;
	UINT			m_nBodyImage;

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXSuperTooltipTestDlg)
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON	m_hIcon;
	CFont	m_font;
	CString	m_strHtml;
	CString	m_strSavedHeader;
	CString	m_strSavedBody;
	CString	m_strSavedFooter;
	BOOL	m_bSavedCheckHeader;
	BOOL	m_bSavedCheckHeaderLine;
	BOOL	m_bSavedCheckBodyImage;
	BOOL	m_bSavedCheckFooter;
	BOOL	m_bSavedCheckFooterLine;

	COLORREF m_rgbStart, m_rgbMiddle, m_rgbEnd, m_rgbText;
	static COLOR_SCHEME m_ColorSchemes[];
	void SetBalloonTooltip();
	void Generate();

	// Generated message map functions
	//{{AFX_MSG(CXSuperTooltipTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnHeaderCheck();
	afx_msg void OnFooterCheck();
	afx_msg void OnColorCustom();
	afx_msg void OnColorPredefined();
	afx_msg void OnGenerate();
	afx_msg void OnCopyCode();
	afx_msg void OnSizeDefault();
	afx_msg void OnSizeCustom();
	afx_msg void OnSelchangeColor();
	afx_msg void OnChange();
	afx_msg void OnDisablePreview();
	afx_msg void OnCopyHtml();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	afx_msg LRESULT OnVirtualKey(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnHyperlinkClicked(WPARAM wParam, LPARAM lParam);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif //XSUPERTOOLTIPTESTDLG_H
