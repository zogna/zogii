//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by XSuperTooltipTest.rc
//
#define IDR_MANIFEST                    1
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_XSUPERTOOLTIPTEST_DIALOG    102
#define IDS_MAILTO                      103
#define IDR_MAINFRAME                   128
#define IDI_HELP                        130
#define IDB_HELP                        131
#define IDB_MOUSEOVER                   132
#define IDB_NORMAL                      133
#define IDB_FONT                        134
#define IDB_FONT2                       135
#define IDB_DISABLED                    136
#define IDC_ABOUT_EMAIL                 1000
#define IDC_COLOR                       1001
#define IDC_HEADER_FRAME                1002
#define IDC_HEADER_CHECK                1003
#define IDC_HEADER_TEXT                 1004
#define IDC_COLOR_PREDEFINED            1005
#define IDC_COLOR_CUSTOM                1006
#define IDC_COLOR_START                 1007
#define IDC_COLOR_STATIC1               1008
#define IDC_COLOR_MIDDLE                1009
#define IDC_COLOR_STATIC2               1010
#define IDC_COLOR_END                   1011
#define IDC_COLOR_STATIC3               1012
#define IDC_BODY_TEXT                   1013
#define IDC_BODY_PICTURE                1014
#define IDC_FOOTER_FRAME                1015
#define IDC_FOOTER_CHECK                1016
#define IDC_FOOTER_PICTURE              1017
#define IDC_FOOTER_TEXT                 1018
#define IDC_SIZE_DEFAULT                1019
#define IDC_SIZE_CUSTOM                 1020
#define IDC_SIZE_X_EDIT                 1021
#define IDC_SIZE_X_SPIN                 1022
#define IDC_PREVIEW                     1023
#define IDC_SAVE                        1024
#define IDC_GENERATE                    1025
#define IDC_COPY_CODE                   1026
#define IDC_HEADER_LINE                 1027
#define IDC_FOOTER_LINE                 1028
#define IDC_BODY_IMAGE_CHECK            1029
#define IDC_DISABLE_PREVIEW             1030
#define IDC_ALLOW_DISABLED              1031
#define IDC_COPY_HTML                   1032
#define IDC_STYLE_SUPER                 1033
#define IDC_STYLE_NORMAL                1034
#define IDC_STYLE_NONE                  1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
