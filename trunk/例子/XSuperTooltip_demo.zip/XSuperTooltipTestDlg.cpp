// XSuperTooltipTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "XSuperTooltipTest.h"
#include "XSuperTooltipTestDlg.h"
#include "about.h"
#include "Clipboard.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define UNM_HYPERLINK_CLICKED	(WM_APP + 0x100)

COLOR_SCHEME CXSuperTooltipTestDlg::m_ColorSchemes[] =
{
	_T("Beige"),             RGB(255,255,255), RGB(242,242,223), RGB(198,195,160), RGB(0,0,0),
	_T("Blue"),              RGB(255,255,255), RGB(202,220,246), RGB(150,180,222), RGB(0,0,0),
	_T("Blue 2"),            RGB(255,255,255), RGB(228,236,248), RGB(198,214,235), RGB(0,0,0),
	_T("Blue 3"),            RGB(255,255,255), RGB(213,233,243), RGB(151,195,216), RGB(0,0,0),
	_T("Blue 4"),            RGB(255,255,255), RGB(227,235,255), RGB(102,153,255), RGB(0,0,0),
	_T("Blue Glass"),        RGB(182,226,253), RGB(137,185,232), RGB(188,244,253), RGB(0,0,0),
	_T("Blue Glass 2"),      RGB(192,236,255), RGB(147,195,242), RGB(198,254,255), RGB(0,0,0),
	_T("Blue Glass 3"),      RGB(212,255,255), RGB(167,215,255), RGB(218,255,255), RGB(0,0,0),
	_T("Blue Inverted"),     RGB(117,160,222), RGB(167,210,240), RGB(233,243,255), RGB(0,0,0),
	_T("Blue Shift"),        RGB(124,178,190), RGB(13,122,153),  RGB(0,89,116),    RGB(255,255,255),
	_T("CodeProject"),       RGB(255,250,172), RGB(255,207,157), RGB(255,153,0),   RGB(0,0,0),
	_T("Dark Gray"),         RGB(195,195,195), RGB(168,168,168), RGB(134,134,134), RGB(255,255,255),
	_T("Deep Purple"),       RGB(131,128,164), RGB(112,110,143), RGB(90,88,117),   RGB(255,255,255),
	_T("Electric Blue"),     RGB(224,233,255), RGB(135,146,251), RGB(99,109,233),  RGB(0,0,0),
	_T("Firefox"),           RGB(255,254,207), RGB(254,248,125), RGB(225,119,24),  RGB(0,0,0),
	_T("Gold"),              RGB(255,202,0),   RGB(255,202,0),   RGB(255,202,0),   RGB(0,0,0),
	_T("Gold Shift"),        RGB(178,170,107), RGB(202,180,32),  RGB(162,139,1),   RGB(255,255,255),
	_T("Gray"),              RGB(255,255,255), RGB(228,228,228), RGB(194,194,194), RGB(0,0,0),
	_T("Green"),             RGB(234,241,223), RGB(211,224,180), RGB(182,200,150), RGB(0,0,0),
	_T("Green Shift"),       RGB(129,184,129), RGB(13,185,15),   RGB(1,125,1),     RGB(255,255,255),
	_T("Light Green"),       RGB(174,251,171), RGB(145,221,146), RGB(90,176,89),   RGB(0,0,0),
	_T("NASA Blue"),         RGB(0,91,134),    RGB(0,100,150),   RGB(0,105,160),   RGB(255,255,255),
	_T("Office 2007 Blue"),  RGB(255,255,255), RGB(242,246,251), RGB(202,218,239), RGB(76,76,76),
	_T("Orange Shift"),      RGB(179,120,80),  RGB(183,92,19),   RGB(157,73,1),    RGB(255,255,255),
	_T("Outlook Green"),     RGB(236,242,208), RGB(219,230,187), RGB(195,210,155), RGB(0,0,0),
	_T("Pale Green"),        RGB(249,255,248), RGB(206,246,209), RGB(148,225,155), RGB(0,0,0),
	_T("Pink Blush"),        RGB(255,254,255), RGB(255,231,242), RGB(255,213,233), RGB(0,0,0),
	_T("Pink Shift"),        RGB(202,135,188), RGB(186,8,158),   RGB(146,2,116),   RGB(255,255,255),
	_T("Pretty Pink"),       RGB(255,240,249), RGB(253,205,217), RGB(255,150,177), RGB(0,0,0),
	_T("Red"),               RGB(255,183,176), RGB(253,157,143), RGB(206,88,78),   RGB(0,0,0),
	_T("Red Shift"),         RGB(186,102,102), RGB(229,23,9),    RGB(182,11,1),    RGB(255,255,255),
	_T("Silver"),            RGB(255,255,255), RGB(242,242,246), RGB(212,212,224), RGB(0,0,0),
	_T("Silver 2"),          RGB(255,255,255), RGB(242,242,248), RGB(222,222,228), RGB(0,0,0),
	_T("Silver Glass"),      RGB(158,158,158), RGB(255,255,255), RGB(105,105,105), RGB(0,0,0),
	_T("Silver Inverted"),   RGB(161,160,186), RGB(199,201,213), RGB(255,255,255), RGB(0,0,0),
	_T("Silver Inverted 2"), RGB(181,180,206), RGB(219,221,233), RGB(255,255,255), RGB(0,0,0),
	_T("Soylent Green"),     RGB(134,211,131), RGB(105,181,106), RGB(50,136,49),   RGB(255,255,255),
	_T("Spring Green"),      RGB(154,231,151), RGB(125,201,126), RGB(70,156,69),   RGB(255,255,255),
	_T("Too Blue"),          RGB(255,255,255), RGB(225,235,244), RGB(188,209,226), RGB(0,0,0),
	_T("Totally Green"),     RGB(190,230,160), RGB(190,230,160), RGB(190,230,160), RGB(0,0,0),
	_T("XP Blue"),           RGB(119,185,236), RGB(81,144,223),  RGB(36,76,171),   RGB(255,255,255),
	_T("Yellow"),            RGB(255,255,220), RGB(255,231,161), RGB(254,218,108), RGB(0,0,0),
	NULL, 0, 0, 0, 0	// last entry must be NULL
};

///////////////////////////////////////////////////////////////////////////////
// CXSuperTooltipTestDlg dialog

BEGIN_MESSAGE_MAP(CXSuperTooltipTestDlg, CDialog)
	//{{AFX_MSG_MAP(CXSuperTooltipTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_HEADER_CHECK, OnHeaderCheck)
	ON_BN_CLICKED(IDC_FOOTER_CHECK, OnFooterCheck)
	ON_BN_CLICKED(IDC_COLOR_CUSTOM, OnColorCustom)
	ON_BN_CLICKED(IDC_COLOR_PREDEFINED, OnColorPredefined)
	ON_BN_CLICKED(IDC_GENERATE, OnGenerate)
	ON_BN_CLICKED(IDC_COPY_CODE, OnCopyCode)
	ON_BN_CLICKED(IDC_SIZE_DEFAULT, OnSizeDefault)
	ON_BN_CLICKED(IDC_SIZE_CUSTOM, OnSizeCustom)
	ON_BN_CLICKED(IDC_DISABLE_PREVIEW, OnDisablePreview)
	ON_BN_CLICKED(IDC_COPY_HTML, OnCopyHtml)
	ON_BN_CLICKED(IDC_BODY_IMAGE_CHECK, OnChange)
	ON_BN_CLICKED(IDC_HEADER_LINE, OnChange)
	ON_BN_CLICKED(IDC_FOOTER_LINE, OnChange)
	ON_BN_CLICKED(IDC_ALLOW_DISABLED, OnChange)
	ON_BN_CLICKED(IDC_STYLE_SUPER, OnChange)
	ON_BN_CLICKED(IDC_STYLE_NORMAL, OnChange)
	ON_BN_CLICKED(IDC_STYLE_NONE, OnChange)
	ON_CBN_SELCHANGE(IDC_COLOR, OnSelchangeColor)
	ON_EN_CHANGE(IDC_HEADER_TEXT, OnChange)
	ON_EN_CHANGE(IDC_FOOTER_TEXT, OnChange)
	ON_EN_CHANGE(IDC_BODY_TEXT, OnChange)
	//}}AFX_MSG_MAP
	ON_REGISTERED_MESSAGE(WM_PPTOOLTIP_VIRTUAL_KEY_CODE, OnVirtualKey)
	ON_MESSAGE(UNM_HYPERLINK_CLICKED, OnHyperlinkClicked)
END_MESSAGE_MAP()

CXSuperTooltipTestDlg::CXSuperTooltipTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CXSuperTooltipTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CXSuperTooltipTestDlg)
	m_nPredefined  = 0;
	m_nSize        = 0;
	m_nSizeX       = XSUPERTOOLTIP_DEFAULT_WIDTH;
	m_rgbStart     =  m_rgbMiddle = m_rgbEnd = m_rgbText = 0;
	m_nFooterImage = IDB_HELP;
	m_nStyle       = 0;
	//}}AFX_DATA_INIT

	m_strHeader	     = _T("Merge and Center");
	m_strFooter      = _T("<a msg=\"F1\">Press F1 for more help.</a>");
	m_strBody        = _T("Joins the selected cells into one larger cell and ")
					   _T("centers the contents in the new cell.\r\n")
					   _T("This is often used to create labels that span ")
					   _T("multiple columns.");

	m_strSavedHeader = m_strHeader;
	m_strSavedFooter = m_strFooter;
	m_strSavedBody   = m_strBody;

	m_bSavedCheckHeader     = TRUE;
	m_bSavedCheckHeaderLine = FALSE;
	m_bSavedCheckBodyImage  = FALSE;
	m_bSavedCheckFooter     = TRUE;
	m_bSavedCheckFooterLine = TRUE;

	m_strHtml        = _T("");

	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CXSuperTooltipTestDlg::~CXSuperTooltipTestDlg()
{
	if (m_font.GetSafeHandle())
		m_font.DeleteObject();
}

void CXSuperTooltipTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CXSuperTooltipTestDlg)
	DDX_Control(pDX,     IDC_COLOR,            m_comboColor);
	DDX_Control(pDX,     IDC_DISABLE_PREVIEW,  m_checkDisablePreview);
	DDX_Control(pDX,     IDC_ALLOW_DISABLED,   m_checkAllowDisabled);
	DDX_Control(pDX,     IDC_BODY_IMAGE_CHECK, m_checkBodyImage);
	DDX_Control(pDX,     IDC_HEADER_LINE,      m_checkHeaderLine);
	DDX_Control(pDX,     IDC_FOOTER_LINE,      m_checkFooterLine);
	DDX_Control(pDX,     IDC_FOOTER_CHECK,     m_checkFooter);
	DDX_Control(pDX,     IDC_HEADER_CHECK,     m_checkHeader);
	DDX_Control(pDX,     IDC_PREVIEW,          m_Preview);
	DDX_Control(pDX,     IDC_COLOR_START,      m_ctlStart);
	DDX_Control(pDX,     IDC_COLOR_MIDDLE,     m_ctlMiddle);
	DDX_Control(pDX,     IDC_COLOR_END,        m_ctlEnd);
	DDX_Radio(pDX,       IDC_COLOR_PREDEFINED, m_nPredefined);
	DDX_Radio(pDX,       IDC_SIZE_DEFAULT,     m_nSize);
	DDX_Radio(pDX,       IDC_STYLE_SUPER,      m_nStyle);
	DDX_Text(pDX,        IDC_SIZE_X_EDIT,      m_nSizeX);
	DDX_Text(pDX,        IDC_HEADER_TEXT,      m_strHeader);
	DDX_Text(pDX,        IDC_FOOTER_TEXT,      m_strFooter);
	DDX_Text(pDX,        IDC_BODY_TEXT,        m_strBody);
	DDX_ColorPicker(pDX, IDC_COLOR_START,      m_rgbStart);
	DDX_ColorPicker(pDX, IDC_COLOR_MIDDLE,     m_rgbMiddle);
	DDX_ColorPicker(pDX, IDC_COLOR_END,        m_rgbEnd);
	//}}AFX_DATA_MAP

	if (pDX->m_bSaveAndValidate & (m_nSize != 0))
	{
		DDV_MinMaxInt(pDX, m_nSizeX, 1, 999);
	}
}

///////////////////////////////////////////////////////////////////////////////
BOOL CXSuperTooltipTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// ------------------------------------------------------------------------

	// set up preview button
	CFont *pFont = m_Preview.GetFont();
	LOGFONT lf;
	pFont->GetLogFont(&lf);
	if (lf.lfHeight < 0)
		lf.lfHeight -= 2;
	else
		lf.lfHeight += 2;
	lf.lfWeight = FW_BOLD;
	m_font.CreateFontIndirect(&lf);
	m_Preview.SetFont(&m_font);

	m_Preview.SetSkin(IDB_NORMAL,IDB_MOUSEOVER,IDB_MOUSEOVER,IDB_DISABLED,0,0,2,1,0);

	m_comboColor.ResetContent();
	for (int i = 0; m_ColorSchemes[i].lpszName != NULL; i++)
	{
		m_comboColor.AddString(m_ColorSchemes[i].lpszName);
	}

	// set to silver used in Office 2007
	int index = m_comboColor.FindStringExact(0, _T("Office 2007 Blue"));
	if (index < 0)
		index = 0;
	m_comboColor.SetCurSel(index);
	OnSelchangeColor();

	if (m_nPredefined == 0)
		OnColorPredefined();
	else
		OnColorCustom();

	if (m_nSize == 0)
		OnSizeDefault();
	else
		OnSizeCustom();

	// set size
	CSpinButtonCtrl* pSpin = (CSpinButtonCtrl*) GetDlgItem(IDC_SIZE_X_SPIN);
	ASSERT(pSpin);
	pSpin->SetRange(1, 999);

	CEdit* pEdit = (CEdit*) GetDlgItem(IDC_SIZE_X_EDIT);
	ASSERT(pEdit);
	pEdit->LimitText(3);

	pEdit = (CEdit *) GetDlgItem(IDC_BODY_TEXT);
	pEdit->SetLimitText(30000);

	m_HeaderFrame.Set(this, IDC_HEADER_FRAME);
	m_checkHeader.SetCheck(TRUE);
	m_HeaderFrame.Enable(m_checkHeader.GetCheck());

	m_FooterFrame.Set(this, IDC_FOOTER_FRAME);
	m_checkFooter.SetCheck(TRUE);
	m_FooterFrame.Enable(m_checkFooter.GetCheck());
	m_checkFooterLine.SetCheck(TRUE);
	m_checkBodyImage.SetCheck(FALSE);
	m_checkDisablePreview.SetCheck(FALSE);
	m_checkAllowDisabled.SetCheck(FALSE);

	// set font bmp that will be displayed on dialog
	VERIFY(m_Picture.Load(_T("BMP"), IDB_FONT2));

	// Create the CXSuperTooltip object
	m_tooltip.Create(this);	

	SetBalloonTooltip();

	//-------------------------------------------------------------------------

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CXSuperTooltipTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CXSuperTooltipTestDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	if (IsIconic())
	{
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();

		// draw font.bmp 
		CWnd *pWnd = GetDlgItem(IDC_BODY_PICTURE);
		ASSERT(pWnd);
		pWnd->ShowWindow(SW_HIDE);
		CRect rect;
		pWnd->GetWindowRect(&rect);
		ScreenToClient(&rect);
		m_Picture.Draw(&dc, rect.left, rect.top, rect.Width(), rect.Height());
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CXSuperTooltipTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CXSuperTooltipTestDlg::OnHeaderCheck() 
{
	SetBalloonTooltip();
	m_HeaderFrame.Enable(m_checkHeader.GetCheck());
}

void CXSuperTooltipTestDlg::OnFooterCheck() 
{
	SetBalloonTooltip();
	m_FooterFrame.Enable(m_checkFooter.GetCheck());
}

void CXSuperTooltipTestDlg::OnColorCustom() 
{
	SetBalloonTooltip();
	GetDlgItem(IDC_COLOR)->EnableWindow(FALSE);
	GetDlgItem(IDC_COLOR_STATIC1)->EnableWindow(TRUE);
	GetDlgItem(IDC_COLOR_START)->EnableWindow(TRUE);
	GetDlgItem(IDC_COLOR_STATIC2)->EnableWindow(TRUE);
	GetDlgItem(IDC_COLOR_MIDDLE)->EnableWindow(TRUE);
	GetDlgItem(IDC_COLOR_STATIC3)->EnableWindow(TRUE);
	GetDlgItem(IDC_COLOR_END)->EnableWindow(TRUE);
}

void CXSuperTooltipTestDlg::OnColorPredefined() 
{
	SetBalloonTooltip();
	GetDlgItem(IDC_COLOR)->EnableWindow(TRUE);
	GetDlgItem(IDC_COLOR_STATIC1)->EnableWindow(FALSE);
	GetDlgItem(IDC_COLOR_START)->EnableWindow(FALSE);
	GetDlgItem(IDC_COLOR_STATIC2)->EnableWindow(FALSE);
	GetDlgItem(IDC_COLOR_MIDDLE)->EnableWindow(FALSE);
	GetDlgItem(IDC_COLOR_STATIC3)->EnableWindow(FALSE);
	GetDlgItem(IDC_COLOR_END)->EnableWindow(FALSE);
}

void CXSuperTooltipTestDlg::OnSizeDefault() 
{
	SetBalloonTooltip();
	GetDlgItem(IDC_SIZE_X_EDIT)->EnableWindow(FALSE);
	GetDlgItem(IDC_SIZE_X_SPIN)->EnableWindow(FALSE);
}

void CXSuperTooltipTestDlg::OnSizeCustom() 
{
	SetBalloonTooltip();
	GetDlgItem(IDC_SIZE_X_EDIT)->EnableWindow(TRUE);
	GetDlgItem(IDC_SIZE_X_SPIN)->EnableWindow(TRUE);
}

// generate tooltip HTML for IDC_PREVIEW
void CXSuperTooltipTestDlg::OnGenerate() 
{
	UpdateData(TRUE);

	m_tooltip.RemoveAllTools();

	Generate();
}

void CXSuperTooltipTestDlg::Generate() 
{
	SUPER_TOOLTIP_INFO sti;

	sti.bSuperTooltip   = TRUE;
	sti.nVirtualKeyCode = VK_F1;
	sti.nKeyCodeId      = 12345;			// can be anything you want
	sti.nIDTool         = IDC_PREVIEW;		// can be anything you want
	sti.nSizeX          = m_nSizeX;
	sti.pWnd            = GetDlgItem(IDC_PREVIEW);
	//sti.pWnd            = GetDlgItem(IDC_COPY_CODE);

	m_tooltip.SetIgnoreEnabledStatus(m_checkAllowDisabled.GetCheck());
	m_tooltip.SetCallbackHyperlink(this->GetSafeHwnd(), UNM_HYPERLINK_CLICKED);
	m_tooltip.EnableHyperlink(TRUE);

	if (m_checkHeader.GetCheck())
	{
		sti.strHeader   = m_strHeader; 
		sti.bLineAfterHeader = m_checkHeaderLine.GetCheck();
	}

	sti.strBody = m_strBody;

	if (m_checkBodyImage.GetCheck())
		sti.nBodyImage = IDB_FONT;

	if (m_checkFooter.GetCheck())
	{
		sti.strFooter    = m_strFooter;
		sti.nFooterImage = m_nFooterImage;
		sti.bLineBeforeFooter = m_checkFooterLine.GetCheck();
	}

	sti.rgbBegin = m_ctlStart.GetColor();
	sti.rgbMid   = m_ctlMiddle.GetColor();
	sti.rgbEnd   = m_ctlEnd.GetColor();
	sti.rgbText  = m_rgbText;

	m_tooltip.SetScreenTipScheme((CXSuperTooltip::ScreenTipScheme)m_nStyle);

	m_strHtml = m_tooltip.AddTool(&sti);
}

void CXSuperTooltipTestDlg::OnDisablePreview() 
{
	BOOL bEnable = !m_checkDisablePreview.GetCheck();
	GetDlgItem(IDC_PREVIEW)->EnableWindow(bEnable);

	if (bEnable)
	{
		m_strHeader = m_strSavedHeader;
		m_strBody   = m_strSavedBody;
		m_strFooter = m_strSavedFooter;
		GetDlgItem(IDC_HEADER_TEXT)->SetWindowText(m_strHeader);
		GetDlgItem(IDC_BODY_TEXT)->SetWindowText(m_strBody);
		GetDlgItem(IDC_FOOTER_TEXT)->SetWindowText(m_strFooter);
		m_checkHeader.SetCheck(m_bSavedCheckHeader);
		m_checkHeaderLine.SetCheck(m_bSavedCheckHeaderLine);
		m_checkBodyImage.SetCheck(m_bSavedCheckBodyImage);
		m_checkFooter.SetCheck(m_bSavedCheckFooter);
		m_checkFooterLine.SetCheck(m_bSavedCheckFooterLine);
	}
	else
	{
		GetDlgItem(IDC_HEADER_TEXT)->GetWindowText(m_strSavedHeader);
		GetDlgItem(IDC_BODY_TEXT)->GetWindowText(m_strSavedBody);
		GetDlgItem(IDC_FOOTER_TEXT)->GetWindowText(m_strSavedFooter);
		m_bSavedCheckHeader     = m_checkHeader.GetCheck();
		m_bSavedCheckHeaderLine = m_checkHeaderLine.GetCheck();
		m_bSavedCheckBodyImage  = m_checkBodyImage.GetCheck();
		m_bSavedCheckFooter     = m_checkFooter.GetCheck();
		m_bSavedCheckFooterLine = m_checkFooterLine.GetCheck();

		GetDlgItem(IDC_HEADER_TEXT)->SetWindowText(_T("Preview button"));
		GetDlgItem(IDC_BODY_TEXT)->SetWindowText(
			_T("The Preview button is currently disabled.\r\n")
			_T("The <b>Disable Preview button</b> checkbox has been checked.\r\n")
			_T("To enable this button, simply uncheck the checkbox.") );
		GetDlgItem(IDC_FOOTER_TEXT)->SetWindowText(_T("<a msg=\"F1\">Press F1 for more help.</a>"));
		m_checkHeader.SetCheck(TRUE);
		m_checkHeaderLine.SetCheck(TRUE);
		m_checkBodyImage.SetCheck(FALSE);
		m_checkFooter.SetCheck(TRUE);
		m_checkFooterLine.SetCheck(TRUE);
	}
	
	OnChange();
}

void CXSuperTooltipTestDlg::OnCopyHtml() 
{
	CString str = m_strHtml;
	if (!str.IsEmpty())
	{
		str += _T("\n");
		CClipboard::SetText(str);
	}
}

void CXSuperTooltipTestDlg::OnCopyCode() 
{
	CString strSize = _T("");
	strSize.Format(_T("%d"), m_nSizeX);

	CTime t = CTime::GetCurrentTime();
	CString str = t.Format(_T("\t// Generated by XSuperTooltipTest on %Y %B %d\n\n"));

	str += 
		_T("\tSUPER_TOOLTIP_INFO sti;\n\n")
		_T("\tsti.bSuperTooltip     = TRUE;\n")
		_T("\tsti.nVirtualKeyCode   = VK_F1;\t\t\t\t\t\t// zero if none\n")
		_T("\tsti.nKeyCodeId        = <insert key code id here>;\t// can be anything you want\n")
		_T("\tsti.nIDTool           = <IDC_XXXXX>;\t\t\t\t// can be anything you want\n")
		_T("\tsti.nSizeX            = ");
	str += strSize;
	str += _T(";\n");
	str += _T("\tsti.pWnd              = GetDlgItem(IDC_XXXXX);\n");

	if (m_checkHeader.GetCheck())
	{
		str += _T("\tsti.strHeader         = _T(\"");
		str += m_strHeader; 
		str += _T("\");\n");
		str += _T("\tsti.bLineAfterHeader  = ");
		str += m_checkHeaderLine.GetCheck() ? _T("TRUE;\n") : _T("FALSE;\n");
	}

	str += _T("\tsti.strBody           = \n");

	CString strLine = _T("");
	CString strBody = m_strBody;
	int nLen = strBody.GetLength();
	int nTotal = 0;

	for (;;)
	{
		strLine = _T("");

		int n = m_tooltip.GetNextLine(strBody, strLine);
		if (n == 0)
			break;

		str += _T("\t\t_T(\"");
		str += strLine;
		str += _T("\\n\")\n");

		nTotal += n;

		if (nTotal >= nLen)
			break;

		strBody = strBody.Mid(n);
	}

	str += _T("\t\t;\n");

	if (m_checkBodyImage.GetCheck())
	{
		str += _T("\tsti.nBodyImage        = IDB_XXXXX;\n");
	}

	if (m_checkFooter.GetCheck())
	{
		str += _T("\tsti.strFooter         = _T(\"");
		str += m_strFooter;
		str += _T("\");\n");
		str += _T("\tsti.nFooterImage      = IDB_YYYYY;\n");
		str += _T("\tsti.bLineBeforeFooter = ");
		str += m_checkFooterLine.GetCheck() ? _T("TRUE;\n") : _T("FALSE;\n");
	}

	str += _T("\tsti.rgbBegin          = ");
	str += m_ctlStart.GetColorString();
	str += _T(";\n");
	str += _T("\tsti.rgbMid            = ");
	str += m_ctlMiddle.GetColorString();
	str += _T(";\n");
	str += _T("\tsti.rgbEnd            = ");
	str += m_ctlEnd.GetColorString();
	str += _T(";\n");
	str += _T("\tsti.rgbText           = ");

	BYTE r = GetRValue(m_rgbText);
	BYTE g = GetGValue(m_rgbText);
	BYTE b = GetBValue(m_rgbText);
	CString strTextColor = _T("");
	strTextColor.Format(_T("RGB(%u, %u, %u)"), r, g, b);
	str += strTextColor;
	str += _T(";\n\n");

	str += _T("\tCString strHtml = m_tooltip.AddTool(&sti);\n");

	if (!str.IsEmpty())
	{
		str += _T("\n");
		CClipboard::SetText(str);
	}
}

BOOL CXSuperTooltipTestDlg::PreTranslateMessage(MSG* pMsg) 
{
	if (pMsg->message == WM_KEYUP)
	{
		TRACE(_T("CXSuperTooltipTestDlg::PreTranslateMessage:  WM_KEYUP\n"));
	}
	if (pMsg->message == WM_KEYDOWN)
	{
		TRACE(_T("CXSuperTooltipTestDlg::PreTranslateMessage:  WM_KEYDOWN\n"));
		if (pMsg->wParam == VK_F1)
		{
			TRACE(_T("CXSuperTooltipTestDlg::PreTranslateMessage:  VK_F1\n"));
		}
	}

	if (pMsg->message == 0x4d) 
	{
		TRACE(_T("CXSuperTooltipTestDlg::PreTranslateMessage:  MFC magic help message\n"));
	}

	// if RelayEvent returns TRUE, it means CXSuperTooltip
	// processed a virtual key code, and this message should
	// not be sent to CDialog
	if (m_tooltip.RelayEvent(pMsg))
		return TRUE;

	return CDialog::PreTranslateMessage(pMsg);
}

// receives WM_PPTOOLTIP_VIRTUAL_KEY_CODE from tooltip
LRESULT CXSuperTooltipTestDlg::OnVirtualKey(WPARAM wParam, LPARAM lParam)
{
	TRACE(_T("in CXSuperTooltipTestDlg::OnVirtualKey\n"));

	CString msg = _T("");
	CString strMagic = _T("");
	if (wParam == 0x4d)
		strMagic = _T("MFC magic help message!");

	msg.Format(_T("WM_PPTOOLTIP_VIRTUAL_KEY_CODE received from CPPToolTip:  \n\n")
			   _T("     key code ID = %d  (0x%X)  %s\n")
			   _T("     tool ID = %d  (0x%X)"), 
			   wParam, wParam, strMagic, lParam, lParam);
	AfxMessageBox(msg, MB_OK | MB_ICONINFORMATION);

	return 0;
}

// for hyperlinks
LRESULT CXSuperTooltipTestDlg::OnHyperlinkClicked(WPARAM wParam, LPARAM lParam)
{
	TRACE(_T("in CXSuperTooltipTestDlg::OnHyperlinkClicked\n"));

	if (wParam)
	{
		CString msg = _T("");
		msg.Format(_T("UNM_HYPERLINK_CLICKED received from CPPToolTip:  \n\n")
				   _T("     msg = '%s'\n")
				   _T("     tool ID = %d  (0x%X)"), 
				   (LPCTSTR)wParam, lParam, lParam);
		AfxMessageBox(msg, MB_OK | MB_ICONINFORMATION);
	}
	else
	{
		AfxMessageBox(_T("ERROR!  UNM_HYPERLINK_CLICKED received from CPPToolTip with NULL wParam"),
			MB_OK | MB_ICONSTOP);
	}

    return TRUE;
}

void CXSuperTooltipTestDlg::OnSelchangeColor() 
{
	SetBalloonTooltip();

	int index = m_comboColor.GetCurSel();
	if (index < 0)
		index = 0;

	m_rgbStart  = m_ColorSchemes[index].rgbStart;
	m_rgbMiddle = m_ColorSchemes[index].rgbMiddle;
	m_rgbEnd    = m_ColorSchemes[index].rgbEnd;
	m_rgbText   = m_ColorSchemes[index].rgbText;

	m_ctlStart.SetColor(m_rgbStart);
	m_ctlMiddle.SetColor(m_rgbMiddle);
	m_ctlEnd.SetColor(m_rgbEnd);
}

void CXSuperTooltipTestDlg::SetBalloonTooltip()
{
	m_tooltip.RemoveAllTools();
	m_tooltip.SetDefaultSizes(TRUE);

	PPTOOLTIP_INFO ti;

	int yMargin = m_tooltip.GetSize(CPPToolTip::PPTTSZ_MARGIN_CY);
	m_tooltip.SetSize(CPPToolTip::PPTTSZ_MARGIN_CY, yMargin/2);
	m_tooltip.SetBorder(RGB(105,105,107));
	m_tooltip.SetTooltipShadow(6, 5, 50);
	m_tooltip.SetNotify();
	m_tooltip.SetDelayTime(TTDT_AUTOPOP, 60000);
	m_tooltip.SetSize(CPPToolTip::PPTTSZ_WIDTH_ANCHOR, 20);
	m_tooltip.SetSize(CPPToolTip::PPTTSZ_HEIGHT_ANCHOR, 20);
	m_tooltip.SetTooltipShadow(6, 5, 50);
	ti.nDirection = PPTOOLTIP_BOTTOMEDGE_LEFT;
	m_tooltip.SetColorBk(GetSysColor(COLOR_INFOBK));
	m_tooltip.SetIgnoreEnabledStatus(TRUE);
	ti.nBehaviour = PPTOOLTIP_DISABLE_AUTOPOP |
					PPTOOLTIP_NOCLOSE_OVER |
					PPTOOLTIP_CLOSE_LEAVEWND |
					PPTOOLTIP_MULTIPLE_SHOW;
	ti.nMask = PPTOOLTIP_MASK_DIRECTION | PPTOOLTIP_MASK_BEHAVIOUR;
	ti.bSuperTooltip = FALSE;
	ti.sTooltip = _T("Click on Generate Tooltip button to see super tooltip.");

	m_tooltip.AddTool(GetDlgItem(IDC_PREVIEW), ti);
}

// catch-all for controls that have changed
void CXSuperTooltipTestDlg::OnChange() 
{
	SetBalloonTooltip();
}

