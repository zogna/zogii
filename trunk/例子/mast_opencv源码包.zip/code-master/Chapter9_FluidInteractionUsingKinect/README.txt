******************************************************************************
*   Fluid Interaction using Kinect
******************************************************************************
*   by Naureen Mahmood & Austin Hines, 5th Dec 2012.
*   http://code.google.com/p/fluidwall/
******************************************************************************
*   Ch9 of the book "Mastering OpenCV with Practical Computer Vision Projects"
*   Copyright Packt Publishing 2012.
*   http://www.packtpub.com/cool-projects-with-opencv/book
******************************************************************************

For instructions on building & setting up FluidWall, please visit the website:
    "http://code.google.com/p/fluidwall/"


Note: If you receive error messages saying "UPDATE  ALL:  ..." in your console:
    Sometimes the Kinect will not synchronize properly with the program, usually after quitting and re-launching in quick succession. If this happens, just quit, wait, and try launching again. This error is  rare. 

