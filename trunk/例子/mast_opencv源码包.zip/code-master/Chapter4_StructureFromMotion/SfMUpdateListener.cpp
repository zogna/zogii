/*
 *  SfMUpdateListener.cpp
 *  SfMToyExample
 *
 *  Created by Roy Shilkrot on 10/7/12.
 *  Copyright 2012 MIT. All rights reserved.
 *
 */

#include "SfMUpdateListener.h"

