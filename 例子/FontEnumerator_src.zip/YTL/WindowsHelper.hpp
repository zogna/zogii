﻿///////////////////////////////////////////////////////////////////////////////
//
//  WindowsHelper.hpp: Windows 관련함수를 편리하게 사용하기 위한 템플릿 라이브러리
//
//  Copyright (c) PARK Youngho. All rights reserved.
//
///////////////////////////////////////////////////////////////////////////////


#ifndef WINDOWSHELPER_HPP_6290349B_2EA6_42e2_8F33_1DD8B751E4A5
#define WINDOWSHELPER_HPP_6290349B_2EA6_42e2_8F33_1DD8B751E4A5

#include <windows.h>

#ifdef _WINDOWS_

#define WINDOWSHELPER_NAMESPACE_BEGINS	namespace WindowsHelper {
#define WINDOWSHELPER_NAMESPACE_ENDS	}

#include <tchar.h>
#include <vector>


//////////// OS Language begins /////////////////////////////////////////
//
#define GetOSLang()		PRIMARYLANGID( GetSystemDefaultLangID() )
#define GetOSSubLang()	SUBLANGID( GetSystemDefaultLangID() )


WINDOWSHELPER_NAMESPACE_BEGINS
template<int mode = -1>
struct OSLang
{
	WORD	m_Lang;

	OSLang(void)
	{
		m_Lang = (mode < 0) ? GetSystemDefaultLangID() : mode;
	}

	OSLang(HFONT& hFont, int point)
	{
		m_Lang = (mode < 0) ? GetSystemDefaultLangID() : mode;
		HDC	hDC = ::GetDC(NULL);
		int height = -::MulDiv(point, GetDeviceCaps(hDC, LOGPIXELSY), 72);
		::ReleaseDC(NULL, hDC);
		switch (PRIMARYLANGID(m_Lang))
		{
		case LANG_KOREAN:
			hFont = ::CreateFont(height, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, HANGUL_CHARSET, 
									OUT_STROKE_PRECIS, CLIP_DEFAULT_PRECIS, PROOF_QUALITY,
									VARIABLE_PITCH | FF_MODERN, _T("맑은 고딕"));
			break;
		default:
			hFont = ::CreateFont(height, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET, 
									OUT_STROKE_PRECIS, CLIP_DEFAULT_PRECIS, PROOF_QUALITY,
									VARIABLE_PITCH | FF_SWISS, _T("Calibri"));
			break;
		}
	}

	inline operator WORD ()
	{
		return PRIMARYLANGID(m_Lang);
	}

	inline char getSubLang(void)
	{
		return SUBLANGID(m_Lang);
	}
};
WINDOWSHELPER_NAMESPACE_ENDS
//
///////////// OS Language ends /////////////////////////////////////////

//////////// regHelper begins /////////////////////////////////////
//
WINDOWSHELPER_NAMESPACE_BEGINS
template<bool bCheck>
bool regWrite(HKEY hKey, LPCTSTR szSubKey, LPCTSTR szValueName,
					  const BYTE* lpData, DWORD dwType, DWORD cbData)
{
	HKEY	hSubKey;
	long	lResult = RegCreateKeyEx(hKey, szSubKey, 0, NULL, REG_OPTION_NON_VOLATILE,
										KEY_WRITE, NULL, &hSubKey, NULL);
	if (bCheck && (ERROR_SUCCESS != lResult))
		return false;

	lResult = RegSetValueEx(hSubKey, szValueName, 0, dwType, lpData, cbData);
	RegCloseKey(hSubKey);

	if (bCheck && (ERROR_SUCCESS != lResult))
		return false;
	return true;
}

template<bool bCheck>
inline bool regWrite(LPCTSTR szSubKey, LPCTSTR szValueName, LPCTSTR str)
{
	return regWrite<bCheck>(HKEY_CURRENT_USER, szSubKey, szValueName, (const BYTE *) str,
							REG_SZ, _tcslen(str) * sizeof (TCHAR));
}

template<bool bCheck>
inline bool regWriteString(HKEY hKey, LPCTSTR szSubKey, LPCTSTR szValueName, LPCTSTR str)
{
	return regWrite<bCheck>(hKey, szSubKey, szValueName, (const BYTE *) str, REG_SZ,
							_tcslen(str) * sizeof (TCHAR));
}

template<bool bCheck>
inline bool regWriteString(LPCTSTR szSubKey, LPCTSTR szValueName, LPCTSTR str)
{
	return regWrite<bCheck>(HKEY_CURRENT_USER, szSubKey, szValueName, (const BYTE *) str,
							REG_SZ, _tcslen(str) * sizeof (TCHAR));
}

template<bool bCheck>
inline bool regWriteInt(HKEY hKey, LPCTSTR szSubKey, LPCTSTR szValueName, int nVal)
{
	return regWrite<bCheck>(hKey, szSubKey, szValueName, (const BYTE *) &nVal,
							REG_DWORD, sizeof (int));
}

template<bool bCheck>
inline bool regWriteInt(LPCTSTR szSubKey, LPCTSTR szValueName, int nVal)
{
	return regWrite<bCheck>(HKEY_CURRENT_USER, szSubKey, szValueName, (const BYTE *) &nVal,
							REG_DWORD, sizeof (int));
}

template<bool bCheck>
inline bool regWriteInt64(HKEY hKey, LPCTSTR szSubKey, LPCTSTR szValueName, INT64 nVal)
{
	return regWrite<bCheck>(hKey, szSubKey, szValueName, (const BYTE *) &nVal,
							REG_QWORD, sizeof (INT64));
}

template<bool bCheck>
inline bool regWriteInt64(LPCTSTR szSubKey, LPCTSTR szValueName, INT64 nVal)
{
	return regWrite<bCheck>(HKEY_CURRENT_USER, szSubKey, szValueName, (const BYTE *) &nVal,
							REG_QWORD, sizeof (INT64));
}

template<bool bCheck>
bool regRead(HKEY hKey, LPCTSTR szSubKey, LPCTSTR szValueName, LPBYTE lpData, LPDWORD lpcbData)
{
	HKEY	hSubKey;
	long	lResult = RegOpenKeyEx(hKey, szSubKey, 0, KEY_READ, &hSubKey);

	if (bCheck && (ERROR_SUCCESS != lResult))
		return false;

	lResult = RegQueryValueEx(hSubKey, szValueName, 0, NULL, lpData, lpcbData);
	RegCloseKey(hSubKey);

	if (bCheck && (ERROR_SUCCESS != lResult))
		return false;
	return true;
}

template<bool bCheck>
inline bool regRead(LPCTSTR szSubKey, LPCTSTR szValueName, LPBYTE lpData, LPDWORD lpcbData)
{
	return regRead<bCheck>(HKEY_CURRENT_USER, szSubKey, szValueName, lpData, lpcbData);
}

template<bool bCheck>
inline bool regReadString(HKEY hKey, LPCTSTR szSubKey, LPCTSTR szValueName,
							LPCTSTR str, LPDWORD lpchSize)
{
	*lpchSize *= sizeof (TCHAR);
	bool	bSucc = regRead<bCheck>(hKey, szSubKey, szValueName, (LPBYTE) str, lpchSize);
	*lpchSize /= sizeof (TCHAR);
	return bSucc;
}

template<bool bCheck>
inline bool regReadString(LPCTSTR szSubKey, LPCTSTR szValueName, LPCTSTR str, LPDWORD lpchSize)
{
	*lpchSize *= sizeof (TCHAR);
	bool	bSucc = regRead<bCheck>(HKEY_CURRENT_USER, szSubKey, szValueName,
									(LPBYTE) str, lpchSize);
	*lpchSize /= sizeof (TCHAR);
	return bSucc;
}

template<bool bCheck>
inline bool regReadInt(HKEY hKey, LPCTSTR szSubKey, LPCTSTR szValueName, LPINT lpVal)
{
	DWORD	cbData = sizeof (int);
	return regRead<bCheck>(hKey, szSubKey, szValueName, (LPBYTE) lpVal, &cbData);
}

template<bool bCheck>
inline bool regReadInt(LPCTSTR szSubKey, LPCTSTR szValueName, LPINT lpVal)
{
	DWORD	cbData = sizeof (int);
	return regRead<bCheck>(HKEY_CURRENT_USER, szSubKey, szValueName, (LPBYTE) lpVal, &cbData);
}

template<bool bCheck>
inline bool regReadInt64(HKEY hKey, LPCTSTR szSubKey, LPCTSTR szValueName, PINT64 lpVal)
{
	DWORD	cbData = sizeof (INT64);
	return regRead<bCheck>(hKey, szSubKey, szValueName, (LPBYTE) lpVal, &cbData);
}

template<bool bCheck>
inline bool regReadInt64(LPCTSTR szSubKey, LPCTSTR szValueName, PINT64 lpVal)
{
	DWORD	cbData = sizeof (INT64);
	return regRead<bCheck>(HKEY_CURRENT_USER, szSubKey, szValueName, (LPBYTE) lpVal, &cbData);
}
WINDOWSHELPER_NAMESPACE_ENDS
//
///////// regHelper ends /////////////////////////////////////////////////

/////// Font Setting begins /////////////////////////////////////////////////////
//
WINDOWSHELPER_NAMESPACE_BEGINS
typedef std::vector<HWND>	HWNDS;

struct SetFontData
{
	HFONT	hFont;
	HWNDS*	phWndExcepts;
};

template<bool bInvalidate>
BOOL CALLBACK EnumChildProc(HWND hWnd, LPARAM lParam)
{
	HWNDS*	excepts = ((SetFontData*) lParam)->phWndExcepts;
	for (HWNDS::iterator it = excepts->begin(); it != excepts->end(); it++)
	{
		if (hWnd == *it)
		{
			excepts->erase(it);
			return TRUE;
		}
	}
	::SendMessage(hWnd, WM_SETFONT, (WPARAM) (((SetFontData*) lParam)->hFont), TRUE);
	if (bInvalidate)
	{
		//RECT	rc;
		//::GetClientRect(hWnd, &rc);
		//::InvalidateRect(hWnd, &rc, TRUE);
		::InvalidateRect(hWnd, NULL, TRUE);
	}
	return TRUE;
}

template<bool bInvalidate>
void setFont(HFONT hFont, HWND hWndParent, HWNDS& hWndExcepts)
{
	SetFontData	data;
	data.hFont = hFont;
	data.phWndExcepts = &hWndExcepts;
	::SendMessage(hWndParent, WM_SETFONT, (WPARAM) hFont, TRUE);
	::EnumChildWindows(hWndParent, &EnumChildProc<bInvalidate>, (LPARAM) &data);
}

template<bool bInvalidate>
void setFont(HFONT hFont, HWND hWndParent, HWND hWndExcept = NULL)
{
	HWNDS		hWnds;
	if (hWndExcept)
		hWnds.push_back(hWndExcept);
	setFont<bInvalidate>(hFont, hWndParent, hWnds);
}
WINDOWSHELPER_NAMESPACE_ENDS
//
///////// Font Setting ends /////////////////////////////////////////////////

/////// Debug begins ////////////////////////////////////////////////
//
#ifdef _DEBUG
#include <iostream>
#include <stlHelper.hpp>
#include <crtdbg.h>

#define MEMORY_LEAK_CHECK()				_CrtSetDbgFlag(_CRTDBG_LEAK_CHECK_DF)
#define MEMORY_LEAK_BREAK_AT(n)			_CrtSetBreakAlloc(n)
#define MEMORY_LEAK_REPORT(bWindows)	Report_Memory_Leak<bWindows>()

template<bool bWindows>
__forceinline void Report_Memory_Leak(void)
{
	bool		bLeaked = _CrtDumpMemoryLeaks();
	LPCTSTR		str = bLeaked ? _T("메모리 누수 있음   ") : _T("메모리 누수 없음  ");

	if (bWindows)
	{
		int		style = MB_OK | (bLeaked ? MB_ICONWARNING : MB_ICONINFORMATION);
		::MessageBox(NULL, str, _T("메모리 누수검사"), style);
	}
	else
	{
		std::tcout << std::endl << str << std::endl;
	}
}
#else	// _DEBUG
#define MEMORY_LEAK_CHECK()
#define MEMORY_LEAK_BREAK_AT(n)
#define MEMORY_LEAK_REPORT(bWindows)
#endif	// _DEBUG
//
////////// Debug ends ///////////////////////////////////////////

//////////////// Performance /////////////////////////////////////////
//
#ifdef _PERFORMANCE
#include <iostream>
#include <stlhelper.hpp>

#define SPEED_CHECK_DECLARE(bPair, sc)	SpeedCheck<bPair>	sc
#define SPEED_CHECK_STAMP(sc, str)		sc.stamp(str)
#define SPEED_CHECK_PRINT(sc)			sc.print()

template<bool bPair = false>
class SpeedCheck
{
	typedef std::pair<LPCTSTR, DWORD>	Check;
	typedef std::vector<Check>			CheckVec;

	CheckVec	m_time;

public:
	void stamp(LPCTSTR str)
	{
		m_time.push_back(Check(str, GetTickCount()));
	}

	void print(void)
	{
		if (bPair && (0 != (m_time.size() % 2)))
			stamp(NULL);
		tcout << _T("==================== 결과 =================") << endl;
		for (CheckVec::iterator	prev = m_time.begin(), it = m_time.begin() + 1;
				it != m_time.end(); prev = it, it++)
		{
			tcout << it->first << _T(": ") << it->second - prev->second << endl;
			if (bPair)
				it++;
		}
	}
};
#else	// _PERFORMANCE
#define SPEED_CHECK_DECLARE(bPair, sc)
#define SPEED_CHECK_STAMP(sc, str)
#define SPEED_CHECK_PRINT(sc)
#endif _PERFORMANCE
//
////////////////  Performance ends /////////////////////////////////////////
////////// XP_Style begins ///////////////////////////////////////////////
//
#if defined _M_IX86
  #pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_IA64
  #pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='ia64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_X64
  #pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#else
  #pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")
#endif
//
/////////// XP_Style ends /////////////////////////////////////////////////
#endif	// _WINDOWS_

#endif	// WINDOWSHELPER_HPP_6290349B_2EA6_42e2_8F33_1DD8B751E4A5
