///////////////////////////////////////////////////////////////////////////////
//
//  stlHelper.hpp: STL�� �����ϱ� ���� ���ø� ���̺귯��
//
//  Copyright (c) PARK Youngho. All rights reserved.
//
///////////////////////////////////////////////////////////////////////////////


//#include <string>
//#include <iostream>
//#include <memory>
//#include <algorithm>
//#include <utility>

namespace std
{
#ifdef _STRING_
#ifndef _STRING_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
#define _STRING_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
#ifdef UNICODE
	typedef		wstring		tstring;
#else
	typedef		string		tstring;
#endif	// UNICODE
#endif	// _STRING_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
#endif	// _STRING_

#ifdef _IOSTREAM_
#ifndef _IOSTREAM_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
#define _IOSTREAM_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
#ifdef UNICODE
	typedef		wistream		tistream;
	typedef		wostream		tostream;
	#define		tcin			wcin
	#define		tcout			wcout
	#define		tcerr			wcerr
	#define		tclog			wclog
#else
	typedef		istream			tistream;
	typedef		ostream			tostream;
	#define		tcin			cin
	#define		tcout			cout
	#define		tcerr			cerr
	#define		tclog			clog
#endif	// UNICODE
	#define init_tcin(x)	std::tcin.imbue(std::locale(x));
	#define	init_tcout(x)	std::tcout.imbue(std::locale(x));
	#define	init_tcerr(x)	std::tcerr.imbue(std::locale(x));
	#define	init_tclog(x)	std::tclog.imbue(std::locale(x));
	#define init_cin(x)		std::cin.imbue(std::locale(x));
	#define	init_cout(x)	std::cout.imbue(std::locale(x));
	#define	init_cerr(x)	std::cerr.imbue(std::locale(x));
	#define	init_clog(x)	std::clog.imbue(std::locale(x));
	#define init_wcin(x)	std::wcin.imbue(std::locale(x));
	#define	init_wcout(x)	std::wcout.imbue(std::locale(x));
	#define	init_wcerr(x)	std::wcerr.imbue(std::locale(x));
	#define	init_wclog(x)	std::wclog.imbue(std::locale(x));
#endif	// _IOSTREAM_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
#endif	// _IOSTREAM_

#ifdef _IOSFWD_
#ifndef _IOSFWD_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
#define _IOSFWD_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
#ifdef UNICODE
	typedef		wios			tios;
	typedef		wstreambuf		tsteambuf;
	typedef		wistream		tistream;
	typedef		wostream		tostream;
	typedef		wiostream		tiostream;
	typedef		wstringbuf		tstringbuf;
	typedef		wistringstream	tistringstream;
	typedef		wostringstream	tostringstream;
	typedef		wstringstream	tstringstream;
	typedef		wfilebuf		tfilebuf;
	typedef		wifstream		tifstream;
	typedef		wofstream		tofstream;
	typedef		wfstream		tfstream;
#else
	typedef		ios				tios;
	typedef		streambuf		tsteambuf;
	typedef		istream			tistream;
	typedef		ostream			tostream;
	typedef		iostream		tiostream;
	typedef		stringbuf		tstringbuf;
	typedef		istringstream	tistringstream;
	typedef		ostringstream	tostringstream;
	typedef		stringstream	tstringstream;
	typedef		filebuf			tfilebuf;
	typedef		ifstream		tifstream;
	typedef		ofstream		tofstream;
	typedef		fstream			tfstream;
#endif	// UNICODE
#endif	// _IOSFWD_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
#endif	// _IOSFWD_

#ifdef _MEMORY_
#ifndef _MEMORY_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
#define _MEMORY_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
template<typename _Ty>
struct auto_ptr_compare
{
	bool operator ==(const _Ty& _Right) const
	{
		return (*((_Ty*) ptr) == *_Right);
	}

	bool operator !=(const _Ty& _Right) const
	{
		return (*((_Ty*) ptr) != *_Right);
	}

	bool operator >(const _Ty& _Right) const
	{
		return (*((_Ty*) ptr) > *_Right);
	}

	bool operator >=(const _Ty& _Right) const
	{
		return (*((_Ty*) ptr) >= *_Right);
	}

	bool operator <(const _Ty& _Right) const
	{
		return (*((_Ty*) ptr) < *_Right);
	}

	bool operator <=(const _Ty& _Right) const
	{
		return (*((_Ty*) ptr) <= *_Right);
	}
};

template<typename _Ty>
class auto_deep_ptr : public auto_ptr<_Ty>, public auto_ptr_compare<_Ty>
{	// wrap an object pointer to ensure destruction
public:
	explicit auto_deep_ptr(_Ty *_Ptr = 0) _THROW0()
		: auto_ptr<_Ty>(_Ptr), auto_ptr_compare()
	{	// construct from object pointer
	}

	auto_deep_ptr(auto_deep_ptr<_Ty>& _Right) _THROW0()
		: auto_ptr<_Ty>(_Right.release()), auto_ptr_compare()
	{	// construct by assuming pointer from _Right auto_ptr
	}

	auto_deep_ptr(auto_ptr_ref<_Ty> _Right) _THROW0()
		: auto_ptr<_Ty>(_Right), auto_ptr_compare()
	{	// construct by assuming pointer from _Right auto_ptr_ref
	}

	template<typename _Other>
	operator auto_deep_ptr<_Other>() _THROW0()
	{	// convert to compatible auto_ptr
		return (auto_deep_ptr<_Other>(*this));
	}

	template<typename _Other>
	auto_deep_ptr<_Ty>& operator=(auto_deep_ptr<_Other>& _Right) _THROW0()
	{	// assign compatible _Right (assume pointer)
		reset(_Right.release());
		return (*this);
	}

	template<typename _Other>
	auto_deep_ptr(auto_deep_ptr<_Other>& _Right) _THROW0()
		: auto_ptr<_Ty>(_Right), auto_ptr_compare()
	{	// construct by assuming pointer from _Right
	}

	auto_deep_ptr<_Ty>& operator=(auto_ptr<_Ty>& _Right) _THROW0()
	{	// assign compatible _Right (assume pointer)
		reset(_Right.release());
		return (*this);
	}

	auto_deep_ptr<_Ty>& operator=(auto_ptr_ref<_Ty> _Right) _THROW0()
	{	// assign compatible _Right._Ref (assume pointer)
		_Ty *_Ptr = _Right._Ref;
		_Right._Ref = 0;	// release old
		reset(_Ptr);	// set new
		return (*this);
	}
};

// TEMPLATE CLASS auto_array_ptr
template<typename _Ty>
class auto_array_ptr
{	// wrap an object pointer to ensure destruction
public:
	typedef _Ty element_type;

	explicit auto_array_ptr(_Ty *_Ptr = 0) _THROW0()
		: _Myptr(_Ptr)
	{	// construct from object pointer
	}

	auto_array_ptr(auto_array_ptr<_Ty>& _Right) _THROW0()
		: _Myptr(_Right.release())
	{	// construct by assuming pointer from _Right auto_array_ptr
	}

	auto_array_ptr(auto_ptr_ref<_Ty> _Right) _THROW0()
	{	// construct by assuming pointer from _Right auto_ptr_ref
		_Ty *_Ptr = _Right._Ref;
		_Right._Ref = 0;	// release old
		_Myptr = _Ptr;	// reset this
	}

	template<typename _Other>
	operator auto_array_ptr<_Other>() _THROW0()
	{	// convert to compatible auto_array_ptr
		return (auto_array_ptr<_Other>(*this));
	}

	template<typename _Other>
	operator auto_ptr_ref<_Other>() _THROW0()
	{	// convert to compatible auto_ptr_ref
		_Other *_Cvtptr = _Myptr;	// test implicit conversion
		auto_ptr_ref<_Other> _Ans(_Cvtptr);
		_Myptr = 0;	// pass ownership to auto_ptr_ref
		return (_Ans);
	}

	template<typename _Other>
	auto_array_ptr<_Ty>& operator =(auto_array_ptr<_Other>& _Right) _THROW0()
	{	// assign compatible _Right (assume pointer)
		reset(_Right.release());
		return (*this);
	}

	template<typename _Other>
	auto_array_ptr(auto_array_ptr<_Other>& _Right) _THROW0()
		: _Myptr(_Right.release())
	{	// construct by assuming pointer from _Right
	}

	auto_array_ptr<_Ty>& operator =(auto_array_ptr<_Ty>& _Right) _THROW0()
	{	// assign compatible _Right (assume pointer)
		reset(_Right.release());
		return (*this);
	}

	auto_array_ptr<_Ty>& operator =(auto_ptr_ref<_Ty> _Right) _THROW0()
	{	// assign compatible _Right._Ref (assume pointer)
		_Ty *_Ptr = _Right._Ref;
		_Right._Ref = 0;	// release old
		reset(_Ptr);	// set new
		return (*this);
	}

	~auto_array_ptr()
	{	// destroy the object
		delete[] _Myptr;
	}

	_Ty& operator*() const _THROW0()
	{	// return designated value

 #if _HAS_ITERATOR_DEBUGGING
		if (_Myptr == 0)
			_DEBUG_ERROR("auto_array_ptr not dereferencable");
 #endif /* _HAS_ITERATOR_DEBUGGING */

		__analysis_assume(_Myptr);

		return (*get());
	}

	_Ty& operator [](int idx) _THROW0()
	{
		if (_Myptr == 0)
			_DEBUG_ERROR("auto_array_ptr not dereferencable");
		return (get())[idx];
	}

	_Ty *get() const _THROW0()
	{	// return wrapped pointer
		return (_Myptr);
	}

	_Ty *release() _THROW0()
	{	// return wrapped pointer and give up ownership
		_Ty *_Tmp = _Myptr;
		_Myptr = 0;
		return (_Tmp);
	}

	void reset(_Ty* _Ptr = 0)
	{	// destroy designated object and store new pointer
		if (_Ptr != _Myptr)
			delete[] _Myptr;
		_Myptr = _Ptr;
	}

protected:
	_Ty *_Myptr;	// the wrapped object pointer
};

template<typename _Ty = void>
class auto_c_ptr
{	// wrap an object pointer to ensure destruction
public:
	typedef _Ty element_type;

	explicit auto_c_ptr(_Ty *_Ptr = 0) _THROW0()
		: _Myptr(_Ptr)
	{	// construct from object pointer
	}

	auto_c_ptr(auto_c_ptr<_Ty>& _Right) _THROW0()
		: _Myptr(_Right.release())
	{	// construct by assuming pointer from _Right auto_array_ptr
	}

	auto_c_ptr(auto_ptr_ref<_Ty> _Right) _THROW0()
	{	// construct by assuming pointer from _Right auto_ptr_ref
		_Ty *_Ptr = _Right._Ref;
		_Right._Ref = 0;	// release old
		_Myptr = _Ptr;	// reset this
	}

	template<typename _Other>
	operator auto_c_ptr<_Other>() _THROW0()
	{	// convert to compatible auto_array_ptr
		return (auto_c_ptr<_Other>(*this));
	}

	template<typename _Other>
	operator auto_ptr_ref<_Other>() _THROW0()
	{	// convert to compatible auto_ptr_ref
		_Other *_Cvtptr = _Myptr;	// test implicit conversion
		auto_ptr_ref<_Other> _Ans(_Cvtptr);
		_Myptr = 0;	// pass ownership to auto_ptr_ref
		return (_Ans);
	}

	template<typename _Other>
	auto_c_ptr<_Ty>& operator=(auto_c_ptr<_Other>& _Right) _THROW0()
	{	// assign compatible _Right (assume pointer)
		reset(_Right.release());
		return (*this);
	}

	template<typename _Other>
	auto_c_ptr(auto_c_ptr<_Other>& _Right) _THROW0()
		: _Myptr(_Right.release())
	{	// construct by assuming pointer from _Right
	}

	auto_c_ptr<_Ty>& operator=(auto_c_ptr<_Ty>& _Right) _THROW0()
	{	// assign compatible _Right (assume pointer)
		reset(_Right.release());
		return (*this);
	}

	auto_c_ptr<_Ty>& operator=(auto_ptr_ref<_Ty> _Right) _THROW0()
	{	// assign compatible _Right._Ref (assume pointer)
		_Ty *_Ptr = _Right._Ref;
		_Right._Ref = 0;	// release old
		reset(_Ptr);	// set new
		return (*this);
	}

	~auto_c_ptr()
	{	// destroy the object
		free(_Myptr);
	}

	_Ty& operator*() const _THROW0()
	{	// return designated value

 #if _HAS_ITERATOR_DEBUGGING
		if (_Myptr == 0)
			_DEBUG_ERROR("auto_c_ptr not dereferencable");
 #endif /* _HAS_ITERATOR_DEBUGGING */

		__analysis_assume(_Myptr);

		return (*get());
	}

	_Ty *operator->() const _THROW0()
	{	// return pointer to class object

 #if _HAS_ITERATOR_DEBUGGING
		if (_Myptr == 0)
			_DEBUG_ERROR("auto_c_ptr not dereferencable");
 #endif /* _HAS_ITERATOR_DEBUGGING */

		return (get());
	}

	_Ty *get() const _THROW0()
	{	// return wrapped pointer
		return (_Myptr);
	}

	_Ty *release() _THROW0()
	{	// return wrapped pointer and give up ownership
		_Ty *_Tmp = _Myptr;
		_Myptr = 0;
		return (_Tmp);
	}

	void reset(_Ty* _Ptr = 0)
	{	// destroy designated object and store new pointer
		if (_Ptr != _Myptr)
			free(_Myptr);
		_Myptr = _Ptr;
	}

protected:
	_Ty *_Myptr;	// the wrapped object pointer
};

template<typename _Ty>
class auto_deep_c_ptr : public auto_c_ptr<_Ty>, public auto_ptr_compare<_Ty>
{	// wrap an object pointer to ensure destruction
public:
	explicit auto_deep_c_ptr(_Ty *_Ptr = 0) _THROW0()
		: auto_c_ptr<_Ty>(_Ptr), auto_ptr_compare()
	{	// construct from object pointer
	}

	auto_deep_c_ptr(auto_deep_c_ptr<_Ty>& _Right) _THROW0()
		: auto_c_ptr<_Ty>(_Right.release()), auto_ptr_compare()
	{	// construct by assuming pointer from _Right auto_ptr
	}

	auto_deep_c_ptr(auto_ptr_ref<_Ty> _Right) _THROW0()
		: auto_c_ptr<_Ty>(_Right), auto_ptr_compare()
	{	// construct by assuming pointer from _Right auto_ptr_ref
	}

	template<typename _Other>
	operator auto_deep_c_ptr<_Other>() _THROW0()
	{	// convert to compatible auto_ptr
		return (auto_deep_c_ptr<_Other>(*this));
	}

	template<typename _Other>
	auto_deep_c_ptr<_Ty>& operator=(auto_deep_c_ptr<_Other>& _Right) _THROW0()
	{	// assign compatible _Right (assume pointer)
		reset(_Right.release());
		return (*this);
	}

	template<typename _Other>
	auto_deep_c_ptr(auto_deep_c_ptr<_Other>& _Right) _THROW0()
		: auto_c_ptr<_Ty>(_Right), auto_ptr_compare()
	{	// construct by assuming pointer from _Right
	}

	auto_deep_c_ptr<_Ty>& operator=(auto_ptr<_Ty>& _Right) _THROW0()
	{	// assign compatible _Right (assume pointer)
		reset(_Right.release());
		return (*this);
	}

	auto_deep_c_ptr<_Ty>& operator=(auto_ptr_ref<_Ty> _Right) _THROW0()
	{	// assign compatible _Right._Ref (assume pointer)
		_Ty *_Ptr = _Right._Ref;
		_Right._Ref = 0;	// release old
		reset(_Ptr);	// set new
		return (*this);
	}
};
#endif	// _MEMORY_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
#endif	// _MEMORY_

#ifdef _ALGORITHM_
#ifndef _ALGORITHM_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
#define _ALGORITHM_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
template<typename _InIt, typename _Fn1>
inline bool foreach(_InIt _First, _InIt _Last, _Fn1 _Func)
{	// perform function for each element
	_DEBUG_RANGE(_First, _Last);
	_DEBUG_POINTER(_Func);
	_CHECKED_BASE_TYPE(_InIt) _ChkFirst(_CHECKED_BASE(_First));
	_CHECKED_BASE_TYPE(_InIt) _ChkLast(_CHECKED_BASE(_Last));
	for (_ChkFirst != _ChkLast; ++_ChkFirst)
		if (!_Func(*_ChkFirst))
			return false;
	return true;
}

template<typename _Ty>
inline bool isInRange(_Ty l, _Ty x, _Ty h)
{
	return (l <= x) && (x <= h);
}

template<typename _Ty>
inline bool isOneOf(_Ty x, _Ty a, _Ty b)
{
	return (x == a) || (x == b);
}

template<typename _Ty>
inline bool isOneOf(_Ty x, _Ty a, _Ty b, _Ty c)
{
	return (x == a) || (x == b) || (x == c);
}

template<typename _Ty>
inline bool isOneOf(_Ty x, _Ty a, _Ty b, _Ty c, _Ty d)
{
	return (x == a) || (x == b) || (x == c) || (x == d);
}

template<typename _Ty>
inline bool isOneOf(_Ty x, _Ty a, _Ty b, _Ty c, _Ty d, _Ty e)
{
	return (x == a) || (x == b) || (x == c) || (x == d) || (x == e);
}

template<typename _Ty>
inline bool isOneOf(_Ty x, _Ty a, _Ty b, _Ty c, _Ty d, _Ty e, _Ty f)
{
	return (x == a) || (x == b) || (x == c) || (x == d) || (x == e) || (x == f);
}

template<typename _Ty>
inline bool isOneOf(_Ty x, _Ty a, _Ty b, _Ty c, _Ty d, _Ty e, _Ty f, _Ty g)
{
	return (x == a) || (x == b) || (x == c) || (x == d) || (x == e) || (x == f) || (x == g);
}

template<typename _Ty>
inline bool isOneOf(_Ty x, _Ty a, _Ty b, _Ty c, _Ty d, _Ty e, _Ty f, _Ty g, _Ty h)
{
	return (x == a) || (x == b) || (x == c) || (x == d) || (x == e) || (x == f) || (x == g)
		|| (x == h);
}

template<typename _Ty>
inline bool isOneOf(_Ty x, _Ty a, _Ty b, _Ty c, _Ty d, _Ty e, _Ty f, _Ty g, _Ty h, _Ty i)
{
	return (x == a) || (x == b) || (x == c) || (x == d) || (x == e) || (x == f) || (x == g)
		|| (x == h) || (x == i);
}

template<typename _Ty>
inline bool isOneOf(_Ty x, _Ty a, _Ty b, _Ty c, _Ty d, _Ty e, _Ty f, _Ty g, _Ty h, _Ty i, _Ty j)
{
	return (x == a) || (x == b) || (x == c) || (x == d) || (x == e) || (x == f) || (x == g)
		|| (x == h) || (x == i) || (x == j);
}

#endif	// _ALGORITHM_STLHELPER_D4459FC7_15A3_4C5E_8CD8_15BF92D97BF3
#endif	//_ALGORITHM_

#ifdef _UTILITY_
#ifndef _UTILITY_3AF5ADF6_4E4A_4ba2_9088_B29760AB69F4
#define _UTILITY_3AF5ADF6_4E4A_4ba2_9088_B29760AB69F4
template<int _N, typename _Ty>
class Multiple
{
	_Ty n[_N];

public:
	Multiple(void)
	{
		memset(n, sizeof n);
	}

	Multiple(_Ty first, ...)
	{
		_Ty m = first;
		va_list marker;
		va_start(marker, first); /* Initialize variable arguments. */

		n[0] = first;
		for (int i = 1; i < _N; i++)
			n[i] = va_arg(marker, _Ty);

		va_end(marker); /* Reset variable arguments. */
	}

	bool operator == (Multiple<_N, _Ty>& right)
	{
		for (int i = 0; i < _N; i++)
		{
			if (n[i] != right.n[i])
				return false;
		}
		return true;
	}

	inline bool operator != (Multiple<_N, _Ty>& right)
	{
		return !(*this == right);
	}

	bool operator > (Multiple<_N, _Ty>& right)
	{
		for (int i = 0; i < _N; i++)
		{
			if (n[i] > right.n[i])
				return true;
			else if (n[i] < right.n[i])
				return false;
		}
		return false;
	}

	inline bool operator < (Multiple<_N, _Ty>& right)
	{
		return (*right > *this);
	}

	inline bool operator >= (Multiple<_N, _Ty>& right)
	{
		return !(*this < right);
	}

	inline bool operator <= (Multiple<_N, _Ty>& right)
	{
		return !(*this > right);
	}
};

template<typename  _Ty1, typename _Ty2, typename _Ty3>
struct triple
{	// store a triple of values
	typedef triple<_Ty1, _Ty2, _Ty3> _Myt;
	typedef _Ty1 first_type;
	typedef _Ty2 second_type;
	typedef _Ty2 third_type;

	_Ty1 first;		// the first stored value
	_Ty2 second;	// the second stored value
	_Ty2 third;		// the third stored value

	triple() : first(_Ty1()), second(_Ty2()), third(_Ty3())
	{	// construct from defaults
	}

	triple(const _Ty1& _Val1, const _Ty2& _Val2, const _Ty3& _Val3)
		: first(_Val1), second(_Val2), third(_Val3)
	{	// construct from specified values
	}

	template<typename _Other1, typename _Other2, typename _Other3>
	triple(const triple<_Other1, _Other2, _Other3>& _Right)
		: first(_Right.first), second(_Right.second), third(_Right.third)
	{	// construct from compatible triple
	}

	void swap(_Myt& _Right)
	{	// exchange contents with _Right
		if (this != &_Right)
		{	// different, worth swapping
			_STD _Swap_adl(first, _Right.first);
			_STD _Swap_adl(second, _Right.second);
			_STD _Swap_adl(third, _Right.third);
		}
	}

	bool operator == (const triple<_Ty1, _Ty2, _Ty3>& _Right)
	{	// test for triple equality
		return (this->first == _Right.first)
			&& (this->second == _Right.second)
			&& (this->third == _Right.third);
	}

	inline bool operator != (const triple<_Ty1, _Ty2, _Ty3>& _Right)
	{	// test for triple inequality
		return !(*this == _Right);
	}

	bool operator < (const triple<_Ty1, _Ty2, _Ty3>& _Right)
	{	// test if _Left < _Right for triples
		if (this->first < _Right.first)
			return true;
		if (this->first > _Right.first)
			return false;
		if (this->second < _Right.second)
			return true;
		if (this->second > _Right.second)
			return false;
		return (this->third < _Right.third);
	}

	inline bool operator > (const triple<_Ty1, _Ty2, _Ty3>& _Right)
	{	// test if _Left > _Right for triples
		return _Right < *this;
	}

	inline bool operator <= (const triple<_Ty1, _Ty2, _Ty3>& _Right)
	{	// test if _Left <= _Right for triples
		return !(*this > _Right);
	}

	inline bool operator >= (const triple<_Ty1, _Ty2, _Ty3>& _Right)
	{	// test if _Left >= _Right for triples
		return !(*this < _Right);
	}
};

template<typename _Ty1, typename _Ty2, typename _Ty3>
inline void swap(triple<_Ty1, _Ty2, _Ty3>& _Left, triple<_Ty1, _Ty2, _Ty3>& _Right)
{	// swap _Left and _Right triples
	_Left.swap(_Right);
}

template<typename _Ty1, typename _Ty2, typename _Ty3>
inline triple<_Ty1, _Ty2, _Ty3> make_triple(_Ty1 _Val1, _Ty2 _Val2, _Ty3 _Val3)
{	// return pair composed from arguments
	return (triple<_Ty1, _Ty2, _Ty3>(_Val1, _Val2, _Val3));
}

#endif	// _UTILITY_3AF5ADF6_4E4A_4ba2_9088_B29760AB69F4
#endif	//
}
