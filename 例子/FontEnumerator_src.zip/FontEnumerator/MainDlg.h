// MainDlg.h : interface of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#pragma once
#include <atlddx.h>
#include <atlcrack.h>
#include <atlmisc.h>
#include <vector>
#include <string>
#include <algorithm>
#include <stlHelper.hpp>

typedef	std::pair<LOGFONT, DWORD>	FontPair;
typedef	std::vector<FontPair>		FontVec;

class CMainDlg : public CDialogImpl<CMainDlg>, public CWinDataExchange<CMainDlg>
{
private:
	CStatic		m_wndGroupSize;
	CStatic		m_wndGroupPrecision;
	CStatic		m_wndGroupFontName;
	CStatic		m_wndGroupTilt;
	CStatic		m_wndGroupShape;

	CButton		m_wndCheckHeight;
	CStatic		m_wndStaticWidth;
	CStatic		m_wndStaticWeight;
	CEdit		m_wndEditHeight;
	CEdit		m_wndEditWidth;
	CEdit		m_wndEditWeight;

	CStatic		m_wndStaticEscapement;
	CStatic		m_wndStaticOrientation;
	CEdit		m_wndEditEscapement;
	CEdit		m_wndEditOrientation;

	CButton		m_wndCheckItalic;
	CButton		m_wndCheckUnderline;
	CButton		m_wndCheckStrikeout;

	CStatic		m_wndStaticOutPrecision;
	CStatic		m_wndStaticClipPrecision;
	CStatic		m_wndStaticQuality;
	CEdit		m_wndEditOutPrecision;
	CEdit		m_wndEditClipPrecision;
	CEdit		m_wndEditQuality;

	CStatic		m_wndStaticFaceName;
	CStatic		m_wndStaticPitchAndFamily;
	CStatic		m_wndStaticCharSet;
	CStatic		m_wndStaticFontType;
	CEdit		m_wndEditFaceName;
	CEdit		m_wndEditPitchAndFamily;
	CEdit		m_wndEditCharSet;
	CEdit		m_wndEditFontType;

	CListBox	m_wndListFonts;
	CButton		m_wndButtonExample;

	FontVec		m_FontVec;
	LPCTSTR		m_strTitle, m_strEnumFont, m_strTotal;
	LPCTSTR		m_strHeight, m_strPoint, m_strInfo, m_strCopySrc, m_strInputExample;
	std::tstring	m_strExample;
	CFont			m_Font;
	int				m_Resolution;

public:
	enum { IDD = IDD_MAINDLG };

	BEGIN_MSG_MAP(CMainDlg)
		COMMAND_HANDLER_EX(IDC_LIST1, LBN_SELCHANGE, OnList1LbnSelChange)
		COMMAND_HANDLER_EX(IDC_BUTTON60, BN_CLICKED, OnButton60BnClicked)
		COMMAND_HANDLER_EX(IDC_CHECK11, BN_CLICKED, OnCheck11BnClicked)
		MSG_WM_SYSCOMMAND(OnSysCommand)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		MSG_WM_CLOSE(OnClose)
		MSG_WM_HELP(OnHelp)
	END_MSG_MAP()

	BEGIN_DDX_MAP(CMainDlg)
		DDX_CONTROL_HANDLE(IDC_LIST1, m_wndListFonts)
		DDX_CONTROL_HANDLE(IDC_STATIC10, m_wndGroupSize)
		DDX_CONTROL_HANDLE(IDC_STATIC20, m_wndGroupTilt)
		DDX_CONTROL_HANDLE(IDC_STATIC30, m_wndGroupShape)
		DDX_CONTROL_HANDLE(IDC_STATIC40, m_wndGroupPrecision)
		DDX_CONTROL_HANDLE(IDC_STATIC50, m_wndGroupFontName)
		DDX_CONTROL_HANDLE(IDC_CHECK11, m_wndCheckHeight)
		DDX_CONTROL_HANDLE(IDC_STATIC12, m_wndStaticWidth)
		DDX_CONTROL_HANDLE(IDC_STATIC13, m_wndStaticWeight)
		DDX_CONTROL_HANDLE(IDC_STATIC21, m_wndStaticEscapement)
		DDX_CONTROL_HANDLE(IDC_STATIC22, m_wndStaticOrientation)
		DDX_CONTROL_HANDLE(IDC_CHECK31, m_wndCheckItalic)
		DDX_CONTROL_HANDLE(IDC_CHECK32, m_wndCheckUnderline)
		DDX_CONTROL_HANDLE(IDC_CHECK33, m_wndCheckStrikeout)
		DDX_CONTROL_HANDLE(IDC_STATIC41, m_wndStaticOutPrecision)
		DDX_CONTROL_HANDLE(IDC_STATIC42, m_wndStaticClipPrecision)
		DDX_CONTROL_HANDLE(IDC_STATIC43, m_wndStaticQuality)
		DDX_CONTROL_HANDLE(IDC_STATIC51, m_wndStaticFaceName)
		DDX_CONTROL_HANDLE(IDC_STATIC52, m_wndStaticPitchAndFamily)
		DDX_CONTROL_HANDLE(IDC_STATIC53, m_wndStaticCharSet)
		DDX_CONTROL_HANDLE(IDC_STATIC54, m_wndStaticFontType)
		DDX_CONTROL_HANDLE(IDC_EDIT11, m_wndEditHeight)
		DDX_CONTROL_HANDLE(IDC_EDIT12, m_wndEditWidth)
		DDX_CONTROL_HANDLE(IDC_EDIT13, m_wndEditWeight)
		DDX_CONTROL_HANDLE(IDC_EDIT21, m_wndEditEscapement)
		DDX_CONTROL_HANDLE(IDC_EDIT22, m_wndEditOrientation)
		DDX_CONTROL_HANDLE(IDC_EDIT41, m_wndEditOutPrecision)
		DDX_CONTROL_HANDLE(IDC_EDIT42, m_wndEditClipPrecision)
		DDX_CONTROL_HANDLE(IDC_EDIT43, m_wndEditQuality)
		DDX_CONTROL_HANDLE(IDC_EDIT51, m_wndEditFaceName)
		DDX_CONTROL_HANDLE(IDC_EDIT52, m_wndEditPitchAndFamily)
		DDX_CONTROL_HANDLE(IDC_EDIT53, m_wndEditCharSet)
		DDX_CONTROL_HANDLE(IDC_EDIT54, m_wndEditFontType)
		DDX_CONTROL_HANDLE(IDC_BUTTON60, m_wndButtonExample)
	END_DDX_MAP()

// Handler prototypes (uncomment arguments if needed):
//	LRESULT MessageHandler(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
//	LRESULT CommandHandler(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
//	LRESULT NotifyHandler(int /*idCtrl*/, LPNMHDR /*pnmh*/, BOOL& /*bHandled*/)

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnClose(void);
	LRESULT OnList1LbnSelChange(WORD wNotifyCode, WORD wID, HWND hWndCtl);
	LRESULT OnCheck11BnClicked(WORD wNotifyCode, WORD wID, HWND hWndCtl);
	LRESULT OnSysCommand(UINT cmd, CPoint Pt);
	LRESULT OnButton60BnClicked(WORD wNotifyCode, WORD wID, HWND hWndCtl);
	LRESULT OnHelp(LPHELPINFO lpHelpInfo);

private:
	void initVars(void);
	void initLang(void);
	void initString(WORD lang);
	void enumerateFonts(void);
	void modifyLogfont(LOGFONT* pModifiedLF);
	void showExample(LOGFONT* pModifiedLF);
	void copyClipboard(int menuID);
	void inputExample(void);
};

extern "C" bool comp(FontPair& left, FontPair& right);

extern "C" int CALLBACK enumerateFontsCallBack(ENUMLOGFONTEX *lpelf,
												NEWTEXTMETRICEX *lpntm,
												DWORD fontType, LPARAM lParam);

#ifdef _UNICODE
#define CF_TTEXT	CF_UNICODETEXT
#else
#define	CF_TTEXT	CF_TEXT
#endif

#ifndef CLIP_DFA_DISABLE
#define CLIP_DFA_DISABLE	(4<<4)
#endif

// �ѱ���
#define STR_FONT			_T("���� ����")

#define STR_TITLE			_T("�۲� ���ű�")
#define STR_ENUMFONT		_T("�۲� ��˻�")
#define STR_INFORMATION		_T("����")
#define STR_TOTAL			_T("���� �˻��Ǿ����ϴ�.")
#define STR_COPY_SRC		_T("Ŭ��������� ��Ʈ���� �ҽ��ڵ� ����")
#define STR_INPUT_EXAMPLE	_T("���� ���ڿ� �ٲٱ�")
#define STR_COPY_SRC_CREATEFONTINDIRECT_WIN32API	_T("::CreateFontIndirect(...)")
#define STR_COPY_SRC_CREATEFONT_WIN32API			_T("::CreateFontI(...)")
#define STR_COPY_SRC_CREATEFONTINDIRECT_WTL_MFC		_T("CFont::CreateFontIndirect(...)")
#define STR_COPY_SRC_CREATEFONT_WTL_MFC				_T("CFont::CreateFontI(...)")
#define STR_COPY_SRC_CREATEFONT_GDIPLUS				_T("Font font(...)")

#define STR_HEIGHT			_T("���� (Height):")
#define STR_POINT			_T("����Ʈ:")
#define STR_WIDTH			_T("�� (Width):")
#define STR_WEIGHT			_T("�β� (Weight):")
#define STR_ESCAPEMENT		_T("���ڿ� ���� (Escapement):")
#define STR_ORIENTATION		_T("���� ���� (Orientation):")
#define STR_ITALIC			_T("����Ӳ� (Italic)")
#define STR_UNDERLINE		_T("���� (Underline)")
#define STR_STRIKEOUT		_T("��Ҽ� (StrikeOut)")
#define STR_OUTPRECISION	_T("������е� (OutPrecision):")
#define STR_CLIPPRECISION	_T("Ŭ�����е� (ClipPrecision):")
#define STR_QUALITY			_T("ǰ�� (Quality):")
#define STR_FACENAME		_T("�۲��̸� (FaceName):")
#define STR_PITCHANDFAMILY	_T("��ġ�� �йи� (PitchAndFamily):")
#define STR_CHARSET			_T("�����ڵ� (CharSet):")
#define STR_FONTTYPE		_T("�۲����� (FontType)")
#define STR_SIZE			_T("ũ��")
#define STR_TILT			_T("����")
#define STR_SHAPE			_T("���")
#define STR_FONTNAME		_T("�۲��̸�")
#define STR_PRECISION		_T("���е�")

// ����
#define STR_FONT_ENG			_T("Calibri")

#define STR_TITLE_ENG			_T("Font Emulator")
#define STR_ENUMFONT_ENG		_T("Re-enumerate fonts")
#define STR_INFORMATION_ENG		_T("About...")
#define STR_TOTAL_ENG			_T("are found.")
#define STR_COPY_SRC_ENG		_T("Copy the source code for creating font to clipboard")
#define STR_INPUT_EXAMPLE_ENG	_T("Change the sample string")

#define STR_HEIGHT_ENG			_T("Height:")
#define STR_POINT_ENG			_T("Point:")
#define STR_WIDTH_ENG			_T("Width:")
#define STR_WEIGHT_ENG			_T("Weight:")
#define STR_ESCAPEMENT_ENG		_T("Escapement:")
#define STR_ORIENTATION_ENG		_T("Orientation:")
#define STR_ITALIC_ENG			_T("Italic")
#define STR_UNDERLINE_ENG		_T("Underline")
#define STR_STRIKEOUT_ENG		_T("StrikeOut")
#define STR_OUTPRECISION_ENG	_T("OutPrecision:")
#define STR_CLIPPRECISION_ENG	_T("ClipPrecision:")
#define STR_QUALITY_ENG			_T("Quality:")
#define STR_FACENAME_ENG		_T("FaceName:")
#define STR_PITCHANDFAMILY_ENG	_T("PitchAndFamily:")
#define STR_CHARSET_ENG			_T("CharSet:")
#define STR_FONTTYPE_ENG		_T("FontType")
#define STR_SHAPE_ENG			_T("Shape")
#define STR_SIZE_ENG			_T("Size")
#define STR_TILT_ENG			_T("Tilt")
#define STR_FONTNAME_ENG		_T("Font Name")
#define STR_PRECISION_ENG		_T("Precision")


#define STR_EXAMPE			_T("ABCdef ������ 123 �������ѬҬ� @#$%")

#define STR_CREATEFONTINDIRECT_WIN32API	_T("\tLOGFONT\tlf;\r\n")						\
										_T("\tlf.lfHeight = %d;\r\n")					\
										_T("\tlf.lfWidth = %d;\r\n")					\
										_T("\tlf.lfEscapement = %d;\r\n")				\
										_T("\tlf.lfOrientation = %d;\r\n")				\
										_T("\tlf.lfWeight = %s;\r\n")					\
										_T("\tlf.lfItalic = %s;\r\n")					\
										_T("\tlf.lfUnderline = %s;\r\n")				\
										_T("\tlf.lfStrikeOut = %s;\r\n")				\
										_T("\tlf.lfCharSet = %s;\r\n")					\
										_T("\tlf.lfOutPrecision = %s;\r\n")				\
										_T("\tlf.lfClipPrecision = %s;\r\n")			\
										_T("\tlf.lfQuality = %s;\r\n")					\
										_T("\tlf.lfPitchAndFamily = %s;\r\n")			\
										_T("\t_tcscpy(lf.lfFaceName, _T(\"%s\"));\r\n")	\
										_T("\tHFONT hFont = ::CreateFontIndirect(&lf);\r\n")

#define STR_CREATEFONT_WIN32API	_T("\tHFONT hFont = ::CreateFont(%d, %d, %d, %d, ")		\
								_T("%s, %s, %s, %s, %s, \r\n")							\
								_T("\t\t\t\t\t\t\t\t%s, %s, %s,\r\n")					\
								_T("\t\t\t\t\t\t\t\t%s, _T(\"%s\"));\r\n")

#define STR_CREATEFONTINDIRECT_WTL_MFC	_T("\tLOGFONT\tlf;\r\n")						\
										_T("\tlf.lfHeight = %d;\r\n")					\
										_T("\tlf.lfWidth = %d;\r\n")					\
										_T("\tlf.lfEscapement = %d;\r\n")				\
										_T("\tlf.lfOrientation = %d;\r\n")				\
										_T("\tlf.lfWeight = %s;\r\n")					\
										_T("\tlf.lfItalic = %s;\r\n")					\
										_T("\tlf.lfUnderline = %s;\r\n")				\
										_T("\tlf.lfStrikeOut = %s;\r\n")				\
										_T("\tlf.lfCharSet = %s;\r\n")					\
										_T("\tlf.lfOutPrecision = %s;\r\n")				\
										_T("\tlf.lfClipPrecision = %s;\r\n")			\
										_T("\tlf.lfQuality = %s;\r\n")					\
										_T("\tlf.lfPitchAndFamily = %s;\r\n")			\
										_T("\t_tcscpy(lf.lfFaceName, _T(\"%s\"));\r\n")	\
										_T("\tCFont\tfont;\r\n")						\
										_T("\tfont.CreateFontIndirect(&lf);\r\n")

#define STR_CREATEFONT_WTL_MFC	_T("\tCFont\tfont;\r\n")					\
								_T("\tfont.CreateFont(%d, %d, %d, %d, ")	\
								_T("%s, %s, %s, %s, %s, \r\n")				\
								_T("\t\t\t\t\t%s, %s, %s,\r\n")				\
								_T("\t\t\t\t\t%s, _T(\"%s\"));\r\n")

#define STR_CREATEFONT_GDIPLUS			_T("\tLOGFONT\tlf;\r\n")						\
										_T("\tlf.lfHeight = %d;\r\n")					\
										_T("\tlf.lfWidth = %d;\r\n")					\
										_T("\tlf.lfEscapement = %d;\r\n")				\
										_T("\tlf.lfOrientation = %d;\r\n")				\
										_T("\tlf.lfWeight = %s;\r\n")					\
										_T("\tlf.lfItalic = %s;\r\n")					\
										_T("\tlf.lfUnderline = %s;\r\n")				\
										_T("\tlf.lfStrikeOut = %s;\r\n")				\
										_T("\tlf.lfCharSet = %s;\r\n")					\
										_T("\tlf.lfOutPrecision = %s;\r\n")				\
										_T("\tlf.lfClipPrecision = %s;\r\n")			\
										_T("\tlf.lfQuality = %s;\r\n")					\
										_T("\tlf.lfPitchAndFamily = %s;\r\n")			\
										_T("\t_tcscpy(lf.lfFaceName, _T(\"%s\"));\r\n")	\
										_T("\tHDC\thDC = ::GetDC(NULL);\r\n")			\
										_T("\tFont\tfont(hDC, &lf);\r\n")				\
										_T("\t::ReleaseDC(NULL, hDC);\r\n")

#define STR_CREATEFONTINDIRECT_WIN32API_POINT	_T("\tHDC\thDC = ::GetDC(NULL);\r\n")	\
												_T("\tLOGFONT\tlf;\r\n")				\
		_T("\tlf.lfHeight = -::MulDiv(%d, ::GetDeviceCaps(hDC, LOGPIXELSY), 72);\r\n")	\
										_T("\t::ReleaseDC(NULL, hDC);\r\n")				\
										_T("\tlf.lfWidth = %d;\r\n")					\
										_T("\tlf.lfEscapement = %d;\r\n")				\
										_T("\tlf.lfOrientation = %d;\r\n")				\
										_T("\tlf.lfWeight = %s;\r\n")					\
										_T("\tlf.lfItalic = %s;\r\n")					\
										_T("\tlf.lfUnderline = %s;\r\n")				\
										_T("\tlf.lfStrikeOut = %s;\r\n")				\
										_T("\tlf.lfCharSet = %s;\r\n")					\
										_T("\tlf.lfOutPrecision = %s;\r\n")				\
										_T("\tlf.lfClipPrecision = %s;\r\n")			\
										_T("\tlf.lfQuality = %s;\r\n")					\
										_T("\tlf.lfPitchAndFamily = %s;\r\n")			\
										_T("\t_tcscpy(lf.lfFaceName, _T(\"%s\"));\r\n")	\
										_T("\tHFONT hFont = ::CreateFontIndirect(&lf);\r\n")

#define STR_CREATEFONT_WIN32API_POINT	_T("\tHDC\thDC = ::GetDC(NULL);\r\n")			\
										_T("\tHFONT hFont = ::CreateFont(")				\
						_T("-::MulDiv(%d, ::GetDeviceCaps(hDC, LOGPIXELSY), 72), \r\n")	\
										_T("\t\t\t\t\t\t\t\t%d, %d, %d, ")				\
										_T("%s, %s, %s, %s, %s, \r\n")					\
										_T("\t\t\t\t\t\t\t\t%s, %s, %s,\r\n")			\
										_T("\t\t\t\t\t\t\t\t%s, _T(\"%s\"));\r\n")		\
										_T("\t::ReleaseDC(NULL, hDC);\r\n")

#define STR_CREATEFONTINDIRECT_WTL_MFC_POINT	_T("\tHDC\thDC = ::GetDC(NULL);\r\n")	\
										_T("\tLOGFONT\tlf;\r\n")						\
		_T("\tlf.lfHeight = -::MulDiv(%d, ::GetDeviceCaps(hDC, LOGPIXELSY), 72);\r\n")	\
										_T("\t::ReleaseDC(NULL, hDC);\r\n")				\
										_T("\tlf.lfWidth = %d;\r\n")					\
										_T("\tlf.lfEscapement = %d;\r\n")				\
										_T("\tlf.lfOrientation = %d;\r\n")				\
										_T("\tlf.lfWeight = %s;\r\n")					\
										_T("\tlf.lfItalic = %s;\r\n")					\
										_T("\tlf.lfUnderline = %s;\r\n")				\
										_T("\tlf.lfStrikeOut = %s;\r\n")				\
										_T("\tlf.lfCharSet = %s;\r\n")					\
										_T("\tlf.lfOutPrecision = %s;\r\n")				\
										_T("\tlf.lfClipPrecision = %s;\r\n")			\
										_T("\tlf.lfQuality = %s;\r\n")					\
										_T("\tlf.lfPitchAndFamily = %s;\r\n")			\
										_T("\t_tcscpy(lf.lfFaceName, _T(\"%s\"));\r\n")	\
										_T("\tCFont\tfont;\r\n")						\
										_T("\tfont.CreateFontIndirect(&lf);\r\n")

#define STR_CREATEFONT_WTL_MFC_POINT	_T("\tHDC\thDC = ::GetDC(NULL);\r\n")			\
										_T("\tCFont\tfont;\r\n")						\
										_T("\tfont.CreateFont(")						\
						_T("-::MulDiv(%d, ::GetDeviceCaps(hDC, LOGPIXELSY), 72), \r\n")	\
										_T("\t\t\t\t\t%d, %d, %d, ")					\
										_T("%s, %s, %s, %s, %s, \r\n")					\
										_T("\t\t\t\t\t%s, %s, %s,\r\n")					\
										_T("\t\t\t\t\t%s, _T(\"%s\"));\r\n")			\
										_T("\t::ReleaseDC(NULL, hDC);\r\n")

#define STR_CREATEFONT_GDIPLUS_POINT	_T("\tHDC\thDC = ::GetDC(NULL);\r\n")			\
										_T("\tLOGFONT\tlf;\r\n")						\
		_T("\tlf.lfHeight = -::MulDiv(%d, ::GetDeviceCaps(hDC, LOGPIXELSY), 72);\r\n")	\
										_T("\tlf.lfWidth = %d;\r\n")					\
										_T("\tlf.lfEscapement = %d;\r\n")				\
										_T("\tlf.lfOrientation = %d;\r\n")				\
										_T("\tlf.lfWeight = %s;\r\n")					\
										_T("\tlf.lfItalic = %s;\r\n")					\
										_T("\tlf.lfUnderline = %s;\r\n")				\
										_T("\tlf.lfStrikeOut = %s;\r\n")				\
										_T("\tlf.lfCharSet = %s;\r\n")					\
										_T("\tlf.lfOutPrecision = %s;\r\n")				\
										_T("\tlf.lfClipPrecision = %s;\r\n")			\
										_T("\tlf.lfQuality = %s;\r\n")					\
										_T("\tlf.lfPitchAndFamily = %s;\r\n")			\
										_T("\t_tcscpy(lf.lfFaceName, _T(\"%s\"));\r\n")	\
										_T("\tFont\tfont(hDC, &lf);\r\n")				\
										_T("\t::ReleaseDC(NULL, hDC);\r\n")
