//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FontEnumerator.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDD_DLG_RESET                   200
#define IDD_INPUT_EXAMPLE               201
#define IDD_DIALOG_INPUT_SAMPLE         202
#define IDD_COPY_SRC_CREATEFONTINDIRECT_WIN32API	203
#define IDD_COPY_SRC_CREATEFONT_WIN32API			204
#define IDD_COPY_SRC_CREATEFONTINDIRECT_WTL_MFC		205
#define IDD_COPY_SRC_CREATEFONT_WTL_MFC				206
#define IDD_COPY_SRC_CREATEFONT_GDIPLUS				207
#define IDB_BITMAP_YOUNGHO              220
#define IDC_LIST1                       1000
#define IDC_STATIC10                    1001
#define IDC_CHECK11					    1002
#define IDC_STATIC12                    1003
#define IDC_STATIC13                    1004
#define IDC_STATIC20                    1005
#define IDC_EDIT11                      1006
#define IDC_EDIT12                      1007
#define IDC_EDIT13                      1008
#define IDC_STATIC21                    1009
#define IDC_STATIC22                    1010
#define IDC_EDIT21                      1011
#define IDC_EDIT22                      1012
#define IDC_STATIC30                    1013
#define IDC_CHECK31                     1014
#define IDC_CHECK32                     1015
#define IDC_CHECK33                     1016
#define IDC_STATIC40                    1017
#define IDC_STATIC41                    1018
#define IDC_STATIC42                    1019
#define IDC_STATIC43                    1020
#define IDC_EDIT41                      1021
#define IDC_EDIT42                      1022
#define IDC_EDIT43                      1023
#define IDC_STATIC50                    1024
#define IDC_STATIC51                    1025
#define IDC_STATIC52                    1026
#define IDC_STATIC53                    1027
#define IDC_STATIC54                    1028
#define IDC_EDIT51                      1029
#define IDC_EDIT52                      1030
#define IDC_EDIT53                      1031
#define IDC_EDIT54                      1032
#define IDC_BUTTON60                    1033
#define IDC_EDIT_SAMPLE                 1040

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1041
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
