// MainDlg.cpp : implementation of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "MainDlg.h"
#include "InputSampleString.h"
#include ".\maindlg.h"

LRESULT CMainDlg::OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	// center the dialog on the screen
	CenterWindow();

	// set icons
	HICON hIcon = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
		IMAGE_ICON, ::GetSystemMetrics(SM_CXICON), ::GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR);
	SetIcon(hIcon, TRUE);
	HICON hIconSmall = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
		IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
	SetIcon(hIconSmall, FALSE);

	DoDataExchange();
	initVars();

	CMenu subMenu;
	subMenu.CreatePopupMenu();
	subMenu.AppendMenu(MF_STRING, IDD_COPY_SRC_CREATEFONTINDIRECT_WIN32API,
									STR_COPY_SRC_CREATEFONTINDIRECT_WIN32API);
	subMenu.AppendMenu(MF_STRING, IDD_COPY_SRC_CREATEFONT_WIN32API,
									STR_COPY_SRC_CREATEFONT_WIN32API);
	subMenu.AppendMenu(MF_STRING, IDD_COPY_SRC_CREATEFONTINDIRECT_WTL_MFC,
									STR_COPY_SRC_CREATEFONTINDIRECT_WTL_MFC);
	subMenu.AppendMenu(MF_STRING, IDD_COPY_SRC_CREATEFONT_WTL_MFC,
									STR_COPY_SRC_CREATEFONT_WTL_MFC);
	subMenu.AppendMenu(MF_STRING, IDD_COPY_SRC_CREATEFONT_GDIPLUS,
									STR_COPY_SRC_CREATEFONT_GDIPLUS);

	CMenu menu(GetSystemMenu(FALSE));
	menu.InsertMenu(6, MF_BYPOSITION, IDD_ABOUTBOX, m_strInfo);
	menu.InsertMenu(5, MF_BYPOSITION | MF_POPUP, subMenu, m_strCopySrc);
	menu.InsertMenu(5, MF_BYPOSITION, IDD_INPUT_EXAMPLE, m_strInputExample);
	menu.InsertMenu(5, MF_BYPOSITION, IDD_DLG_RESET, m_strEnumFont);
	menu.InsertMenu(5, MF_BYPOSITION, MF_MENUBREAK, (LPCTSTR) NULL);

	WindowsHelper::setFont<true>(_Font, *this, m_wndButtonExample);
	return TRUE;
}

LRESULT CMainDlg::OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	CSimpleDialog<IDD_ABOUTBOX, TRUE> dlg;
	dlg.DoModal();
	return 0;
}

LRESULT CMainDlg::OnClose(void)
{
	EndDialog(0);
	return 0;
}

LRESULT CMainDlg::OnList1LbnSelChange(WORD wNotifyCode, WORD wID, HWND hWndCtl)
{
	wNotifyCode; wID; hWndCtl;

	TCHAR	temp[32];
	int		selected = m_wndListFonts.GetCurSel();
	LOGFONT*	pLF = &m_FontVec[selected].first;

	m_wndCheckHeight.SetCheck(BST_UNCHECKED);
	m_wndCheckHeight.SetWindowText(m_strHeight);
	m_wndEditHeight.SetWindowText(_itot(pLF->lfHeight, temp, 10));
	m_wndEditWidth.SetWindowText(_itot(pLF->lfWidth, temp, 10));
	m_wndEditWeight.SetWindowText(_itot(pLF->lfWeight, temp, 10));

	m_wndEditEscapement.SetWindowText(_itot(pLF->lfEscapement, temp, 10));
	m_wndEditOrientation.SetWindowText(_itot(pLF->lfOrientation, temp, 10));

	m_wndCheckItalic.SetCheck(pLF->lfItalic);
	m_wndCheckUnderline.SetCheck(pLF->lfUnderline);
	m_wndCheckStrikeout.SetCheck(pLF->lfStrikeOut);

	m_wndEditOutPrecision.SetWindowText(_itot(pLF->lfOutPrecision, temp, 10));
	m_wndEditClipPrecision.SetWindowText(_itot(pLF->lfClipPrecision, temp, 10));
	m_wndEditQuality.SetWindowText(_itot(pLF->lfQuality, temp, 10));

	m_wndEditFaceName.SetWindowText(pLF->lfFaceName);
	switch (pLF->lfCharSet)
	{
	case ANSI_CHARSET:			_tcscpy(temp, _T("ANSI_CHARSET"));			break;
	case DEFAULT_CHARSET:		_tcscpy(temp, _T("DEFAULT_CHARSET"));		break;
	case SYMBOL_CHARSET:		_tcscpy(temp, _T("SYMBOL_CHARSET"));		break;
	case MAC_CHARSET:			_tcscpy(temp, _T("MAC_CHARSET"));			break;
	case SHIFTJIS_CHARSET:		_tcscpy(temp, _T("SHIFTJIS_CHARSET"));		break;
	case HANGUL_CHARSET:		_tcscpy(temp, _T("HANGUL_CHARSET"));		break;
	case JOHAB_CHARSET:			_tcscpy(temp, _T("JOHAB_CHARSET"));			break;
	case GB2312_CHARSET:		_tcscpy(temp, _T("GB2312_CHARSET"));		break;
	case CHINESEBIG5_CHARSET:	_tcscpy(temp, _T("CHINESEBIG5_CHARSET"));	break;
	case GREEK_CHARSET:			_tcscpy(temp, _T("GREEK_CHARSET"));			break;
	case TURKISH_CHARSET:		_tcscpy(temp, _T("TURKISH_CHARSET"));		break;
	case VIETNAMESE_CHARSET:	_tcscpy(temp, _T("VIETNAMESE_CHARSET"));	break;
	case HEBREW_CHARSET:		_tcscpy(temp, _T("HEBREW_CHARSET"));		break;
	case ARABIC_CHARSET:		_tcscpy(temp, _T("BALTIC_CHARSET"));		break;
	case BALTIC_CHARSET:		_tcscpy(temp, _T("TURKISH_CHARSET"));		break;
	case RUSSIAN_CHARSET:		_tcscpy(temp, _T("RUSSIAN_CHARSET"));		break;
	case THAI_CHARSET:			_tcscpy(temp, _T("THAI_CHARSET"));			break;
	case EASTEUROPE_CHARSET:	_tcscpy(temp, _T("EASTEUROPE_CHARSET"));	break;
	case OEM_CHARSET:			_tcscpy(temp, _T("OEM_CHARSET"));			break;
	default:					_tcscpy(temp, _T("ETC"));					break;
	}
	m_wndEditCharSet.SetWindowText(temp);
	switch (pLF->lfPitchAndFamily & 0x0f)
	{
	case DEFAULT_PITCH:		_tcscpy(temp, _T("DEFAULT_PITCH"));		break;
	case FIXED_PITCH:		_tcscpy(temp, _T("FIXED_PITCH"));		break;
	case VARIABLE_PITCH:	_tcscpy(temp, _T("VARIABLE_PITCH"));	break;
	default:				_tcscpy(temp, _T("ETC"));				break;
	}
	switch (pLF->lfPitchAndFamily & 0xf0)
	{
	case FF_DONTCARE:		_tcscat(temp, _T(" | FF_DONTCARE"));	break;
	case FF_ROMAN:			_tcscat(temp, _T(" | FF_ROMAN"));		break;
	case FF_SWISS:			_tcscat(temp, _T(" | FF_SWISS"));		break;
	case FF_MODERN:			_tcscat(temp, _T(" | FF_MODERN"));		break;
	case FF_SCRIPT:			_tcscat(temp, _T(" | FF_SCRIPT"));		break;
	case FF_DECORATIVE:		_tcscat(temp, _T(" | FF_DECORATIVE"));	break;
	default:				_tcscat(temp, _T(" | ETC"));			break;
	}
	m_wndEditPitchAndFamily.SetWindowText(temp);
	switch (m_FontVec[selected].second)
	{
	case RASTER_FONTTYPE:	_tcscpy(temp, _T("RASTER_FONTTYPE"));	break;
	case DEVICE_FONTTYPE:	_tcscpy(temp, _T("DEVICE_FONTTYPE"));	break;
	case TRUETYPE_FONTTYPE:	_tcscpy(temp, _T("TRUETYPE_FONTTYPE"));	break;
	default:				_tcscpy(temp, _T("UnKnown"));			break;
	}
	m_wndEditFontType.SetWindowText(temp);

	showExample(pLF);

	return 0;
}

LRESULT CMainDlg::OnCheck11BnClicked(WORD wNotifyCode, WORD wID, HWND hWndCtl)
{
	wNotifyCode; wID; hWndCtl;

	TCHAR	temp[16];
	int		height, point;
	if (m_wndCheckHeight.GetCheck() == BST_CHECKED)
	{
		m_wndCheckHeight.SetWindowText(m_strPoint);
		m_wndEditHeight.GetWindowText(temp, sizeof temp / sizeof temp[0]);
		height = _ttoi(temp);
		if (height < 0)
			point = ::MulDiv(-height, 72, m_Resolution);
		else
			point = 0;
		m_wndEditHeight.SetWindowText(_itot(point, temp, 10));
		m_wndEditWidth.SetWindowText(_itot(0, temp, 10));
	}
	else
	{
		m_wndCheckHeight.SetWindowText(m_strHeight);
		m_wndEditHeight.GetWindowText(temp, sizeof temp / sizeof temp[0]);
		point = _ttoi(temp);
		height = -::MulDiv(point, m_Resolution, 72);
		m_wndEditHeight.SetWindowText(_itot(height, temp, 10));
	}
	return 0;
}

LRESULT CMainDlg::OnButton60BnClicked(WORD wNotifyCode, WORD wID, HWND hWndCtl)
{
	wNotifyCode; wID; hWndCtl;

	LOGFONT		ModifiedLF;
	modifyLogfont(&ModifiedLF);
	showExample(&ModifiedLF);
	return 0;
}

LRESULT CMainDlg::OnSysCommand(UINT cmd, CPoint Pt)
{
	Pt;

	BOOL	bDummy;
	switch (cmd)
	{
	case IDD_COPY_SRC_CREATEFONTINDIRECT_WIN32API:
	case IDD_COPY_SRC_CREATEFONT_WIN32API:
	case IDD_COPY_SRC_CREATEFONTINDIRECT_WTL_MFC:
	case IDD_COPY_SRC_CREATEFONT_WTL_MFC:
	case IDD_COPY_SRC_CREATEFONT_GDIPLUS:	copyClipboard(cmd);		break;
	case IDD_INPUT_EXAMPLE:	inputExample();							break;
	case IDD_DLG_RESET:		enumerateFonts();						break;
	case IDD_ABOUTBOX:		OnAppAbout(NULL, NULL, NULL, bDummy);	break;
	default:				SetMsgHandled(FALSE);					break;
	}
	return 0;
}

LRESULT CMainDlg::OnHelp(LPHELPINFO lpHelpInfo)
{
	lpHelpInfo;

	BOOL	bDummy = TRUE;
	OnAppAbout(NULL, NULL, NULL, bDummy);
	return TRUE;
}

void CMainDlg::initVars(void)
{
	initLang();
	enumerateFonts();
	m_wndListFonts.SetCurSel(0);
	OnList1LbnSelChange(LBN_SELCHANGE, IDC_LIST1, m_wndListFonts.m_hWnd);

	HDC	hDC = ::GetDC(NULL);
	m_Resolution = GetDeviceCaps(hDC, LOGPIXELSY);
	::ReleaseDC(NULL, hDC);
}

void CMainDlg::initLang(void)
{
	LPCTSTR		strWidth, strWeigt, strEscapement, strOrientation;
	LPCTSTR		strItalic, strUnderline, strStrikeout, strOutPrec, strClipPrec, strQuality;
	LPCTSTR		strFacename, strPitchAndFamily, strCharset, strFonttype;
	LPCTSTR		strSize, strTilt, strShape, strPrecision, strFontname;

	initString(_Lang);
	switch (_Lang)
	{
	case LANG_KOREAN:
		strWidth = STR_WIDTH;
		strWeigt = STR_WEIGHT;
		strEscapement = STR_ESCAPEMENT;
		strOrientation = STR_ORIENTATION;
		strItalic = STR_ITALIC;
		strUnderline = STR_UNDERLINE;
		strStrikeout = STR_STRIKEOUT;
		strOutPrec = STR_OUTPRECISION;
		strClipPrec = STR_CLIPPRECISION;
		strQuality = STR_QUALITY;
		strFacename = STR_FACENAME;
		strPitchAndFamily = STR_PITCHANDFAMILY;
		strCharset = STR_CHARSET;
		strFonttype = STR_FONTTYPE;
		strSize = STR_SIZE;
		strTilt = STR_TILT;
		strShape = STR_SHAPE;
		strPrecision = STR_PRECISION;
		strFontname = STR_FONTNAME;
		break;
	default:
		strWidth = STR_WIDTH_ENG;
		strWeigt = STR_WEIGHT_ENG;
		strEscapement = STR_ESCAPEMENT_ENG;
		strOrientation = STR_ORIENTATION_ENG;
		strItalic = STR_ITALIC_ENG;
		strUnderline = STR_UNDERLINE_ENG;
		strStrikeout = STR_STRIKEOUT_ENG;
		strOutPrec = STR_OUTPRECISION_ENG;
		strClipPrec = STR_CLIPPRECISION_ENG;
		strQuality = STR_QUALITY_ENG;
		strFacename = STR_FACENAME_ENG;
		strPitchAndFamily = STR_PITCHANDFAMILY_ENG;
		strCharset = STR_CHARSET_ENG;
		strFonttype = STR_FONTTYPE_ENG;
		strSize = STR_SIZE_ENG;
		strTilt = STR_TILT_ENG;
		strShape = STR_SHAPE_ENG;
		strPrecision = STR_PRECISION_ENG;
		strFontname = STR_FONTNAME_ENG;
		break;
	}

	m_wndCheckHeight.SetWindowText(m_strHeight);
	m_wndStaticWidth.SetWindowText(strWidth);
	m_wndStaticWeight.SetWindowText(strWeigt);

	m_wndStaticEscapement.SetWindowText(strEscapement);
	m_wndStaticOrientation.SetWindowText(strOrientation);
	
	m_wndCheckItalic.SetWindowText(strItalic);
	m_wndCheckUnderline.SetWindowText(strUnderline);
	m_wndCheckStrikeout.SetWindowText(strStrikeout);

	m_wndStaticOutPrecision.SetWindowText(strOutPrec);
	m_wndStaticClipPrecision.SetWindowText(strClipPrec);
	m_wndStaticQuality.SetWindowText(strQuality);

	m_wndStaticFaceName.SetWindowText(strFacename);
	m_wndStaticPitchAndFamily.SetWindowText(strPitchAndFamily);
	m_wndStaticCharSet.SetWindowText(strCharset);
	m_wndStaticFontType.SetWindowText(strFonttype);

	m_wndGroupSize.SetWindowText(strSize);
	m_wndGroupTilt.SetWindowText(strTilt);
	m_wndGroupShape.SetWindowText(strShape);
	m_wndGroupPrecision.SetWindowText(strPrecision);
	m_wndGroupFontName.SetWindowText(strFontname);

	m_wndButtonExample.SetWindowText(m_strExample.c_str());
	this->SetWindowText(m_strTitle);
}

void CMainDlg::initString(WORD lang)
{
	switch (lang)
	{
	case LANG_KOREAN:
		m_strTitle = STR_TITLE;
		m_strHeight = STR_HEIGHT;
		m_strPoint = STR_POINT;
		m_strInfo = STR_INFORMATION;
		m_strEnumFont = STR_ENUMFONT;
		m_strTotal = STR_TOTAL;
		m_strCopySrc = STR_COPY_SRC;
		m_strInputExample = STR_INPUT_EXAMPLE;
		break;
	default:
		m_strTitle = STR_TITLE_ENG;
		m_strHeight = STR_HEIGHT_ENG;
		m_strPoint = STR_POINT_ENG;
		m_strInfo = STR_INFORMATION_ENG;
		m_strEnumFont = STR_ENUMFONT_ENG;
		m_strTotal = STR_TOTAL_ENG;
		m_strCopySrc = STR_COPY_SRC_ENG;
		m_strInputExample = STR_INPUT_EXAMPLE_ENG;
		break;
	}
	m_strExample = STR_EXAMPE;
}

void CMainDlg::modifyLogfont(LOGFONT* pModifiedLF)
{
	TCHAR	temp[32];
	int		selected = m_wndListFonts.GetCurSel();
	*pModifiedLF = m_FontVec[selected].first;

	m_wndEditHeight.GetWindowText(temp, sizeof temp / sizeof temp[0]);
	if (m_wndCheckHeight.GetCheck() == BST_CHECKED)
		pModifiedLF->lfHeight = -::MulDiv(_ttoi(temp), m_Resolution, 72);
	else
		pModifiedLF->lfHeight = _ttoi(temp);
	m_wndEditWidth.GetWindowText(temp, sizeof temp / sizeof temp[0]);
	pModifiedLF->lfWidth = _ttoi(temp);
	m_wndEditWeight.GetWindowText(temp, sizeof temp / sizeof temp[0]);
	pModifiedLF->lfWeight = _ttoi(temp);

	m_wndEditEscapement.GetWindowText(temp, sizeof temp / sizeof temp[0]);
	pModifiedLF->lfEscapement = _ttoi(temp);
	m_wndEditOrientation.GetWindowText(temp, sizeof temp / sizeof temp[0]);
	pModifiedLF->lfOrientation = _ttoi(temp);

	pModifiedLF->lfItalic = (BYTE) m_wndCheckItalic.GetCheck();
	pModifiedLF->lfUnderline = (BYTE) m_wndCheckUnderline.GetCheck();
	pModifiedLF->lfStrikeOut = (BYTE) m_wndCheckStrikeout.GetCheck();

	m_wndEditOutPrecision.GetWindowText(temp, sizeof temp / sizeof temp[0]);
	pModifiedLF->lfOutPrecision = (BYTE) _ttoi(temp);
	m_wndEditClipPrecision.GetWindowText(temp, sizeof temp / sizeof temp[0]);
	pModifiedLF->lfClipPrecision = (BYTE) _ttoi(temp);
	m_wndEditQuality.GetWindowText(temp, sizeof temp / sizeof temp[0]);
	pModifiedLF->lfQuality = (BYTE) _ttoi(temp);
}

void CMainDlg::enumerateFonts(void)
{
	m_FontVec.clear();
	LOGFONT		lf;
	lf.lfFaceName[0] = _T('\0');
	lf.lfCharSet = DEFAULT_CHARSET;
	lf.lfPitchAndFamily = 0;
	::EnumFontFamiliesEx(CClientDC(m_hWnd).m_hDC, &lf,
						(FONTENUMPROC) enumerateFontsCallBack,
						(LPARAM) &m_FontVec, 0);
	std::sort(m_FontVec.begin(), m_FontVec.end(), comp);
	TCHAR	temp[50];
	_stprintf_s(temp, sizeof temp / sizeof temp[0], _T("%s - %d %s"),
					m_strTitle, m_FontVec.size(), m_strTotal);
	this->SetWindowText(temp);
	m_wndListFonts.ResetContent();
	for (FontVec::iterator it = m_FontVec.begin(); it != m_FontVec.end(); it++)
		m_wndListFonts.AddString(it->first.lfFaceName);
}

void CMainDlg::showExample(LOGFONT* pModifiedLF)
{
	if (m_Font.m_hFont != NULL)
		m_Font.DeleteObject();
	m_Font.CreateFontIndirect(pModifiedLF);
	m_wndButtonExample.SetFont(m_Font.m_hFont);
}

void CMainDlg::copyClipboard(int menuID)
{
	LOGFONT		ModifiedLF;
	modifyLogfont(&ModifiedLF);
	TCHAR	temp[1024], strWeight[16], strOutPrec[32], strClipPres[32], strQuality[32];
	TCHAR	strCharSet[32], strPitchAndFamily[32], strFaceName[32];

	switch (ModifiedLF.lfWeight)
	{
	case FW_DONTCARE:	_tcscpy(strWeight, _T("FW_DONTCARE"));		break;
	case FW_THIN:		_tcscpy(strWeight, _T("FW_THIN"));			break;
	case FW_EXTRALIGHT:	_tcscpy(strWeight, _T("FW_EXTRALIGHT"));	break;
	case FW_LIGHT:		_tcscpy(strWeight, _T("FW_LIGHT"));			break;
	case FW_NORMAL:		_tcscpy(strWeight, _T("FW_NORMAL"));		break; 
	case FW_MEDIUM:		_tcscpy(strWeight, _T("FW_MEDIUM"));		break;
	case FW_SEMIBOLD:	_tcscpy(strWeight, _T("FW_SEMIBOLD"));		break;
	case FW_BOLD:		_tcscpy(strWeight, _T("FW_BOLD"));			break;
	case FW_EXTRABOLD:	_tcscpy(strWeight, _T("FW_EXTRABOLD"));		break;
	case FW_HEAVY:		_tcscpy(strWeight, _T("FW_HEAVY"));			break;
	default:			_itot(ModifiedLF.lfWeight, strWeight, 10);	break;
	}

	switch (ModifiedLF.lfOutPrecision)
	{
	case OUT_DEFAULT_PRECIS:	_tcscpy(strOutPrec, _T("OUT_DEFAULT_PRECIS"));	break;
	case OUT_DEVICE_PRECIS:		_tcscpy(strOutPrec, _T("OUT_DEVICE_PRECIS"));	break;
	case OUT_OUTLINE_PRECIS:	_tcscpy(strOutPrec, _T("OUT_OUTLINE_PRECIS"));	break;
	case OUT_PS_ONLY_PRECIS:	_tcscpy(strOutPrec, _T("OUT_PS_ONLY_PRECIS"));	break;
	case OUT_RASTER_PRECIS:		_tcscpy(strOutPrec, _T("OUT_RASTER_PRECIS"));	break;
	case OUT_STRING_PRECIS:		_tcscpy(strOutPrec, _T("OUT_STRING_PRECIS"));	break;
	case OUT_STROKE_PRECIS:		_tcscpy(strOutPrec, _T("OUT_STROKE_PRECIS"));	break;
	case OUT_TT_ONLY_PRECIS:	_tcscpy(strOutPrec, _T("OUT_TT_ONLY_PRECIS"));	break;
	case OUT_TT_PRECIS:			_tcscpy(strOutPrec, _T("OUT_TT_PRECIS"));		break;
	default:					_tcscpy(strOutPrec, _T("OUT_DEFAULT_PRECIS"));	break;
	}

	switch (ModifiedLF.lfQuality)
	{
	case CLIP_DEFAULT_PRECIS:	_tcscpy(strClipPres, _T("CLIP_DEFAULT_PRECIS"));	break;
	case CLIP_STROKE_PRECIS:	_tcscpy(strClipPres, _T("CLIP_STROKE_PRECIS"));		break;
	case CLIP_LH_ANGLES:		_tcscpy(strClipPres, _T("CLIP_LH_ANGLES"));			break;
	case CLIP_DFA_DISABLE:		_tcscpy(strClipPres, _T("CLIP_DFA_DISABLE"));		break;
	case CLIP_EMBEDDED:			_tcscpy(strClipPres, _T("CLIP_EMBEDDED"));			break;
	default:					_tcscpy(strClipPres, _T("CLIP_DEFAULT_PRECIS"));	break;
	}

	switch (ModifiedLF.lfClipPrecision)
	{
	case DEFAULT_QUALITY:			_tcscpy(strQuality, _T("DEFAULT_QUALITY"));			break;
	case DRAFT_QUALITY:				_tcscpy(strQuality, _T("DRAFT_QUALITY"));			break;
	case PROOF_QUALITY:				_tcscpy(strQuality, _T("PROOF_QUALITY"));			break;
	case NONANTIALIASED_QUALITY:	_tcscpy(strQuality, _T("NONANTIALIASED_QUALITY"));	break;
	case ANTIALIASED_QUALITY:		_tcscpy(strQuality, _T("ANTIALIASED_QUALITY"));		break;
	case CLEARTYPE_QUALITY:			_tcscpy(strQuality, _T("CLEARTYPE_QUALITY"));		break;
	default:						_tcscpy(strQuality, _T("DEFAULT_QUALITY"));			break;
	}

	m_wndEditCharSet.GetWindowText(strCharSet, 32);
	m_wndEditPitchAndFamily.GetWindowText(strPitchAndFamily, 32);
	m_wndEditFaceName.GetWindowText(strFaceName, 32);

	LPCTSTR	str = STR_CREATEFONTINDIRECT_WIN32API;

	switch (menuID)
	{
	case IDD_COPY_SRC_CREATEFONTINDIRECT_WIN32API:
		str = (m_wndCheckHeight.GetCheck() == BST_CHECKED)
			? STR_CREATEFONTINDIRECT_WIN32API_POINT
			: STR_CREATEFONTINDIRECT_WIN32API;
		break;
	case IDD_COPY_SRC_CREATEFONT_WIN32API:
		str = (m_wndCheckHeight.GetCheck() == BST_CHECKED)
			? STR_CREATEFONT_WIN32API_POINT
			: STR_CREATEFONT_WIN32API;
		break;
	case IDD_COPY_SRC_CREATEFONTINDIRECT_WTL_MFC:
		str = (m_wndCheckHeight.GetCheck() == BST_CHECKED)
			? STR_CREATEFONTINDIRECT_WTL_MFC_POINT
			: STR_CREATEFONTINDIRECT_WTL_MFC;
		break;
	case IDD_COPY_SRC_CREATEFONT_WTL_MFC:
		str = (m_wndCheckHeight.GetCheck() == BST_CHECKED)
			? STR_CREATEFONT_WTL_MFC_POINT
			: STR_CREATEFONT_WTL_MFC;
		break;
	case IDD_COPY_SRC_CREATEFONT_GDIPLUS:
		str = (m_wndCheckHeight.GetCheck() == BST_CHECKED)
			? STR_CREATEFONT_GDIPLUS_POINT
			: STR_CREATEFONT_GDIPLUS;
		break;
	}

	if (m_wndCheckHeight.GetCheck() == BST_CHECKED)
		_stprintf_s(temp, sizeof temp / sizeof temp[0], str,
						::MulDiv(-ModifiedLF.lfHeight, 72, m_Resolution),
						ModifiedLF.lfWidth,
						ModifiedLF.lfEscapement, ModifiedLF.lfOrientation, strWeight,
						ModifiedLF.lfItalic ? _T("TRUE") : _T("FALSE"),
						ModifiedLF.lfUnderline ? _T("TRUE") : _T("FALSE"),
						ModifiedLF.lfStrikeOut ? _T("TRUE") : _T("FALSE"),
						strCharSet, strOutPrec, strClipPres, strQuality,
						strPitchAndFamily, strFaceName);
	else
		_stprintf_s(temp, sizeof temp / sizeof temp[0], str,
						ModifiedLF.lfHeight, ModifiedLF.lfWidth,
						ModifiedLF.lfEscapement, ModifiedLF.lfOrientation, strWeight,
						ModifiedLF.lfItalic ? _T("TRUE") : _T("FALSE"),
						ModifiedLF.lfUnderline ? _T("TRUE") : _T("FALSE"),
						ModifiedLF.lfStrikeOut ? _T("TRUE") : _T("FALSE"),
						strCharSet, strOutPrec, strClipPres, strQuality,
						strPitchAndFamily, strFaceName);

	int		size = (_tcslen(temp) + 1) * sizeof(TCHAR);
	HGLOBAL	hmem = GlobalAlloc(GHND, size);
	LPTSTR	pmem = (LPTSTR) GlobalLock(hmem);
	memcpy(pmem, temp, size);
	GlobalUnlock(hmem);
	if (OpenClipboard())
	{
		EmptyClipboard();
		SetClipboardData(CF_TTEXT, hmem);
		CloseClipboard();
	}
}

void CMainDlg::inputExample(void)
{
	InputSampleString	iss(m_strExample);
	if (IDOK == iss.DoModal())
	{
		m_strExample = (iss.m_strExample.empty()) ? STR_EXAMPE : iss.m_strExample;
		m_wndButtonExample.SetWindowText(m_strExample.c_str());
	}
}

extern "C" bool comp(FontPair& left, FontPair& right)
{
	if ((_T('@') != left.first.lfFaceName[0]) && (_T('@') == right.first.lfFaceName[0]))
		return true;
	if ((_T('@') == left.first.lfFaceName[0]) && (_T('@') != right.first.lfFaceName[0]))
		return false;
	return (_tcscmp(left.first.lfFaceName, right.first.lfFaceName) < 0);
}

extern "C" int CALLBACK enumerateFontsCallBack(ENUMLOGFONTEX *lpelf,
												NEWTEXTMETRICEX *lpntm,
												DWORD fontType, LPARAM lParam)
{
	lpntm;

	FontVec* pFontVec = (FontVec*) lParam;
	pFontVec->push_back(FontPair(lpelf->elfLogFont, fontType));
	return TRUE;
}

CFont	_Font;
OSL		_Lang(_Font.m_hFont, 9);
