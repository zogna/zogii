/********************************************************************
* 	Project  : NetMonitor
* 	FileName : ListCtrlEx.h
* 	Change   : 	
* 	Brief    :  	
* 	Author   : Chen Jun ( chenjun@3cis.com.cn )
* 	Copyright ( c ) 2007-2008 3cis 
* 	All Right Reserved
*********************************************************************/

#include "stdafx.h"
#include "ListCtrl-Button.h"
#include "ListCtrlEx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif 

#define IDC_BUTTON_ID 0x1235

/////////////////////////////////////////////////////////////////////////////
// CListCtrlEx



CListCtrlEx::CListCtrlEx()
{
	m_uID = IDC_BUTTON_ID;
}



CListCtrlEx::~CListCtrlEx()
{
	
}



BEGIN_MESSAGE_MAP( CListCtrlEx, CListCtrl )
	//{{AFX_MSG_MAP( CListCtrlEx )
		// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
		
	//}}AFX_MSG_MAP
	ON_NOTIFY_REFLECT(LVN_ENDSCROLL, &CListCtrlEx::OnLvnEndScroll)
	ON_WM_DRAWITEM()
	ON_WM_VSCROLL()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CListCtrlEx ���b�Z�[�W �n���h��

void CListCtrlEx::createItemButton( int nItem, int nSubItem, HWND hMain )
{
	CRect rect;
	int offset = 0;

	// Make sure that the item is visible
	if( !EnsureVisible(nItem, TRUE)) 
		return ;

	GetSubItemRect(nItem, nSubItem, LVIR_BOUNDS, rect);
	
	// Now scroll if we need to expose the column
	CRect rcClient;
	GetClientRect(rcClient);
	if( offset + rect.left < 0 || offset + rect.left > rcClient.right )
	{
		CSize size;
		size.cx = offset + rect.left;
		size.cy = 0;
		Scroll(size);
		rect.left -= size.cx;
	}

	rect.left += offset;	
	rect.right = rect.left + GetColumnWidth(nSubItem);
	if(rect.right > rcClient.right) 
		rect.right = rcClient.right;
	//basic code end

	rect.bottom = rect.top + rect.Height();

	int iPageCout = GetCountPerPage();
	if ( nItem >= iPageCout )
	{
		rect.top += rect.Height();
		rect.bottom += rect.Height();
	}

	DWORD dwStyle =  WS_CHILD | WS_VISIBLE;
	CButtonEx *pButton = new CButtonEx(nItem,nSubItem,rect,hMain);
	m_uID++;
	pButton->Create(_T("-"),dwStyle, rect, this, m_uID);
	m_mButton.insert( make_pair( nItem, pButton ) );

	int iTopIndex = GetTopIndex();
	if ( iTopIndex > 0 )
	{
		updateListCtrlButtonPos();
	}
	
	return;
}

void CListCtrlEx::release()
{
	button_map::iterator iter;
	iter = m_mButton.begin();
	while ( iter != m_mButton.end() )
	{
		delete iter->second;
		iter->second = NULL;
		iter++;
	}

}
void CListCtrlEx::deleteItemEx( int nItem )
{
	int iCount = GetItemCount();
	DeleteItem( nItem );
	button_map::iterator iter;
	button_map::iterator iterNext;
#ifdef USE_TOPINDEX_BUTTON
	//add-----------------------------------
	iter = m_mButton.find( nItem );
	iterNext = iter;
	iterNext++;
	while ( iterNext != m_mButton.end() )
	{
		iter->second->bEnable = iterNext->second->bEnable;
		iterNext++;
		iter++;
	}
	//------------------------------
#endif
	iter = m_mButton.find( iCount - 1 );
	if ( iter != m_mButton.end() )
	{
		delete iter->second;
		iter->second = NULL;
		m_mButton.erase( iter );
		updateListCtrlButtonPos();
	}
}
void CListCtrlEx::OnLvnEndScroll(NMHDR *pNMHDR, LRESULT *pResult)
{
	// ���̋@�\�� Internet Explorer 5.5 ������ȍ~�̃o�[�W������K�v�Ƃ��܂��B
	// �V���{�� _WIN32_IE �� >= 0x0560 �ɂȂ�Ȃ���΂Ȃ�܂���B
	LPNMLVSCROLL pStateChanged = reinterpret_cast<LPNMLVSCROLL>(pNMHDR);
	// TODO: �����ɃR���g���[���ʒm�n���h�� �R�[�h��ǉ����܂��B
	updateListCtrlButtonPos();
	*pResult = 0;
}

void CListCtrlEx::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B
	
	CListCtrl::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

void CListCtrlEx::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B
	CListCtrl::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CListCtrlEx::updateListCtrlButtonPos()
{
	int iTopIndex = GetTopIndex();
	int nItem = iTopIndex;
	button_map::iterator iter;
	button_map::iterator iterUp;
	int iLine = 0;
#ifdef USE_TOPINDEX_BUTTON
	iter = m_mButton.find( iTopIndex );
	iterUp = m_mButton.begin();
	while ( iter != m_mButton.end() )
	{
		iterUp->second->EnableWindow( iter->second->bEnable );
		iter ++;
		iterUp++;
	}
#else
	for ( ; nItem < GetItemCount(); nItem++ )
	{
		iter = m_mButton.find(nItem);
		if( iter!= m_mButton.end() )
		{
			CRect rect;
			iterUp = m_mButton.find(iLine);
			rect = iterUp->second->m_rect;
			iter->second->MoveWindow( &rect );
			iter->second->ShowWindow( SW_SHOW );
			if( iLine < iTopIndex )
			{
				iterUp->second->ShowWindow( SW_HIDE );
			}
			iLine++;
		}
	}
#endif

}

void CListCtrlEx::enableButton( BOOL bFlag, int iItem )
{
	button_map::iterator iter;
#ifdef USE_TOPINDEX_BUTTON
	int iTopIndex = GetTopIndex();
	int nItem = iItem - iTopIndex;
	iter = m_mButton.find( iItem );
	if ( iter != m_mButton.end() )
	{
		iter->second->bEnable = bFlag;
	}
	iter = m_mButton.find( nItem );
	if ( iter != m_mButton.end() )
	{
		iter->second->EnableWindow( bFlag );
	}
#else
	iter = m_mButton.find( iItem );
	if ( iter != m_mButton.end() )
	{
		iter->second->EnableWindow( bFlag );
	}
#endif

}