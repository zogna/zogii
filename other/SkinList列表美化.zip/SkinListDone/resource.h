//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SkinList.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SKINLIST_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDB_COLUMNHEADER_SPAN           130
#define IDB_COLUMNHEADER_START          131
#define IDB_COLUMNHEADER_END            136
#define IDB_HORIZONTAL_SCROLLBAR_THUMB  137
#define IDB_HORIZONTAL_SCROLLBAR_RIGHTARROW 138
#define IDB_HORIZONTAL_SCROLLBAR_SPAN   139
#define IDB_HORIZONTAL_SCROLLBAR_LEFTARROW 140
#define IDB_HORIZONTAL_SCROLLBAR_THUMB2 141
#define IDB_VERTICLE_SCROLLBAR_UPARROW  142
#define IDB_VERTICLE_SCROLLBAR_SPAN     143
#define IDB_VERTICLE_SCROLLBAR_THUMB    144
#define IDB_VERTICLE_SCROLLBAR_DOWNARROW 145
#define IDB_VERTICLE_SCROLLBAR_TOP      146
#define IDB_VERTICLE_SCROLLBAR_BOTTOM   150
#define IDB_LISTCTRL_TILE               151
#define IDC_SKIN_LIST                   1000
#define IDC_SKIN_HORIZONTAL_SCROLLBAR   1002
#define IDC_SKIN_VERTICLE_SCROLLBAR     1003
#define IDC_THUMBTOP                    1004
#define IDC_GEN_LIST                    1005
#define IDC_BUTTON1                     1006
#define IDC_LIST1                       1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
