//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by YiRongCarInFo.rc
//
#define IDD_YIRONGCARINFO_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_HISTORY              129
#define IDC_STATIC_REPORT               1000
#define IDC_STATIC_ALARM                1001
#define IDC_LIST_REPORT                 1002
#define IDC_LIST_ALARM                  1003
#define IDC_BUTTON_HISTORY              1004
#define IDC_BUTTON_HISTORY_ALL          1005
#define IDC_LIST                        1005
#define IDC_BUTTON_FIRST                1008
#define IDC_BUTTON_UP                   1009
#define IDC_BUTTON_NEXT                 1010
#define IDC_BUTTON_END                  1011
#define IDC_BUTTON_CARNUMBER            1012
#define IDC_EDIT_CARNUMBER              1013
#define IDC_DATETIMEPICKER_START        1014
#define IDC_DATETIMEPICKER_START2       1015
#define IDC_DATETIMEPICKER_END          1016
#define IDC_DATETIMEPICKER_END2         1017
#define IDC_BUTTON_CARNUMBER2           1018
#define IDC_BUTTON_TIME                 1018
#define IDC_EDIT_PHONE                  1019
#define IDC_BUTTON_SMS                  1020
#define IDC_STATIC_PHONE                1021
#define IDC_STATIC_LISTCHOICE           1022
#define ID_S_F                          32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
