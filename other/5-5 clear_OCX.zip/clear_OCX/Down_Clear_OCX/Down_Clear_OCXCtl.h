#if !defined(AFX_DOWN_CLEAR_OCXCTL_H__8447EDAB_3600_4193_86B1_D8A76E49D6EC__INCLUDED_)
#define AFX_DOWN_CLEAR_OCXCTL_H__8447EDAB_3600_4193_86B1_D8A76E49D6EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Down_Clear_OCXCtl.h : Declaration of the CDown_Clear_OCXCtrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXCtrl : See Down_Clear_OCXCtl.cpp for implementation.
#include "Down_Clear_OCXPpg.h"

#include "comcat.h"
#include <objsafe.h>
class CDown_Clear_OCXCtrl : public COleControl
{
	DECLARE_DYNCREATE(CDown_Clear_OCXCtrl)

// Constructor
public:
	CDown_Clear_OCXCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDown_Clear_OCXCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CDown_Clear_OCXCtrl();

	DECLARE_OLECREATE_EX(CDown_Clear_OCXCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CDown_Clear_OCXCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CDown_Clear_OCXCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CDown_Clear_OCXCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CDown_Clear_OCXCtrl)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CDown_Clear_OCXCtrl)
	afx_msg long DowanloadByName(LPCTSTR sDVRFileName, long hHandle);
	afx_msg long DowanloadByTime(long lChannel, short StartYear, short StartMonth, short StartDay, short StartHour, short StartMinute, short StartSecond, short StopYear, short StopMonth, short StopDay, short StopHour, short StopMinute, short StopSecond,long hHandle, short nType);
	afx_msg BSTR FindFile(long lChannel, short StartYear, short StartMonth, short StartDay, short StartHour, short StartMinute, short StartSecond, short StopYear, short StopMonth, short StopDay, short StopHour, short StopMinute, short StopSecond);
	afx_msg short GetDownloadPos(long hHandle);
	afx_msg BOOL LogIn(LPCTSTR sDVRIP, short wDVRPort, LPCTSTR sUserName, LPCTSTR sPassword);
	afx_msg void ShowParam();
	afx_msg BOOL StopDownLoad(long hHandle);
	afx_msg BOOL LogOut();
	afx_msg BOOL Play(short nType);
	afx_msg void SetFileName(LPCTSTR szFileName);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CDown_Clear_OCXCtrl)
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CDown_Clear_OCXCtrl)
	dispidDowanloadByName = 1L,
	dispidDowanloadByTime = 2L,
	dispidFindFile = 3L,
	dispidGetDownloadPos = 4L,
	dispidLogIn = 5L,
	dispidShowParam = 6L,
	dispidStopDownLoad = 7L,
	dispidLogOut = 8L,
	dispidPlay = 9L,
	dispidSetFileName = 10L,
	//}}AFX_DISP_ID
	};

	BOOL m_bIsLogIn ;
	CDown_Clear_OCXPropPage *m_pDlg;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DOWN_CLEAR_OCXCTL_H__8447EDAB_3600_4193_86B1_D8A76E49D6EC__INCLUDED)
