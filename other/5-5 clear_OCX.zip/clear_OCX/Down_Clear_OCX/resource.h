//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Down_Clear_OCX.rc
//
#define IDS_DOWN_CLEAR_OCX              1
#define IDD_ABOUTBOX_DOWN_CLEAR_OCX     1
#define IDB_DOWN_CLEAR_OCX              1
#define IDI_ABOUTDLL                    1
#define IDS_DOWN_CLEAR_OCX_PPG          2
#define IDS_STRINGALGSHOW               3
#define IDS_DOWN_CLEAR_OCX_PPG_CAPTION  200
#define IDD_PROPPAGE_DOWN_CLEAR_OCX     200
#define IDC_STATIC_PLAY_LOCAL           201
#define IDC_SLIDER_PLAY                 202
#define IDC_BTN_PALY                    203
#define IDC_BTN_STOP                    205
#define IDC_BTN_STOP2                   206
#define IDC_BTN_OPEN                    206
#define IDC_SLIDER1                     207
#define IDC_SLIDER_BLOWUP               207
#define IDC_SLIDER2                     208
#define IDC_RADIO_AN                    208
#define IDC_SLIDER3                     209
#define IDC_SLIDER_LIGHT                209
#define IDC_SLIDER4                     210
#define IDC_RADIO_LG                    210
#define IDB_BIT_LIGHT                   210
#define IDC_SLIDER5                     211
#define IDC_RADIO_WY                    211
#define IDB_BIT_SHARPEING               211
#define IDC_RADIO_LG2                   211
#define IDC_SLIDER6                     212
#define IDC_SLIDER_CONTRAST             212
#define IDB_BIT_DELLUMP                 212
#define IDC_SLIDER_CHECK                213
#define IDB_BIT_CONTRAST                213
#define IDC_SLIDER_DELLUMP              214
#define IDB_BIT_PLAY                    214
#define IDC_SLIDER_SHARPENING           215
#define IDB_BIT_PLAY_ENABLE             215
#define IDC_RADIO_LCJ                   216
#define IDC_RADIO_FS                    217
#define IDC_RADIO_SDJH                  218
#define IDC_RADIO_FS2                   218
#define IDC_BTN_LIGHT                   219
#define IDI_PLAY_DISABLE                219
#define IDC_BTN_DELLUMP                 220
#define IDI_ICON2                       220
#define IDI_ICON_QK_ENABLE              220
#define IDC_BTN_CONTAST                 221
#define IDI_ICON3                       221
#define IDI_ICON_DBD_ENABLE             221
#define IDC_BTN_CONTAST2                222
#define IDC_BTN_SHARPENG                222
#define IDI_ICON4                       222
#define IDI_ICON_LD_DISABLE             222
#define IDI_ICON5                       223
#define IDI_ICON_LD_ENABLE              223
#define IDI_ICON6                       224
#define IDI_ICON7                       225
#define IDI_ICON8                       226
#define IDI_ICON_RH_DISABLE             226
#define IDC_CHECK_ANCJ                  226
#define IDI_ICON9                       227
#define IDI_ICON_RH_ENABLE              227
#define IDC_CHECK_LG                    227
#define IDI_ICON10                      228
#define IDI_ICON_OPEN_DISABLE           228
#define IDC_CHECK_WY                    228
#define IDI_ICON11                      229
#define IDI_ICON_OPEN                   229
#define IDI_ICON_OPEN_ENABLE            229
#define IDC_CHECK_LCJ                   229
#define IDI_PAUSE_DISABLE               230
#define IDC_CHECK_FS                    230
#define IDI_PAUSE_ENABLE                231
#define IDC_CHECK6                      231
#define IDC_CHECK_SDJH                  231
#define IDI_PLAY_ENABLE                 232
#define IDI_ICON_DBD_DISABLE            237
#define IDI_STOP_DISABLE                238
#define IDI_STOP_ENABLE                 239
#define IDI_ICON_QK_DISABLE             245
#define IDB_BITMAP_ACTIVE               247
#define IDB_BITMAP_THUMB                249
#define IDB_BITMAP_NORMAL               251
#define IDB_BITMAP_NORMAL1              252
#define IDB_BITMAP_THUMB1               253
#define IDB_BITMAP_ACTIVE_SHORT         254
#define IDB_BITMAP_NORMAL_SHORT         255

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        250
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         227
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
