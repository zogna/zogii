// Down_Clear_OCXCtl.cpp : Implementation of the CDown_Clear_OCXCtrl ActiveX Control class.

#include "stdafx.h"
#include "Down_Clear_OCX.h"
#include "Down_Clear_OCXCtl.h"
#include "Down_Clear_OCXPpg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//#include "DownLoad.h"
#include "launet.h"
IMPLEMENT_DYNCREATE(CDown_Clear_OCXCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CDown_Clear_OCXCtrl, COleControl)
	//{{AFX_MSG_MAP(CDown_Clear_OCXCtrl)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CDown_Clear_OCXCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CDown_Clear_OCXCtrl)
	DISP_FUNCTION(CDown_Clear_OCXCtrl, "DowanloadByName", DowanloadByName, VT_I4, VTS_BSTR VTS_I4)
	DISP_FUNCTION(CDown_Clear_OCXCtrl, "DowanloadByTime", DowanloadByTime, VT_I4, VTS_I4 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I4 VTS_I2)
	DISP_FUNCTION(CDown_Clear_OCXCtrl, "FindFile", FindFile, VT_BSTR, VTS_I4 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2)
	DISP_FUNCTION(CDown_Clear_OCXCtrl, "GetDownloadPos", GetDownloadPos, VT_I2, VTS_I4)
	DISP_FUNCTION(CDown_Clear_OCXCtrl, "LogIn", LogIn, VT_BOOL, VTS_BSTR VTS_I2 VTS_BSTR VTS_BSTR)
	DISP_FUNCTION(CDown_Clear_OCXCtrl, "ShowParam", ShowParam, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CDown_Clear_OCXCtrl, "StopDownLoad", StopDownLoad, VT_BOOL, VTS_I4)
	DISP_FUNCTION(CDown_Clear_OCXCtrl, "LogOut", LogOut, VT_BOOL, VTS_NONE)
	DISP_FUNCTION(CDown_Clear_OCXCtrl, "Play", Play, VT_BOOL, VTS_I2)
	DISP_FUNCTION(CDown_Clear_OCXCtrl, "SetFileName", SetFileName, VT_EMPTY, VTS_BSTR)
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CDown_Clear_OCXCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CDown_Clear_OCXCtrl, COleControl)
	//{{AFX_EVENT_MAP(CDown_Clear_OCXCtrl)
	// NOTE - ClassWizard will add and remove event map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CDown_Clear_OCXCtrl, 1)
	PROPPAGEID(CDown_Clear_OCXPropPage::guid)
END_PROPPAGEIDS(CDown_Clear_OCXCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CDown_Clear_OCXCtrl, "DOWNCLEAROCX.DownClearOCXCtrl.1",
	0x593a1be3, 0xcc77, 0x4401, 0x9c, 0x43, 0x8, 0xa1, 0x2b, 0x88, 0x45, 0x31)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CDown_Clear_OCXCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DDown_Clear_OCX =
		{ 0xb1fe3ad7, 0xb01f, 0x43a0, { 0xa6, 0xad, 0xb4, 0x71, 0x6f, 0x52, 0x10, 0x7a } };
const IID BASED_CODE IID_DDown_Clear_OCXEvents =
		{ 0x91ab1a44, 0x2462, 0x4107, { 0xa2, 0x4e, 0xf1, 0xf2, 0x61, 0x81, 0x84, 0x32 } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwDown_Clear_OCXOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CDown_Clear_OCXCtrl, IDS_DOWN_CLEAR_OCX, _dwDown_Clear_OCXOleMisc)

/////////////ZOGNA//////DOWN////////��ȫ//����JSP�޷�����////////
HRESULT CreateComponentCategory(CATID catid, WCHAR* catDescription)
{

	ICatRegister* pcr = NULL ;
	HRESULT hr = S_OK ;

	hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr,
		NULL, CLSCTX_INPROC_SERVER, IID_ICatRegister, (void**)&pcr);
	if (FAILED(hr))
		return hr;

	// Make sure the HKCR\Component Categories\{..catid...}

	// key is registered

	CATEGORYINFO catinfo;
	catinfo.catid = catid;
	catinfo.lcid = 0x0409 ; // english


	// Make sure the provided description is not too long.

	// Only copy the first 127 characters if it is

	int len = wcslen(catDescription);
	if (len>127)
		len = 127;
	wcsncpy(catinfo.szDescription, catDescription, len);
	// Make sure the description is null terminated

	catinfo.szDescription[len] = '\0';

	hr = pcr->RegisterCategories(1, &catinfo);
	pcr->Release();

	return hr;
}


HRESULT RegisterCLSIDInCategory(REFCLSID clsid, CATID catid)
{
	// Register your component categories information.

	ICatRegister* pcr = NULL ;
	HRESULT hr = S_OK ;
	hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr,
		NULL, CLSCTX_INPROC_SERVER, IID_ICatRegister, (void**)&pcr);
	if (SUCCEEDED(hr))
	{
		// Register this category as being "implemented" by

		// the class.

		CATID rgcatid[1] ;
		rgcatid[0] = catid;
		hr = pcr->RegisterClassImplCategories(clsid, 1, rgcatid);
	}

	if (pcr != NULL)
		pcr->Release();

	return hr;
}

HRESULT UnRegisterCLSIDInCategory(REFCLSID clsid, CATID catid)
{
	ICatRegister* pcr = NULL ;
	HRESULT hr = S_OK ;
	hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr,
		NULL, CLSCTX_INPROC_SERVER, IID_ICatRegister, (void**)&pcr);
	if (SUCCEEDED(hr))
	{
		// Unregister this category as being "implemented" by

		// the class.

		CATID rgcatid[1] ;
		rgcatid[0] = catid;
		hr = pcr->UnRegisterClassImplCategories(clsid, 1, rgcatid);
	}

	if (pcr != NULL)
		pcr->Release();

	return hr;
}
BOOL CDown_Clear_OCXCtrl::CDown_Clear_OCXCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
	{
		HRESULT hr = S_OK ;

		// register as safe for scripting

		hr = CreateComponentCategory(CATID_SafeForScripting,
			L"Controls that are safely scriptable");

		if (FAILED(hr))
			return FALSE;

		hr = RegisterCLSIDInCategory(m_clsid, CATID_SafeForScripting);

		if (FAILED(hr))
			return FALSE;

		// register as safe for initializing

		hr = CreateComponentCategory(CATID_SafeForInitializing,
			L"Controls safely initializable from persistent data");

		if (FAILED(hr))
			return FALSE;

		hr = RegisterCLSIDInCategory(m_clsid, CATID_SafeForInitializing);

		if (FAILED(hr))
			return FALSE;

		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_DOWN_CLEAR_OCX,
			IDB_DOWN_CLEAR_OCX,
			afxRegInsertable | afxRegApartmentThreading,
			_dwDown_Clear_OCXOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	}
	else
	{
		HRESULT hr = S_OK ;

		hr = UnRegisterCLSIDInCategory(m_clsid, CATID_SafeForScripting);

		if (FAILED(hr))
			return FALSE;

		hr = UnRegisterCLSIDInCategory(m_clsid, CATID_SafeForInitializing);

		if (FAILED(hr))
			return FALSE;

		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
	}
}

/////////////ZOGNA////////UP//////��ȫ//����JSP�޷�����////////
/*
/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXCtrl::CDown_Clear_OCXCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CDown_Clear_OCXCtrl

BOOL CDown_Clear_OCXCtrl::CDown_Clear_OCXCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_DOWN_CLEAR_OCX,
			IDB_DOWN_CLEAR_OCX,
			afxRegApartmentThreading,
			_dwDown_Clear_OCXOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}
*/

/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXCtrl::CDown_Clear_OCXCtrl - Constructor


CDown_Clear_OCXCtrl::CDown_Clear_OCXCtrl()
{
	InitializeIIDs(&IID_DDown_Clear_OCX, &IID_DDown_Clear_OCXEvents);
	m_bIsLogIn = FALSE;
	m_pDlg = NULL;

	VSNET_ClientStartup(0,0,0);
	SDK_Init();
	// TODO: Initialize your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXCtrl::~CDown_Clear_OCXCtrl - Destructor

CDown_Clear_OCXCtrl::~CDown_Clear_OCXCtrl()
{
	// TODO: Cleanup your control's instance data here.
	
	LogOut();

	if(m_pDlg)
		delete m_pDlg;


	VSNET_ClientCleanup();
	SDK_Cleanup();

}


/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXCtrl::OnDraw - Drawing function

void CDown_Clear_OCXCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	// TODO: Replace the following code with your own drawing code.
// 	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
// 	pdc->Ellipse(rcBounds);
}


/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXCtrl::DoPropExchange - Persistence support

void CDown_Clear_OCXCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	// TODO: Call PX_ functions for each persistent custom property.

}


/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXCtrl::OnResetState - Reset control to default state

void CDown_Clear_OCXCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXCtrl::AboutBox - Display an "About" box to the user

void CDown_Clear_OCXCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_DOWN_CLEAR_OCX);
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXCtrl message handlers
/************************************************************************
* -6  û�г�ʼ��                                                                  

************************************************************************/
long  CDown_Clear_OCXCtrl::DowanloadByName(LPCTSTR sDVRFileName, long hHandle) 
{
	// TODO: Add your dispatch handler code here
	if(m_pDlg == NULL )
		return -6;
	
	return m_pDlg->DowanloadByName(sDVRFileName);


}

long  CDown_Clear_OCXCtrl::DowanloadByTime(long lChannel, short StartYear, short StartMonth, short StartDay,\
										   short StartHour, short StartMinute, short StartSecond, \
										   short StopYear, short StopMonth, short StopDay, \
										   short StopHour, short StopMinute, short StopSecond, \
										   long hHandle ,short nType) 
{
	// TODO: Add your dispatch handler code here
	NET_TIME startTime ,stopTime;
	startTime.dwYear=StartYear;
	startTime.dwMonth= StartMonth;
	startTime.dwDay=StartDay;
	startTime.dwHour=StartHour;
	startTime.dwMinute= StartMinute;
	startTime.dwSecond=StartSecond;
	
	stopTime.dwYear=StopYear;
	stopTime.dwMonth=StopMonth;
	stopTime.dwDay=StopDay;
	stopTime.dwHour=StopHour;
	stopTime.dwMinute=StopMinute;
	stopTime.dwSecond=StopSecond; 
	if(m_pDlg == NULL)
		return -1;

	return m_pDlg->DowanloadByTime(lChannel,startTime,stopTime,0,nType);
}

BSTR CDown_Clear_OCXCtrl::FindFile(long lChannel, short StartYear, short StartMonth, short StartDay, short StartHour, short StartMinute, short StartSecond, short StopYear, short StopMonth, short StopDay, short StopHour, short StopMinute, short StopSecond) 
{

	// TODO: Add your dispatch handler code here
	CString strResult;
	NET_TIME startTime ,stopTime;
	startTime.dwYear=StartYear;
	startTime.dwMonth= StartMonth;
	startTime.dwDay=StartDay;
	startTime.dwHour=StartHour;
	startTime.dwMinute= StartMinute;
	startTime.dwSecond=StartSecond;
	
	stopTime.dwYear=StopYear;
	stopTime.dwMonth=StopMonth;
	stopTime.dwDay=StopDay;
	stopTime.dwHour=StopHour;
	stopTime.dwMinute=StopMinute;
	stopTime.dwSecond=StopSecond; 
	if(m_pDlg == NULL || !m_bIsLogIn)
		return 0;
#ifdef TEST
	CString szTemp ;
	szTemp.Format(" ͨ���� %d %d-%d-%d %d:%d:%d  --- %d-%d-%d %d:%d:%d",lChannel,startTime.dwYear,\
		startTime.dwMonth,startTime.dwDay,startTime.dwHour,startTime.dwMinute,startTime.dwSecond,\
		stopTime.dwYear,stopTime.dwMonth,stopTime.dwDay,stopTime.dwHour,stopTime.dwMinute,stopTime.dwSecond
		);
	MessageBox(szTemp);
#endif	
	strResult = m_pDlg->FindFile(lChannel,startTime,stopTime);
	if(strResult.IsEmpty())
	{
		return 0;
	}
	return strResult.AllocSysString();
}

short CDown_Clear_OCXCtrl::GetDownloadPos(long hHandle) 
{
	// TODO: Add your dispatch handler code here
	if(m_pDlg == NULL)
		return -1;
	int nRet = m_pDlg->GetDownloadPos(hHandle);
	return nRet;

}

BOOL CDown_Clear_OCXCtrl::LogIn(LPCTSTR sDVRIP, short wDVRPort, LPCTSTR sUserName, LPCTSTR sPassword) 
{
	// TODO: Add your dispatch handler code here
	if(!m_bIsLogIn && m_pDlg !=NULL)
	{
		int nRet = m_pDlg->LogIn(sDVRIP,wDVRPort,sUserName,sPassword);
		if(nRet == 1)
		{
			//MessageBox("��¼�ɹ�!");
			m_bIsLogIn = TRUE;
			return TRUE;
		}
		m_bIsLogIn = FALSE;
		return  FALSE;

	}
	else if(m_bIsLogIn && m_pDlg!=NULL)
	{
		return TRUE;
	}
	return FALSE;
}

void CDown_Clear_OCXCtrl::ShowParam() 
{
	// TODO: Add your dispatch handler code here
	if (m_pDlg)
    {
        m_pDlg->DestroyWindow();
        delete m_pDlg;
        m_pDlg = NULL;
    }
	
    m_pDlg = new CDown_Clear_OCXPropPage();
    m_pDlg->Create(IDD_PROPPAGE_DOWN_CLEAR_OCX, this);
    m_pDlg->ShowWindow(SW_SHOW);
	

  

}
/************************************************************************/
/*    
	return  :
		1   ���û��������� ��ֹͣ���ز��ͷ���Դ
		0   ��ʾֹͣ����ʧ��
		                                                               */
/************************************************************************/
BOOL CDown_Clear_OCXCtrl::StopDownLoad(long hHandle) 
{
	// TODO: Add your dispatch handler code here
	if(m_pDlg == NULL)
		return 0;
	return m_pDlg->StopDownLoad(hHandle);


}


BOOL CDown_Clear_OCXCtrl::LogOut() 
{
	// TODO: Add your dispatch handler code here
	
	if(m_pDlg == NULL)
		return 0;
	BOOL bRet = m_pDlg->LogOut();
	m_bIsLogIn = FALSE;
	if(m_pDlg)
	{
		delete m_pDlg;
		m_pDlg = NULL;
	}
	return bRet;
}
/*

void  CDown_Clear_OCXCtrl::SetPlayFileName(LPCTSTR szFileName) 
{
	// TODO: Add your dispatch handler code here
	if(m_pDlg == NULL)
	{
		AfxMessageBox("����δ��ʾ���������ò����ļ���");
		return;
	}
	m_pDlg->SetPlayFileName(szFileName);


}
*/


BOOL CDown_Clear_OCXCtrl::Play(short nType) 
{
	// TODO: Add your dispatch handler code here

	if(m_pDlg == NULL)
	{
		AfxMessageBox("����δ��ʾ�����ܲ����ļ���");
		return FALSE;
	}

   // m_pDlg->ShowWindow(SW_SHOW);

	return  m_pDlg->Play(nType);

}

/*
void  CDown_Clear_OCXCtrl::SetPlayFileName(LPCTSTR szFileName) 
{
	// TODO: Add your dispatch handler code here
	if(m_pDlg == NULL)
	{
		AfxMessageBox("����δ��ʾ���������ò����ļ���");
		return;
	}
	m_pDlg->SetPlayFileName(szFileName);
	
	
}


BOOL CDown_Clear_OCXCtrl::Play(short nType) 
{
	// TODO: Add your dispatch handler code here
	if(m_pDlg == NULL)
	{
		AfxMessageBox("����δ��ʾ�����ܲ����ļ���");
		return FALSE;
	}
	return  m_pDlg->Play(nType);
	
}

*/
/// EnhanceRenderLib.lib 

void CDown_Clear_OCXCtrl::SetFileName(LPCTSTR szFileName) 
{
	// TODO: Add your dispatch handler code here
	if(m_pDlg == NULL)
	{
		AfxMessageBox("����δ��ʾ���������ò����ļ���");
		return;
	}
	m_pDlg->SetPlayFileName(szFileName);
}


