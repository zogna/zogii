// Down_Clear_OCXPpg.cpp : Implementation of the CDown_Clear_OCXPropPage property page class.



#include "stdafx.h"

#include "../include/opencv_inc/cv.h"
#include "../include/opencv_inc/cxcore.h"
#include "../include/opencv_inc/highgui.h"

#pragma comment(lib, "../lib/cv_lib/cv200.lib")
#pragma comment(lib, "../lib/cv_lib/cxcore200.lib")
#pragma comment(lib, "../lib/cv_lib/highgui200.lib")


/*typedef struct CvCapture CvCapture;*/
//#define cvCaptureFromFile cvCreateFileCapture

#include "Down_Clear_OCX.h"
#include "Down_Clear_OCXPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "Download.h"
#include "plaympeg4.h"
#include "RenderAlgFacade.h"
IMPLEMENT_DYNCREATE(CDown_Clear_OCXPropPage, COlePropertyPage)

#include "launet.h"


#define  SETRANGE   3
#define  DECFAILED  4
#define  SETPOS     5
#define  STOPPLAY   6
#define STARTIMAGESHOW      7
#define MP4FAILED           8


#define RADIO_UPDATE 9
 //#include "../opencv/opencv_inc/cv.h"
// #include "../opencv/opencv_inc/cxcore.h"
// #include "../opencv/opencv_inc/highgui.h"
// 
// #pragma comment(lib, "../opencv/cv_lib/cv200.lib")
// #pragma comment(lib, "../opencv/cv_lib/cxcore200.lib")
// #pragma comment(lib, "../opencv/cv_lib/highgui200.lib")
// 
// #include "../EnhanceRenderLib/RenderAlgFacade.h"

//#pragma comment(lib, "../lib/EnhanceRenderLib.lib")

/*#pragma  comment(lib,"../lib/EnhanceRenderLib.lib")*/
/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CDown_Clear_OCXPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CDown_Clear_OCXPropPage)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BTN_PALY, OnBtnPaly)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BTN_STOP, OnBtnStop)
	ON_NOTIFY(NM_OUTOFMEMORY, IDC_SLIDER_PLAY, OnOutofmemorySliderPlay)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_PLAY, OnReleasedcaptureSliderPlay)
	ON_WM_LBUTTONDOWN()
	ON_WM_PAINT()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_SETCURSOR()
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_BLOWUP, OnReleasedcaptureSliderBlowup)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_LIGHT, OnReleasedcaptureSliderLight)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_CONTRAST, OnReleasedcaptureSliderContrast)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_CHECK, OnReleasedcaptureSliderCheck)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_DELLUMP, OnReleasedcaptureSliderDellump)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_SHARPENING, OnReleasedcaptureSliderSharpening)
	ON_BN_CLICKED(IDC_RADIO_AN, OnRadioAn)
	ON_BN_CLICKED(IDC_RADIO_LG, OnRadioLg)
	ON_BN_CLICKED(IDC_RADIO_WY, OnRadioWy)
	ON_BN_CLICKED(IDC_RADIO_LCJ, OnRadioLcj)
	ON_BN_CLICKED(IDC_RADIO_FS, OnRadioFs)
	ON_BN_CLICKED(IDC_RADIO_SDJH, OnRadioSdjh)
	ON_WM_CTLCOLOR()

	ON_BN_CLICKED(IDC_BTN_DELLUMP, OnBtnDellump)
	ON_BN_CLICKED(IDC_BTN_CONTAST, OnBtnContast)
	ON_BN_CLICKED(IDC_BTN_LIGHT, OnBtnLight)
	ON_BN_CLICKED(IDC_BTN_SHARPENG, OnBtnSharpeng)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_DECSHOW,OnDecShow)
	ON_BN_CLICKED(IDC_BTN_OPEN, &CDown_Clear_OCXPropPage::OnBnClickedBtnOpen)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_BLOWUP, &CDown_Clear_OCXPropPage::OnNMCustomdrawSliderBlowup)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_LIGHT, &CDown_Clear_OCXPropPage::OnNMCustomdrawSliderLight)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_DELLUMP, &CDown_Clear_OCXPropPage::OnNMCustomdrawSliderDellump)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_CHECK, &CDown_Clear_OCXPropPage::OnNMCustomdrawSliderCheck)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_PLAY, &CDown_Clear_OCXPropPage::OnNMCustomdrawSliderPlay)
//	ON_BN_CLICKED(IDC_BTN_DELLUMP, &CDown_Clear_OCXPropPage::OnBnClickedBtnDellump)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_SHARPENING, &CDown_Clear_OCXPropPage::OnNMCustomdrawSliderSharpening)

	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_CONTRAST, &CDown_Clear_OCXPropPage::OnNMCustomdrawSliderContrast)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER_LIGHT, &CDown_Clear_OCXPropPage::OnNMReleasedcaptureSliderLight)
	ON_BN_CLICKED(IDC_CHECK_ANCJ, &CDown_Clear_OCXPropPage::OnBnClickedCheckAncj)
	ON_BN_CLICKED(IDC_CHECK_LG, &CDown_Clear_OCXPropPage::OnBnClickedCheckLg)
	ON_BN_CLICKED(IDC_CHECK_WY, &CDown_Clear_OCXPropPage::OnBnClickedCheckWy)
	ON_BN_CLICKED(IDC_CHECK_LCJ, &CDown_Clear_OCXPropPage::OnBnClickedCheckLcj)
	ON_BN_CLICKED(IDC_CHECK_FS, &CDown_Clear_OCXPropPage::OnBnClickedCheckFs)
	ON_BN_CLICKED(IDC_CHECK_SDJH, &CDown_Clear_OCXPropPage::OnBnClickedCheckSdjh)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CDown_Clear_OCXPropPage, "DOWNCLEAROCX.DownClearOCXPropPage.1",
	0x6437d0b5, 0x789b, 0x46ea, 0xbb, 0x9b, 0xa0, 0x89, 0xcc, 0x17, 0x6d, 0x82)


/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXPropPage::CDown_Clear_OCXPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CDown_Clear_OCXPropPage
void GetParam(AlgorithmParamX &apx,CDown_Clear_OCXPropPage* pTemp)
{

	//apx.scale = pTemp->m_nScale ; //1 -> �Ŵ��㷨;
	apx.Lightness = pTemp->m_nLight; //4  ����
	apx.Contrast = pTemp->m_nContrast;//8:  // �Աȶ�
	apx.SceneType = pTemp->m_nSceneType; //128:  ����

	apx.debolckSharpness = pTemp->m_nDelLump;// 256://ȥ��

	//apx.CalibBig = pTemp->m_nCheck; // 512: ��ͷУ��
	apx.Sharplevel = pTemp->m_nSharPening;  //1024:��

}
BOOL CDown_Clear_OCXPropPage::CDown_Clear_OCXPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_DOWN_CLEAR_OCX_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXPropPage::CDown_Clear_OCXPropPage - Constructor

CDown_Clear_OCXPropPage::CDown_Clear_OCXPropPage() :
	COlePropertyPage(IDD, IDS_DOWN_CLEAR_OCX_PPG_CAPTION)
		, m_nContrast(0)
		, m_nLight(0)
		, m_nDelLump(0)
		, m_nCheck(0)
		, m_nSharPening(0)

		, m_nColorTypeIndex(1)
		
	{
	//{{AFX_DATA_INIT(CDown_Clear_OCXPropPage)
	m_nSceneType = -1;

	m_nColorOldType = -1; 
//	m_nSceneType = -1;
	m_nSceneOldType = -1;
	m_nScale = 0;
	m_bBtnDellump= FALSE;
	m_bBtnLight = FALSE;
	m_bBtnSharpeng = FALSE;
	m_bBtnContrast = FALSE;
	m_nAlgCount =0;
	m_nColorType = -1;
	//}}AFX_DATA_INIT
	m_bIsPlaying = FALSE;
	m_bIsPause = FALSE;
	m_lLogId = -1;
	m_nType = -1;
	m_lWidth = -1;
	m_lHeight = -1; 
	IsLButtonDown=FALSE ;

	m_nAlgMask =0;

	m_hStartImageShow =  -1;

	m_lShowWidth = -1;
	m_lShowHeight = -1;
	m_hThreadHandle =0;
	m_pDownload = NULL;


// 	 m_apx.CalibBig = 5;
// 	  m_apx.Contrast = ;
	  // m_apx.debolckSharpness = 0;
// 		 m_apx.scale = ;
// 		  m_apx.SceneType = ;
// 		   m_apx.Sharplevel = ;




}


/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXPropPage::DoDataExchange - Moves data between page and properties

void CDown_Clear_OCXPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CDown_Clear_OCXPropPage)
	DDX_Control(pDX, IDC_SLIDER_SHARPENING, m_ctrSharplevel);
	DDX_Control(pDX, IDC_SLIDER_CHECK, m_ctrCalibBig);
	DDX_Control(pDX, IDC_SLIDER_DELLUMP, m_ctrdebolckSharpness);
	DDX_Control(pDX, IDC_SLIDER_LIGHT, m_ctrLightness);
	DDX_Control(pDX, IDC_SLIDER_CONTRAST, m_ctrContrast);
	DDX_Control(pDX, IDC_SLIDER_BLOWUP, m_ctrScale);
	DDX_Control(pDX, IDC_SLIDER_PLAY, m_sliderPlay);
//	DDX_Radio(pDX, IDC_RADIO_AN, m_nSceneType);
	DDX_Slider(pDX, IDC_SLIDER_BLOWUP, m_nScale);
	DDX_Radio(pDX, IDC_RADIO_FS, m_nColorType);
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
	DDX_Slider(pDX, IDC_SLIDER_CONTRAST, m_nContrast);
	DDX_Slider(pDX, IDC_SLIDER_LIGHT, m_nLight);
	DDX_Slider(pDX, IDC_SLIDER_DELLUMP, m_nDelLump);
	DDX_Slider(pDX, IDC_SLIDER_CHECK, m_nCheck);
	DDX_Slider(pDX, IDC_SLIDER_SHARPENING, m_nSharPening);
	DDX_Control(pDX, IDC_BTN_LIGHT, m_btnLight);
	DDX_Control(pDX, IDC_BTN_PALY, m_btnPlay);
	DDX_Control(pDX, IDC_BTN_OPEN, m_btnOpen);
	DDX_Control(pDX, IDC_BTN_STOP, m_btnStop);

	DDX_Control(pDX, IDC_BTN_DELLUMP, m_btnDelLump);
	DDX_Control(pDX, IDC_BTN_CONTAST, m_btnContrast);
	DDX_Control(pDX, IDC_BTN_SHARPENG, m_btnSharpening);
}


/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXPropPage message handlers

BOOL CDown_Clear_OCXPropPage::OnInitDialog() 
{
	COlePropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here

	//m_hPlayEnableBit = ::LoadBitmap(::AfxGetResourceHandle(), MAKEINTRESOURCE(IDB_BIT_PLAY_ENABLE));
	m_hPlayEnableBit = ::LoadBitmap(::AfxGetResourceHandle(), MAKEINTRESOURCE(IDB_BIT_PLAY_ENABLE));

	m_btnTest.m_bShowDisabledBitmap = FALSE;
	//m_btnSTLogo.SetBitmaps(IDB_STLOGO, RGB(255, 255, 255));
	m_btnTest.SetBitmaps(IDB_BIT_PLAY_ENABLE,RGB(0, 255, 0));


	//m_btn.SetBitmap(hBitmap);

//	hBitmap = ::LoadBitmap(::AfxGetResourceHandle(), MAKEINTRESOURCE(IDB_BIT_CONTRAST));
//	((CButton *)GetDlgItem(IDC_BTN_CONTAST))->SetBitmap(hBitmap);



	m_hPlayEnableIcon =			AfxGetApp()->LoadIcon(IDI_PLAY_ENABLE);
	m_hPlayDisableIcon =		AfxGetApp()->LoadIcon(IDI_PLAY_DISABLE);
	m_hPauseEnableIcon =		AfxGetApp()->LoadIcon(IDI_PAUSE_ENABLE);
	m_hPauseDisableIcon =		AfxGetApp()->LoadIcon(IDI_PAUSE_DISABLE);
	m_hStopEnableIcon =			AfxGetApp()->LoadIcon(IDI_STOP_ENABLE);
	m_hStopDisableIcon =		AfxGetApp()->LoadIcon(IDI_STOP_DISABLE); 
 
	m_hOpenFileEnableIcon = AfxGetApp()->LoadIcon(IDI_ICON_OPEN); 
	m_hOpenFileDisableIcon = AfxGetApp()->LoadIcon(IDI_ICON_OPEN_DISABLE);
	
	m_hLightEnableIcon = AfxGetApp()->LoadIcon(IDI_ICON_LD_ENABLE);
	m_hLightDisableIcon = AfxGetApp()->LoadIcon(IDI_ICON_LD_DISABLE);

	m_hSharpenEnableIcon = AfxGetApp()->LoadIcon(IDI_ICON_RH_ENABLE);// ��
	m_hSharpenDisableIcon = AfxGetApp()->LoadIcon(IDI_ICON_RH_DISABLE);// ��

	m_hDellumpEnableIcon = AfxGetApp()->LoadIcon(IDI_ICON_QK_ENABLE);
	m_hDellumpDisableIcon = AfxGetApp()->LoadIcon(IDI_ICON_QK_DISABLE);

	m_hContrastEnableIcon = AfxGetApp()->LoadIcon(IDI_ICON_DBD_ENABLE);
	m_hContrastDisableIcon = AfxGetApp()->LoadIcon(IDI_ICON_DBD_DISABLE);

	//((CButton *)GetDlgItem(IDC_BTN_OPEN))->SetIcon(m_hOpenFileIcon);


	SetPlayState(PLAY_NORMAL);

	GetDlgItem(IDC_STATIC_PLAY_LOCAL)->GetClientRect(m_rectVedio);
	m_rectVedioInit = m_rectVedio;
	//GetDlgItem(IDC_STATIC_PLAY_LOCAL)->GetClientRect(m_rectVedioInit);

	//��ʼ��
	m_rectTracker.m_nStyle=CRectTracker::resizeOutside|CRectTracker::dottedLine;
	m_rectTracker.m_rect.SetRect(0,0,0,0);

	m_sliderPlay.SetRange(0,100);

	// �Ŵ� 1-5
	m_ctrScale.SetRange(1,5,TRUE);
	m_ctrScale.SetPos(1);

	m_ctrContrast.SetRange(-127,127,TRUE);	//�Աȶ�
	m_ctrContrast.SetPos(0);

	m_ctrLightness.SetRange(-127,127,TRUE); 	//����
	m_ctrLightness.SetPos(0);
 
	m_ctrdebolckSharpness.SetRange(1,15,TRUE);  // ȥ��
	m_ctrdebolckSharpness.SetPos(1);
	
	m_ctrCalibBig.SetRange(1,100,TRUE);  //  ��ͷУ��
	m_ctrCalibBig.SetPos(1);

	m_ctrSharplevel.SetRange(1,99);//��
	m_ctrSharplevel.SetPos(1);
	// CG: The following block was added by the ToolTips component.
	{
		// Create the ToolTip control.
		m_tooltip.Create(this);
		m_tooltip.Activate(TRUE);

		//������ʱ��ʾ��ʾ��Ϣ��ʱ��
		m_tooltip.SetDelayTime(200);
		//������ʾ��Ϣ�ı�����ɫΪ�Ϻ�ɫ
		m_tooltip.SetTipBkColor(RGB(255,0,255));

		//���ÿؼ���ʾ��Ϣ
	//m_tooltip.AddTool(&m_btnBtn,_T("����һ����ť"));
	//	m_tooltip.AddTool(&m_editBox,_T("����һ���༭��"));

		m_tooltip.AddTool(GetDlgItem(IDC_SLIDER_BLOWUP), "�Ŵ�");
		m_tooltip.AddTool(GetDlgItem(IDC_SLIDER_CONTRAST), "�Աȶ�");
		m_tooltip.AddTool(GetDlgItem(IDC_SLIDER_LIGHT), "����");
		m_tooltip.AddTool(GetDlgItem(IDC_SLIDER_DELLUMP), "ȥ��");
		m_tooltip.AddTool(GetDlgItem(IDC_SLIDER_CHECK), "��ͷУ��");
		m_tooltip.AddTool(GetDlgItem(IDC_SLIDER_SHARPENING), "��");
		m_tooltip.AddTool(GetDlgItem(IDC_BTN_OPEN),"���ļ�");
		m_tooltip.AddTool(GetDlgItem(IDC_BTN_STOP),"ֹͣ");

		// TODO: Use one of the following forms to add controls:
		// m_tooltip.AddTool(GetDlgItem(IDC_<name>), <string-table-id>);
		// m_tooltip.AddTool(GetDlgItem(IDC_<name>), "<text>");
	}

	InitAlgBtn();
	InitSliderUi();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDown_Clear_OCXPropPage::InitAlgBtn()
{

	m_btnLight.SetIcon(m_hLightDisableIcon);
	m_btnSharpening.SetIcon(m_hSharpenDisableIcon);
	m_btnContrast.SetIcon(m_hContrastDisableIcon);
	m_btnDelLump.SetIcon(m_hDellumpDisableIcon);


}
void CDown_Clear_OCXPropPage::OnDestroy() 
{
	StopPlay();
	if(m_hThreadHandle >0)
	{
		CloseHandle(m_hThreadHandle);
	}	
	PlayM4_SetFileEndCallback(m_lPlayPort,0,0);

	// TODO: Add your message handler code here
	m_listMutex.Lock();
	list<CDownLoad *>::iterator it= m_listDown.begin();
	int i=0;
	for(;it != m_listDown.end();)
	{
		if(*it != NULL)
		{
			if(i==0)
			{
				((CDownLoad*)(*it))->Logout();
				i++;

			}
			delete (CDownLoad*)(*it);
			it= m_listDown.erase(it);

		}
		else
		{
			it++;

		}
	}
	COlePropertyPage::OnDestroy();

}	

	/************************************************************************
	 param:
		sDVRFileName     �����ļ���
		sSavedFileName   ���ص����صľ���·�� 
	return :

	 >0   �������سɹ�
	 -1   û�е�¼
	 -2   û��ѡ���ļ�
	 -3   ��������ʧ��    
	 -4   �����ļ��� 
	 -5  �����ڴ�ʧ��
	**********************************************************************/

long   CDown_Clear_OCXPropPage::DowanloadByName(LPCTSTR sDVRFileName)
{

	if(!m_bIsLogin)
	{
		return -1;
	}
#ifdef TEST
	CString strTemp;
	strTemp.Format("byname��¼ID��%d",m_lLogId);
	MessageBox( strTemp);
#endif


	CString szDownName;
	szDownName.Format("%s",sDVRFileName);
	CString szSaveName;
	int nRet = -1;
	long hHandle ;

		
	if(szDownName.IsEmpty() )
	{
		//MessageBox("���ص��ļ�������Ϊ��,����ϸ��д����!");
		nRet = -4;

	}
	CFileDialog fileDlg(FALSE);
		//�ı�Ի������
	fileDlg.m_ofn.lpstrTitle = "����Ի���";
		
	fileDlg.m_ofn.lpstrFilter = "mp4 Files(*.mp4)\0*.mp4\0\0";//"Text Files(*.avi)\0*.avi\0All Files(*.*)\0*.*\0\0";
		//����Ĭ�ϵ���չ��
	fileDlg.m_ofn.lpstrDefExt = "mp4";	
		
	if(IDOK == 	fileDlg.DoModal())
	{
		CDownLoad *pTemp = NULL;
		try
		{
			pTemp = new CDownLoad;
			CString strlogid;
			pTemp->SetLogId(m_lLogId);
		}
		catch(...)
		{
			if(pTemp == NULL)
			{
				nRet = -5;
			}
		}
		hHandle = (LONG)(pTemp);
		m_listMutex.Lock();
		m_listDown.push_back(pTemp);
		m_listMutex.Unlock();
		szSaveName = fileDlg.GetPathName();
			
		int nRet = pTemp->DowanloadByName((LPTSTR) sDVRFileName,(LPTSTR)(LPCTSTR)szSaveName);

		if(nRet == 1)
		{
			return hHandle;
		}
		return nRet;


	}
	else
	{
		nRet = -2;//û��ѡ���ļ�
	}
		
	
	

	return nRet;
}

CString   CDown_Clear_OCXPropPage::FindFile(long nChannel, NET_TIME StartTime ,NET_TIME StopTime)
{
	CString strResult;
	// TODO: Add your dispatch handler code here

	
	if( !m_bIsLogin )
	{
		MessageBox("�û�û�е�¼!");
		return "";
	}
	
	NET_TIME startTime ,stopTime;
	startTime = StartTime;
	stopTime = StopTime;
	char pBuff[1000*100];//���1000 ���ļ� 
	CString szTemp ;
#ifdef TEST
	szTemp.Format(" ͨ���� %d %d-%d-%d %d:%d:%d  --- %d-%d-%d %d:%d:%d",nChannel,startTime.dwYear,\
		startTime.dwMonth,startTime.dwDay,startTime.dwHour,startTime.dwMinute,startTime.dwSecond,\
		stopTime.dwYear,stopTime.dwMonth,stopTime.dwDay,stopTime.dwHour,stopTime.dwMinute,stopTime.dwSecond
		);
	MessageBox(szTemp);
#endif
	if(	m_pDownload->FindFile(nChannel,startTime,stopTime,pBuff,sizeof(pBuff)))
	{
		
	}
	else
	{
		return "";
		
	}
	strResult.Format("%s",pBuff);
	return strResult;
}

BOOL  CDown_Clear_OCXPropPage::LogOut()
{
	BOOL bFlag= FALSE;
	int nTmep =0;
	CDownLoad *pTemp = NULL;
	m_listMutex.Lock();
	list<CDownLoad *>::iterator it=m_listDown.begin();
	for(;it != m_listDown.end();)
	{
		pTemp = (*it);

		if(*it != NULL)
		{
			if(nTmep == 0)
				bFlag = pTemp->Logout()	;
			delete pTemp;
			it= m_listDown.erase(it);
		}
		else
		{
			it++;
		}
	}
	m_listMutex.Unlock();
	return bFlag ;
}

BOOL  CDown_Clear_OCXPropPage::LogIn(LPCTSTR sDVRIP, short wDVRPort, LPCTSTR sUserName, LPCTSTR sPassword) 
{
	// TODO: Add your dispatch handler code here
	if(m_pDownload == NULL)
	{
		
		try 
		{
			//m_pDownload = CreateInstance();
			m_pDownload = new CDownLoad;//CreateInstance();

		}
		catch(...)
		{	
			if(m_pDownload == NULL)
			{
				return FALSE;
			}
		}
		
		m_listMutex.Lock();
		m_listDown.push_back(m_pDownload);
		m_listMutex.Unlock();
	}
	int nRet =-1;
#ifdef TEST
	CString strtemp;
	strtemp.Format("%s %d %s %s ",sDVRIP,wDVRPort,sUserName,sPassword);
	MessageBox(strtemp);
#endif
	nRet = m_pDownload->LogIn((LPTSTR)sDVRIP,wDVRPort,(LPTSTR)sUserName,(LPTSTR)sPassword);
	if(nRet == 1)
	{
		m_bIsLogin= TRUE;
		m_pDownload->GetLogId(&m_lLogId);
	}
	else
	{
		m_bIsLogin = FALSE;

	}
	return m_bIsLogin;
}

int   CDown_Clear_OCXPropPage::FindHandleAndGetPos(LONG hHandle)
{
	m_listMutex.Lock();
	list<CDownLoad *>::iterator it=m_listDown.begin();
	for(;it != m_listDown.end();it++)
	{
		if((LONG)(*it)== hHandle )
		{
			int nRet = (*it)->GetDownloadPos();
			return nRet;
		}
	}
	m_listMutex.Unlock();
	return -1;
	
}
int   CDown_Clear_OCXPropPage::FindHandleAndStop(LONG hHandle)
{
	m_listMutex.Lock();
	list<CDownLoad *>::iterator it=m_listDown.begin();
	for(;it != m_listDown.end();it++)
	{
		if((LONG)(*it)== hHandle )
		{
			int nRet = (*it)->StopDownLoad();
			m_listMutex.Unlock();
			return nRet;
		}
	}
	m_listMutex.Unlock();
	return 0;
}


short  CDown_Clear_OCXPropPage::GetDownloadPos(long hHandle) 
{
	// TODO: Add your dispatch handler code here
	//int nRet = FindHandleAndGetPos(hHandle);
	//CDownLoad *pTemp = (CDownLoad*)(hHandle);
	//return pTemp->GetDownloadPos();
	
	m_listMutex.Lock();
	list<CDownLoad *>::iterator it=m_listDown.begin();
	for(;it != m_listDown.end();it++)
	{
		if((LONG)(*it)== hHandle )
		{
			int nRet = (*it)->GetDownloadPos();
			m_listMutex.Unlock();
			return nRet;
		}
	}
	m_listMutex.Unlock();




// 	if( nRet >= 0)
// 	{
// 		return nRet;
// 
// 		/*
// 		CDownLoad *pTemp = (CDownLoad*)(hHandle);
// 		return pTemp->GetDownloadPos();
// 		*/
// 	}
	return -1;
}
// EnhanceRenderLib.lib 
	/************************************************************************

	return :
	>0   �������سɹ�
	-1  û�е�¼
	-2; �û�û��ѡ���ļ�
	-3  ��������ʧ��  
                                                              
	************************************************************************/

long  CDown_Clear_OCXPropPage::DowanloadByTime(long lChannel,NET_TIME StartTime ,NET_TIME StopTime, LONG hHandle,short nType) 
{
	// TODO: Add your dispatch handler code here
	
	if( !m_bIsLogin )
	{
		return -1;
	}
	CString szSaveName;
	
	
	NET_TIME startTime = StartTime ,stopTime =  StopTime;
	
	CFileDialog fileDlg(FALSE);
	//�ı�Ի������
	fileDlg.m_ofn.lpstrTitle = "����Ի���";
	
	fileDlg.m_ofn.lpstrFilter = "mp4 Files(*.mp4)\0*.mp4\0\0";//"Text Files(*.avi)\0*.avi\0All Files(*.*)\0*.*\0\0";
	//����Ĭ�ϵ���չ��
	fileDlg.m_ofn.lpstrDefExt = "avi";	
	
	if(IDOK == 	fileDlg.DoModal())
	{
		CDownLoad *pTemp = NULL;
		try
		{
			pTemp = new CDownLoad;
			pTemp->SetLogId(m_lLogId);

		}
		catch(...)
		{
			if(pTemp == NULL)
			{
				return -5;  //�ڴ����ʧ��
			}
		}
		hHandle = (LONG)(pTemp);

		m_listMutex.Lock();
		m_listDown.push_back(pTemp );
		m_listMutex.Unlock();
		
		szSaveName = fileDlg.GetPathName();
		if( 1 == pTemp->DowanloadByTime(lChannel,startTime,stopTime,(LPTSTR)(LPCTSTR)szSaveName))
		{
			return	hHandle;
		}
		else
		{
			return -1;

		}
	}
	else
	{
		return  -2;//û��ѡ���ļ�
	}
	
}

 CMutex  g_hMutex;


 
void YUV420p_to_RGB24(unsigned char *yuv420[3], unsigned char *rgb24, int width, int height) 
{
	//  int begin = GetTickCount();
	int R,G,B,Y,U,V;
	int x,y;
	int nWidth = width>>1; //ɫ���źſ���
	for (y=0;y<height;y++)
	{
		for (x=0;x<width;x++)
		{
			Y = *(yuv420[0] + y*width + x);
			U = *(yuv420[1] + ((y>>1)*nWidth) + (x>>1));
			V = *(yuv420[2] + ((y>>1)*nWidth) + (x>>1));
			R = Y + 1.402*(V-128);
			G = Y - 0.34414*(U-128) - 0.71414*(V-128);
			B = Y + 1.772*(U-128);
			
			//��ֹԽ��
			if (R>255)R=255;
			if (R<0)R=0;
			if (G>255)G=255;
			if (G<0)G=0;
			if (B>255)B=255;
			if (B<0)B=0;
			
			*(rgb24 + ((height-y-1)*width + x)*3) = B;
			*(rgb24 + ((height-y-1)*width + x)*3 + 1) = G;
			*(rgb24 + ((height-y-1)*width + x)*3 + 2) = R;
			//    *(rgb24 + (y*width + x)*3) = B;
			//    *(rgb24 + (y*width + x)*3 + 1) = G;
			//    *(rgb24 + (y*width + x)*3 + 2) = R;   
		}
	}
}


void RGB2YUV(unsigned char* RgbBuf, int nWidth, int nHeight, unsigned char* yuvBuf, unsigned long *len)
{
    int i, j;
    unsigned char*bufY, *bufU, *bufV, *bufRGB,*bufYuv;
    memset(yuvBuf,0,(unsigned int )*len);
    bufY = yuvBuf;
    bufV = yuvBuf + nWidth * nHeight;
    bufU = bufV + (nWidth * nHeight* 1/4);
    *len = 0; 
    unsigned char y, u, v, r, g, b,testu,testv;
    unsigned int ylen = nWidth * nHeight;
    unsigned int ulen = (nWidth * nHeight)/4;
    unsigned int vlen = (nWidth * nHeight)/4; 
    for (j = 0; j<nHeight;j++)
    {
        bufRGB = RgbBuf + nWidth * (nHeight - 1 - j) * 3 ;
        for (i = 0;i<nWidth;i++)
        {
            int pos = nWidth * i + j;
            r = *(bufRGB++);
            g = *(bufRGB++);
            b = *(bufRGB++);
            y = (unsigned char)( ( 66 * r + 129 * g +  25 * b + 128) >> 8) + 16  ;          
            u = (unsigned char)( ( -38 * r -  74 * g + 112 * b + 128) >> 8) + 128 ;          
            v = (unsigned char)( ( 112 * r -  94 * g -  18 * b + 128) >> 8) + 128 ;

            *(bufY++) = max( 0, min((int)y, 255 ));
            if (j%2==0&&i%2 ==0)
            {
                if (u>255)
                {
                    u=255;
                }
                if (u<0)
                {
                    u = 0;
                }
                *(bufU++) =u;
                //��u����
            }
            else
            {
                //��v����
                if (i%2==0)
                {
                    if (v>255)
                    {
                        v = 255;
                    }
                    if (v<0)
                    {
                        v = 0;
                    }
                    *(bufV++) =v;
                }
            }
        }
    }
    *len = nWidth * nHeight+(nWidth * nHeight)/2;
    return;
}
#ifdef TEST
FILE * g_pFile = fopen("c:\\yuv.dat","wb");

#endif
void __stdcall DecCBFun(long nPort,char* pBuf,long nSize,\
						FRAME_INFO* pFrameInfo, long nUser, long nReserved2)  //MP4�Ľ���
{
#ifdef TEST

	if(g_pFile != NULL)
	{
		int nRet = fwrite(pBuf,nSize,1,g_pFile);
		if(nRet == 1)
		{
			
		}
		else
		{
			AfxMessageBox("д�ļ�����!");

		}
	}
	else
	{
		AfxMessageBox("�ļ�ָ�����!");

	}
#endif
	CDown_Clear_OCXPropPage *pTemp = (CDown_Clear_OCXPropPage*)nUser;
//	T_UYVY
	DWORD nTempTimeStart;
	DWORD nTempTimeEnd;
	DWORD nTempCount;

	nTempTimeStart = GetTickCount();	

	if(pTemp->m_lWidth != pFrameInfo->nWidth || pTemp->m_lHeight != pFrameInfo->nHeight )
	{
		pTemp->m_lWidth = pFrameInfo->nWidth;		
		pTemp->m_lHeight = pFrameInfo->nHeight;
		::SendMessage(pTemp->GetSafeHwnd(),WM_DECSHOW,2,0);//����������ʾ����
		::SendMessage(pTemp->GetSafeHwnd(),WM_DECSHOW,STARTIMAGESHOW,0);
		VSNET_ClientShowSetWnd(pTemp->m_hStartImageShow,pTemp->GetDlgItem(IDC_STATIC_PLAY_LOCAL)->GetSafeHwnd());
		pTemp->m_nFrameTime = 1000/pFrameInfo->nFrameRate;

	}
	int nFrameTime = pTemp->m_nFrameTime;

 	TRACE("buf : size :%d",nSize);

	 // ָ��mask��ȷ��Ҫ���õ��㷨�����ö���㷨����maskֵ��򼴿�
	 // ���� ��ɫ��maskΪ 2�� ���ȵ�����maskΪ 4 ͬʱ���������㷨�ĵ�mask ��Ϊ  ��2|4��
//mask:  1 -> �Ŵ��㷨;  2-> ��ɫ; 4->����; 8->�Աȶ�;  16->ɫ������ ; 128->��ǿ; 256-> ȥ��; 512-> ��ͷУ��; 1024-> �� ;
	JSSJROI* roi = new JSSJROI;
	JSSJ_SFrameData* src = new JSSJ_SFrameData;
	AlgorithmParamX apx;//= new AlgorithmParamX;


	int mask = pTemp ->m_nAlgMask;
	GetParam(apx,pTemp);

	 // Ϊ��Ҫ�������㷨ָ�����������maskָʾû�е��ø��㷨������㷨���ڵĲ������ᱻ���ʵ�
//	 AlgorithmParamX apx(pTemp->m_apx);//= new AlgorithmParamX;

	 // ָ���㷨���õ�ROI����
	 int height = pTemp->m_lHeight;
	 int width = pTemp->m_lWidth;

	 roi->x = 0;
	 roi->y = 0;
	 roi->height = height;
	 roi->width =  width;
	 
	 // Ϊ�㷨׼����������

	 src->dwChannel = 3;
	 src->dwImH = height ;
	 src->dwImW = width;
	 src->dwStride = (width * 3 + 3) >> 2 << 2;	
	//mask:  1 -> �Ŵ��㷨;  2-> ��ɫ; 4->����; 8->�Աȶ�;  16->ɫ������ ; 128->��ǿ; 256-> ȥ��; 512-> ��ͷУ��; 1024-> �� ;
	
	 
	 BYTE *pY = NULL,*pV = NULL,*pU = NULL;
	 int nTempSize = width*height;
	 int nPos = nTempSize;
	 
     pY = (BYTE *)pBuf;

	 pU = pY + nPos;
	 nTempSize = (width*height)/4;
	 nPos = nTempSize;
	 pV = pU + nPos;

	 unsigned char *yuv420[3] ;
	 yuv420[0]= pY;
	 yuv420[1]= pU;
	 yuv420[2]= pV;

	 unsigned char *rgb24 = new unsigned char [width*height*10];

	 YUV420p_to_RGB24(yuv420,rgb24 , width, height) ;  

	src->pubyData = (unsigned char *)rgb24;
	unsigned char* OutData;                                                                         // ����������� yuv12     ת��ΪRBG
    int nRet = 	Enhance_Render_Engine(mask, src,&OutData, roi,  &apx);  //
	                                                                     // �㷨�����rgb24  ��ʾsdk��yuv ������Ҫ rgb ת��Ϊ yuv
	if(OutData == NULL)
	{
		if(IDYES == AfxMessageBox("�������������Ƿ�����˼��ܹ����Ƿ������",MB_YESNO|MB_ICONQUESTION))
		{
			Sleep(1000);

		}
		else
		{
			::PostMessage(pTemp->GetSafeHwnd(),WM_DECSHOW,MP4FAILED,0); //����ֹͣ���ŵ���Ϣ
			//pTemp->StopPlay();  // 
		}
	}
	else
	{
		unsigned char* yuvBuf = new unsigned char[ nSize*2];
		unsigned long len = nSize ;

		RGB2YUV(OutData, width, height , yuvBuf, &len);
		*pY = NULL;
		*pV = NULL;
		*pU = NULL;
		nTempSize = width*height;
		nPos = nTempSize;
		pY = (BYTE *)yuvBuf;
		//	pY = (BYTE *)pBuf;
		//	pY = (BYTE *)OutData;
		///�޸� uv λ��
		pU = pY + nPos;
		nTempSize = (width*height)/4;
		nPos = nTempSize;
		pV = pU + nPos;

		//	VSNET_ClientShowImageShow(pTemp->m_hStartImageShow,	pY,	pU,	pV,	width,	width/2	);
		VSNET_ClientShowImageShow(pTemp->m_hStartImageShow,	pY,	pV,	pU,	width,	width/2	);
		VSNET_ClientRefreshImageShow(pTemp->m_hStartImageShow);

		nTempTimeEnd = GetTickCount();
		nTempCount = nTempTimeEnd- nTempTimeStart;
		if(nTempCount < nFrameTime)
		{
			Sleep(nFrameTime-nTempCount);

		}
		else if(nTempCount >= nFrameTime)
		{

		}
		Enhance_Render_FreeRlt(&OutData);
		delete [] yuvBuf;
	}
	
	delete roi ;
	delete src ;
	delete [] rgb24;
}

void YUVRotate90(BYTE *des,BYTE *src,int width,int height) 
{ 
	int i=0,j=0,n=0; 
	int hw=width/2,hh=height/2; 
	for(j=width;j>0;j--) 
		for(i=0;i<height;i++) 
		{ 
			des[n++] = src[width*i+j]; 
		} 

		unsigned char *ptmp = src+width*height; 
		for(j=hw;j>0;j--) 
			for(i=0;i<hh;i++) 
			{ 
				des[n++] = ptmp[hw*i+j]; 
			} 

			ptmp = src+width*height*5/4; 
			for(j=hw;j>0;j--) 
				for(i=0;i<hh;i++) 
				{ 
					des[n++] = ptmp[hw*i+j]; 
				}
} 

void RGBRotate90(BYTE *des,BYTE *src,int width,int height) 
{ 

    if ((!des)||(!src)) 
    { 
        return; 
    } 
       
    int n = 0; 
    int linesize = width*3; 
    int i,j; 
    for (j=width;j>0;j--) 
        for (i=0;i<height;i++) 
        { 
            memcpy(&des[n],&src[linesize*i+j*3-3],3); 
            n+=3; 
        } 

    /* 

    if((!des)||(!src)) 
    { 
        return; 
    } 
    int n = 0; 
    int linesize = width*3; 
    int i; 
    int j; 
    // ˳ʱ�����ת���㷨 
    for(j = 0;j < width ;j++) 
        for(i= height;i>0;i--) 
        { 
            memcpy(&des[n],&src[linesize*(i-1)+j*3-3],3); 
            n+=3; 
        } 
    */ 
} 




#define PI 3.1415926

// ˮƽ��ֵ
UINT8 InterpolateHoriz(UINT8 *pImg, float ii, float jj, INT32 Width)
{
	INT32 a, b;
	INT32 i = (INT32)ii, j = (INT32)jj;
	float rate = ii - i;

	a = pImg[i + j * Width];
	b = pImg[i + 1 + j * Width];

	return (UINT8)(b * rate + a * (1.0f - rate));
}


// ���ͼ����������������ת0~90�ȵ���Ƶ����
void RotateInside(UINT8 *pImg, UINT8 *pSeqOut, INT32 Width, INT32 Height, float Angle)
{
	INT32 i, j, k;
	float theta;
	INT32 wOut;
	INT32 w, h, plane;

	// ÿת��һ���Ƕȣ����һ֡
	for (theta = 0, k = 0; theta < 90.01f + Angle; theta += Angle, k++)
	{

		// YUV 3 ƽ��
		for (plane = 0; plane < 3; plane++)
		{
			float rate = cos(theta / 90 * PI / 2);
			UINT8 *pPlane, *pPlaneIn;
			if (plane > 0)
			{
				w = Width / 2;
				h = Height / 2;
				pPlane = pSeqOut + k * Width * Height * 3 / 2 + Width * Height + (plane - 1) * Width * Height / 4;
				pPlaneIn = pImg + Width * Height + (plane - 1) * Width * Height / 4;
			}
			else 			
			{
				w = Width;
				h = Height;
				pPlane = pSeqOut + k * Width * Height * 3 / 2;
				pPlaneIn = pImg;
			}

			// ���ͼ��ʵ�ʿ��ȡ����߶���ԭͼ��ͬ��
			wOut = (INT32)(w * rate + 0.5f);

			for (j = 0; j < h; j++)
			{
				INT32 margin = (w - wOut + 1) / 2;
				UINT8 *pOut = pPlane + j * w;
				float center = (w - 1) / 2.0f;

				// �����߽�
				for (i = 0; i < margin; i++)
				{
					*pOut++ = 0;
				}

				// ��Ч����
				for (i = margin; i < margin + wOut; i++)
				{
					float ii, jj;

					// ��Ӧ��ԭͼ�е�����
					ii = center + (i - center) / rate;

					// ��ֵ
					*pOut++ = InterpolateHoriz(pPlaneIn, ii, j, w);

				}

				// ����ұ߽�
				for (;i < w; i++)
				{
					*pOut++ = 0;
				}

			}

		}

	}

}

void RGBRotate180(int w,int h,int channel,unsigned char *pRGB24)
{
	int tempw=w*channel/8;
	int halfh=h/2;
	unsigned char *RGBW=(unsigned char *)calloc(tempw+32,sizeof(unsigned char));
	int y;

	for(y=0; y <= halfh; y++)
	{
		memcpy(RGBW,&pRGB24[y*tempw],tempw);
		memcpy(&pRGB24[y*tempw],&pRGB24[(h-1-y)*tempw],tempw);
		memcpy(&pRGB24[(h-1-y)*tempw],RGBW,tempw);
	}

	free(RGBW);
}

DWORD WINAPI  AviDecAndShow(LPVOID lpParameter  )
{
	CDown_Clear_OCXPropPage* pTemp = (CDown_Clear_OCXPropPage *)lpParameter;
	int mask = -1;// pTemp->m_nAlgMask;
	LONG hStartImageShow;

	// ������Ƶ
    CvCapture *handle = cvCaptureFromFile(pTemp->m_szFileName);
	if (handle == NULL)
	{
		AfxMessageBox(pTemp->m_szFileName);

		AfxMessageBox("���ļ�ʧ�ܣ�");
		pTemp->m_bIsPlaying = FALSE;
		SendMessage(pTemp->GetSafeHwnd(),WM_DECSHOW,DECFAILED,0);
		return FALSE;
	}

    int framecount = cvGetCaptureProperty(handle, CV_CAP_PROP_FRAME_COUNT);
    // �ж���Ƶ��֡��
	if (framecount < 1)
	{
		pTemp->m_bIsPlaying = FALSE;
		SendMessage(pTemp->GetSafeHwnd(),WM_DECSHOW,DECFAILED,0);
		return FALSE;
	}

	SendMessage(pTemp->GetSafeHwnd(),WM_DECSHOW,SETRANGE,framecount);

    int width =  pTemp->m_lWidth = cvGetCaptureProperty(handle, CV_CAP_PROP_FRAME_WIDTH);
    int height = pTemp->m_lHeight = cvGetCaptureProperty(handle, CV_CAP_PROP_FRAME_HEIGHT);
	HWND hPlayWnd =pTemp->GetDlgItem(IDC_STATIC_PLAY_LOCAL)->GetSafeHwnd();

	
	
	//pTemp->m_hStartImageShow =  VSNET_ClientStartImageShow( hPlayWnd,pTemp->m_lShowWidth ,pTemp->m_lShowHeight);

	pTemp->m_hStartImageShow =  VSNET_ClientStartImageShow( hPlayWnd,width ,height);
	hStartImageShow =  pTemp->m_hStartImageShow;
	int nRet = VSNET_ClientShowSetWnd(hStartImageShow,hPlayWnd );
	::SendMessage(pTemp->GetSafeHwnd(),WM_DECSHOW,2,0); // ʹ��ʾ�Ĵ��ڵ�������Ӧ�ı���
	
	
	int ic = 0;

	AlgorithmParamX apx;
	//int mask =-1;// = pTemp ->m_nAlgMask;

	IplImage* img = cvCreateImageHeader(cvSize(width, height), 8, 3);

    // Ϊ�㷨׼����������
	JSSJ_SFrameData* src = new JSSJ_SFrameData;
	src->dwChannel = 3;
	src->dwImH = height;
	src->dwImW = width;
	src->dwStride = (width * 3 + 3) >> 2 << 2;

	JSSJROI* roi = new JSSJROI;
	roi->x = 0;
	roi->y = 0;
	roi->height = height;
	roi->width =  width;

	/////////////////////
	//д����Ƶ ��2�ַ�����һ����CV�Դ�����֧��X264��һ����VFW���ӿ���H264��Ҳ֧��1080P
	double fps = cvGetCaptureProperty( handle, CV_CAP_PROP_FPS );//CV_CAP_PROP_FPS ֡��
	
	
	int nFrameTime = 1000/fps;
	DWORD nTempCount = 0,nTempTimeEnd = 0;
	DWORD nTempTime =0;

	unsigned char* yuvBuf = new unsigned char[width*height*10];//imgx->imageSize

	while (ic < framecount)
	{
		//Sleep( 1000/fps);
		SendMessage(pTemp->GetSafeHwnd(),WM_DECSHOW,SETPOS,ic);
		//handle->set(CV_CAP_PROP_POS_FRAMES, 10) ;int framecount = cvGetCaptureProperty(handle, CV_CAP_PROP_FRAME_COUNT); 
		mask = pTemp ->m_nAlgMask;

		//apx = pTemp->m_apx;
	    GetParam(apx,pTemp);

		nTempTime = GetTickCount();

		if(!pTemp->m_bIsPlaying)
		{
			pTemp->m_bIsPlaying = FALSE;
			break;//
		}

        // data Ϊbgr��ʽ
        IplImage* imgx = cvQueryFrame(handle);
		unsigned char* data = (unsigned char*)imgx->imageData;

		ic++;
		src->pubyData = data;	
		unsigned char* OutData = NULL ;
		
		unsigned long len = imgx->imageSize;
	
		try
		{
		   // �����㷨	
			Enhance_Render_Engine(mask, src, &OutData,  roi, &apx);
			if(OutData == NULL)  //һ���������Ϊ���ܹ�û�в����ԭ��
			{
				if(IDYES == AfxMessageBox("�������������Ƿ�����˼��ܹ����Ƿ������",MB_YESNO|MB_ICONQUESTION))
				{
					Sleep(1000);

					continue;
				}
				else
				{
				
					break;
				}

			}
			RGBRotate180(width,height,24,OutData);
			RGB2YUV(OutData, width, height , yuvBuf, &len);

		}
		catch (...)
		{ 
			AfxMessageBox("�ļ�����");
			break;
		}
		BYTE *pY = NULL,*pV = NULL,*pU = NULL;
		int nTempSize = width*height;
		int nPos = nTempSize;

		pY = (BYTE *)yuvBuf;
		//pY = (BYTE *)data;
		//  pY = (BYTE *)OutData;
		pU = pY + nPos;	
		nTempSize = (width*height)/4;
		nPos = nTempSize;
		pV = pU + nPos;
		//VSNET_ClientShowImageShow(hStartImageShow,tran_frm_buffer,tran_u_buffer,tran_v_buffer,	width,	width/2	);
		VSNET_ClientShowImageShow(hStartImageShow,	pY,	pU,	pV,	width,	width/2	);

		::SendMessage(pTemp->GetSafeHwnd(),WM_DECSHOW,1,0);
		//VSNET_ClientRefreshImageShow(m_hStartImageShow);
		try
		{
			Enhance_Render_FreeRlt(&OutData);
		}
		catch(...)
		{
			AfxMessageBox("�ͷ��ڴ�ʧ�ܣ�");
			break;
		}
		
		nTempTimeEnd = GetTickCount();
		nTempCount = nTempTimeEnd-nTempTime ;

		if(nTempCount < nFrameTime)
		{
			Sleep(nFrameTime-nTempCount);

		}
		else if(nTempCount >= nFrameTime)
		{
			//Sleep(nFrameTime - nTempCount);

		}

	}

	pTemp->m_bIsPlaying = FALSE;
	pTemp->StopPlay();

	delete src;
	delete roi ;
	delete[] yuvBuf;

	SendMessage(pTemp->GetSafeHwnd(),WM_DECSHOW,SETPOS,ic);
	cvReleaseImageHeader(&img);
    cvReleaseCapture(&handle);
	return TRUE;

}
// void CALLBACK funEncChange(long nPort,long nUser)
// {
// 	CDown_Clear_OCXPropPage* pTemp = (CDown_Clear_OCXPropPage*)nUser;
// 
// 	PlayM4_GetPictureSize(pTemp->m_lPlayPort,&pTemp->m_lWidth,&pTemp->m_lHeight);
// 	return ;
// }

void CALLBACK FileEndCallback(long nPort, void *pUser)// mp4 �ļ�������ɻص�
{	
	CDown_Clear_OCXPropPage* pTemp = (CDown_Clear_OCXPropPage*)pUser;
	pTemp->StopPlay();

}

BOOL CDown_Clear_OCXPropPage::Play(int nType)
{

	if(m_bIsPlaying)  // // �޸�
	{
		StopPlay();
	}
	CString FileName;
	HWND hPlayWnd;
	if(m_szFileName.IsEmpty())
	{
		MessageBox("�����ļ�Ϊ�գ��������ò����ļ�");
		return FALSE;
	}
	hPlayWnd = GetDlgItem(IDC_STATIC_PLAY_LOCAL)->GetSafeHwnd();
	if(m_nType == 1) // ����MP4
	{
		if(!PlayM4_GetPort(&m_lPlayPort))
		{
			MessageBox("��ȡͨ����ʧ��!");
			return FALSE;
		}
	
		//���ļ�
		if(!PlayM4_OpenFile(m_lPlayPort,(LPTSTR)(LPCTSTR)m_szFileName))
		{
			MessageBox("���ļ�ʧ��!");
			return FALSE;
		}

		//����

		if(!PlayM4_Play(m_lPlayPort,0))
		{
			MessageBox("����ʧ��!");
			return FALSE;
		}
	//	PlayM4_SetEncTypeChangeCallBack (m_lPlayPort,funEncChange,(long)this);
		PlayM4_SetFileEndCallback(m_lPlayPort,FileEndCallback,this);

		m_TotalTime = PlayM4_GetFileTime(m_lPlayPort); 
		m_TotalFrames = PlayM4_GetFileTotalFrames(m_lPlayPort);
		SetTimer(LOCAL_PLAY_STATE,500,NULL);
		m_bIsPlaying = TRUE;

		SetPlayState(PLAY_PLAY);

		MP4Dec();
	}
	//��ȡ����ͨ����
    
	if(m_nType == 2 )//avi
	{

		m_bIsPlaying = TRUE;
		if(m_hThreadHandle >0)
		{
			CloseHandle(m_hThreadHandle);
		}
		m_hThreadHandle = CreateThread(NULL,1024*10,AviDecAndShow,this,0,0);
	}

	/*
	TRACE("%d------%d\n",m_rectVedio.right-m_rectVedio.left,m_rectVedio.bottom-m_rectVedio.top);
	TRACE("width = %d,w rate = %f-m_lWidth/fWidthRate= %d-----------,\
		height = %d rate =%f---int((float)m_lHeight/fHeightRate= %d-\n",\
		m_lWidth,fWidthRate,int(((float)m_lWidth)/fWidthRate),m_lHeight,fHeightRate,(int)(((float)m_lHeight)/fHeightRate));
//	GetDlgItem(IDC_STATIC_PLAY_LOCAL)->MoveWindow(m_rectVedio);

*/

	return TRUE;
}

void CDown_Clear_OCXPropPage::MP4Dec()
{
	if(m_nType==1) // mp4  �ú����Ľ���
	{
		PlayM4_SetDecCBStream(m_lPlayPort,1);
		PlayM4_SetDecodeFrameType(m_lPlayPort,0 ); // 0 ��������
		//	PlayM4_SetDecCallBack(m_lPlayPort,&DecCBFun);
	
		PlayM4_SetDecCallBackMend(m_lPlayPort,DecCBFun,(LONG)this);
	}
	else
	{
		AfxMessageBox("����ʧ�ܣ�����������ļ��ĸ�ʽ�Ƿ���ȷ��");
	}
}

void CDown_Clear_OCXPropPage::SetPlayState(int iState)
{
	CButton *pButton;
    switch(iState)
	{
	case PLAY_PLAY:  // ���ڲ���

		m_btnPlay.SetIcon(m_hPauseEnableIcon);
		m_btnPlay.EnableWindow(TRUE);

		m_btnStop.SetIcon(m_hStopEnableIcon);
		m_btnStop.EnableWindow(TRUE);

		m_btnOpen.SetIcon(m_hOpenFileDisableIcon);
		m_btnOpen.EnableWindow(FALSE);

		break;
		
	case PLAY_STOP:
			
		m_btnStop.SetIcon(m_hStopDisableIcon);
		m_btnStop.EnableWindow(FALSE);

		m_btnOpen.SetIcon(m_hOpenFileEnableIcon);
		m_btnOpen.EnableWindow(TRUE);

		m_btnPlay.SetIcon(m_hPlayDisableIcon);
		m_btnPlay.EnableWindow(FALSE);

		break;
	case PLAY_NORMAL:

		m_btnPlay.SetIcon(m_hPlayDisableIcon);
	//	m_btnPlay.SetFlat(FALSE);

		m_btnPlay.EnableWindow(FALSE);

		m_btnOpen.SetIcon(m_hOpenFileEnableIcon);
		m_btnOpen.EnableWindow(TRUE);
		
		m_btnStop.SetIcon(m_hStopDisableIcon);
		m_btnStop.EnableWindow(FALSE);
		
		break;
	case PLAY_PAUSE:

		m_btnPlay.SetIcon(m_hPlayEnableIcon);
		m_btnPlay.EnableWindow(TRUE);

		m_btnOpen.SetIcon(m_hOpenFileDisableIcon);
		m_btnOpen.EnableWindow(FALSE);
		
		m_btnStop.SetIcon(m_hStopEnableIcon);
		m_btnStop.EnableWindow(TRUE);

		break;
	case PLAY_READY:
		m_btnPlay.SetIcon(m_hPlayEnableIcon);
		m_btnPlay.EnableWindow(TRUE);

		m_btnOpen.SetIcon(m_hOpenFileEnableIcon);
		m_btnOpen.EnableWindow(TRUE);

		m_btnStop.SetIcon(m_hStopDisableIcon);
		m_btnStop.EnableWindow(FALSE);
		break;
	case PLAY_FAST:
		break;
	case PLAY_SLOW:
		break;
	default:
		break;
	}
}

void CDown_Clear_OCXPropPage::SetPlayFileName(CString szFileName)
{
	if(szFileName.IsEmpty())
	{
		AfxMessageBox("�����ļ�����Ϊ��!");
		return;
	}
	m_szFileName= szFileName;

}

BOOL CDown_Clear_OCXPropPage::StopDownLoad(long hHandle) 
{
		
	if(FindHandleAndStop(hHandle))
	{
		/*
		CDownLoad* pTemp = (CDownLoad*)(hHandle);
		int nRet = 1 ;
		if(pTemp->GetDownloadPos() != 100)
		{
			nRet = pTemp->StopDownLoad();
		}*/

		m_listMutex.Lock();
		list<CDownLoad *>::iterator it=m_listDown.begin();
		for(;it != m_listDown.end();)
		{
			if(LONG(*it)== hHandle )
			{
				delete *it;
				it=m_listDown.erase(it);
			}
			else
			{
				it++;

			}
		}
		m_listMutex.Unlock();


		return TRUE;
	}
	else
	{
		return FALSE;// û����������
	}
}

void CDown_Clear_OCXPropPage::OnBtnPaly() 
{
	// TODO: Add your control notification handler code here
	if(m_bIsPlaying)   
	{
		if(m_nType == 1)  // mp4 �ļ�
		{
			if(m_bIsPause)  //resatrt
			{

				PlayM4_Pause(m_lPlayPort,FALSE);
				m_bIsPause = FALSE;
				SetPlayState(PLAY_PLAY);

			}
			else            //pause
			{
				PlayM4_Pause(m_lPlayPort,TRUE);
				m_bIsPause = TRUE;
				SetPlayState(PLAY_PAUSE);
			}
		}
		else if(m_nType == 2)
		{
			if(m_bIsPause)  //resatrt
			{
				//PlayM4_Pause(m_lPlayPort,FALSE);

				ResumeThread(m_hThreadHandle);

				m_bIsPause = FALSE;
				SetPlayState(PLAY_PLAY);

			}
			else            //pause
			{
				//PlayM4_Pause(m_lPlayPort,TRUE);
				SuspendThread(m_hThreadHandle);

				m_bIsPause = TRUE;
				SetPlayState(PLAY_PAUSE);
			}
		}
		
	}
	else                //start play
	{
		if(m_nType == 1) // mp4
		{
			if(Play(m_nType))
			{
				m_sliderPlay.SetRange(0,100);
				m_bIsPlaying = TRUE;
				SetPlayState(PLAY_PLAY);
			}
			else
			{
				SetPlayState(PLAY_STOP);
			}

		}
		else if(m_nType == 2)
		{
			Play(m_nType);	  
			m_bIsPlaying = TRUE;
			SetPlayState(PLAY_PLAY);
		}

		
	}
}
void CDown_Clear_OCXPropPage::StopPlay()
{
	if(m_bIsPlaying)
	{
		m_bIsPlaying = FALSE;
		m_bIsPause = FALSE;
		m_sliderPlay.SetPos(0);
		if(m_nType == 1 )
		{
			PlayM4_Stop(m_lPlayPort);
			PlayM4_CloseFile(m_lPlayPort);
			PlayM4_FreePort(m_lPlayPort);
			KillTimer(LOCAL_PLAY_STATE);

			
		}
		else if(m_nType == 2) // avi �ļ���stop
		{

		//	TerminateThread(m_hThreadHandle,0);
			WaitForSingleObject(m_hThreadHandle,2000);

			/*SetPlayState(PLAY_STOP);*/
		}

		
	}
	SetPlayState(PLAY_STOP);
} 
void CDown_Clear_OCXPropPage::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == LOCAL_PLAY_STATE)
	{
		DWORD CurTime = PlayM4_GetPlayedTime(m_lPlayPort);
		DWORD CurFrame = PlayM4_GetPlayedFrames(m_lPlayPort);
		

		float fPos = PlayM4_GetPlayPos(m_lPlayPort);
		if(fPos>=(1-0.001) && fPos<=(1+0.001))
		{
            StopPlay();
			KillTimer(LOCAL_PLAY_STATE);

	
			return;
		}
		int iPos = fPos*100;
		m_sliderPlay.SetPos(iPos);			
		return;
	}
	
	COlePropertyPage::OnTimer(nIDEvent);
}

void CDown_Clear_OCXPropPage::OnBtnStop() 
{
	// TODO: Add your control notification handler code here
	StopPlay();
	
}

void CDown_Clear_OCXPropPage::OnOutofmemorySliderPlay(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CDown_Clear_OCXPropPage::OnReleasedcaptureSliderPlay(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	if(m_bIsPlaying)
	{
		if(m_nType == 1)
		{
			int pos = m_sliderPlay.GetPos();
			if(pos >= 0)
			{
				float fRelativePos = (float)pos/100;
				PlayM4_SetPlayPos(m_lPlayPort,fRelativePos);
			}
		}

	}
	*pResult = 0;
}

void CDown_Clear_OCXPropPage::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	/////////////////////////////////
	/*

	if(IsInVedio(point))
	{
		//�������λ�ò���ѡ�������ڣ�����һ����ѡ��
		
		Invalidate(TRUE);
		if(m_rectTracker.HitTest(point)<0)
		{
			IsLButtonDown=TRUE;
			CRectTracker temp;
			temp.TrackRubberBand(this,point,TRUE);
			//	temp.TrackRubberBand(GetDlgItem(IDC_STATIC_VEDIO),point,TRUE);
			temp.m_rect.NormalizeRect();
			
			//��꣨����ѡ����ʼλ��
			pt_start=point;
			//��꣨����ѡ�򣩽���λ��
			GetCursorPos(&pt_end);
			this->SendMessage(WM_LBUTTONUP,NULL,NULL);
		}
		//��������ѡ���С��λ��
		else
		{
			m_rectTracker.Track(this,point,TRUE);
			m_rectTracker.m_rect.NormalizeRect();
			this->OnPaint();
			m_bInRect = TRUE;
			
			this->SendMessage(WM_MOUSEMOVE,NULL,NULL);
			
			
		}		
	}
	*/

	COlePropertyPage::OnLButtonDown(nFlags, point);
}

void CDown_Clear_OCXPropPage::OnPaint() 
{



	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
		////////������Ƥ��/////////
	/*
	CDC* pDC;
	pDC=GetDlgItem(IDC_STATIC_PLAY_LOCAL)->GetDC();
	m_rectTracker.Draw(pDC);
	pDC->DeleteDC();
	*/

		///////////////////////
	// Do not call COlePropertyPage::OnPaint() for painting messages
}


BOOL  CDown_Clear_OCXPropPage::IsInVedio(CPoint point )
{
	
	GetDlgItem(IDC_STATIC_PLAY_LOCAL)->GetClientRect(m_clientVedioRect);
	if(m_clientVedioRect.left<point.x&& m_clientVedioRect.top< point.y\
		&& m_clientVedioRect.right>point.x&& m_clientVedioRect.bottom>point.y)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
		
	}
	
	
	
}

void CDown_Clear_OCXPropPage::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	/////////////////////////////////
	//ȷ���ڹ���һ����ѡ��ʱ����ӦOnLButtonUp����������ӦOnLButtonDblClkʱ����ִ�����
	if(IsLButtonDown==TRUE)
	{
		//MessageBox("�������ɿ�","�ɿ�",NULL);
		
		//����GetCursorPos��õ�pt_end��Screen���꣬����ScreenToClient()����ת��
		rect.right=pt_end.x;
		rect.bottom=pt_end.y;
		ScreenToClient(&rect);
		pt_end.x=rect.right;
		pt_end.y=rect.bottom;
		
		//left,top,right,bottom
		m_rectTracker.m_rect.SetRect(pt_start.x,pt_start.y,pt_end.x,pt_end.y);
		m_rectTracker.m_rect.NormalizeRect();
		
		this->OnPaint();
		IsLButtonDown=FALSE;
	}
	COlePropertyPage::OnLButtonUp(nFlags, point);
}

void CDown_Clear_OCXPropPage::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	/*
	if(m_bInRect)
	{
		//MessageBox("s");
		m_rectTracker.m_rect;
		CRect rectVideo ;
		GetDlgItem(IDC_STATIC_PLAY_LOCAL)->GetClientRect(rectVideo);
		if(1)
		{
		
		}
#if 0
		CRect rectResult;
		if(rectResult.SubtractRect(rectVideo,	m_rectTracker.m_rect))
		{
			MessageBox("������ק�����Ŵ�����!");

		}
#endif 
	}
	*/

	COlePropertyPage::OnMouseMove(nFlags, point);
}

BOOL CDown_Clear_OCXPropPage::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	/*
	//////////////////////
	//�ı������״
	if (pWnd == this && m_rectTracker.SetCursor(this, nHitTest))
		return TRUE;
	//////////////////////
	*/

	
	return COlePropertyPage::OnSetCursor(pWnd, nHitTest, message);
}
//�Ŵ��㷨;  2-> ��ɫ; 4->����; 8->�Աȶ�;  16->ɫ������ ; 128->��ǿ; 256-> ȥ��; 512-> ��ͷУ��; 1024-> �� ;

void CDown_Clear_OCXPropPage::OnReleasedcaptureSliderBlowup(NMHDR* pNMHDR, LRESULT* pResult)  //�Ŵ�
{
	// TODO: Add your control notification handler code here
	//m_apx;

	m_nAlgMask = 1;//1 -> �Ŵ��㷨
	//m_nScale = m_apx.scale = m_ctrScale.GetPos();
	m_nScale =  m_ctrScale.GetPos();

	*pResult = 0;
}
 
// void CDown_Clear_OCXPropPage::OnReleasedcaptureSliderInverse(NMHDR* pNMHDR, LRESULT* pResult) // ��ɫ
// 
// {
// 	// TODO: Add your control notification handler code here
// 	m_nAlgMask = 2;
// 	*pResult = 0;
// }

void CDown_Clear_OCXPropPage::OnReleasedcaptureSliderLight(NMHDR* pNMHDR, LRESULT* pResult)  //����
{
	// TODO: Add your control notification handler code here
	m_nAlgMask |= 4;// 4->����
	//m_apx.Lightness = m_ctrLightness.GetPos();
	m_nLight =  m_ctrLightness.GetPos();
	*pResult = 0;
}



void CDown_Clear_OCXPropPage::OnReleasedcaptureSliderContrast(NMHDR* pNMHDR, LRESULT* pResult) // �Աȶ�
{
	// TODO: Add your control notification handler code here
	m_nAlgMask |= 8; // 8->�Աȶ�

	//m_apx.Contrast = m_ctrContrast.GetPos();
	m_nContrast = m_ctrContrast.GetPos();
	*pResult = 0;
}

void CDown_Clear_OCXPropPage::OnReleasedcaptureSliderCheck(NMHDR* pNMHDR, LRESULT* pResult) // У��
{
	// TODO: Add your control notification handler code here
	m_nAlgMask = 512;//	512-> ��ͷУ��
	m_nCheck =m_ctrCalibBig.GetPos();
	*pResult = 0;
}

void CDown_Clear_OCXPropPage::OnReleasedcaptureSliderDellump(NMHDR* pNMHDR, LRESULT* pResult) // ȥ��
{
	// TODO: Add your control notification handler code here

	m_nAlgMask |= 256; //256-> ȥ�� 
	//m_apx.debolckSharpness = m_ctrdebolckSharpness.GetPos();
	m_nDelLump = m_ctrdebolckSharpness.GetPos();
	*pResult = 0;
}

void CDown_Clear_OCXPropPage::OnReleasedcaptureSliderSharpening(NMHDR* pNMHDR, LRESULT* pResult) // ��
{
	// TODO: Add your control notification handler code here
	m_nAlgMask |= 1024; //1024-> �� ;
	//m_apx.Sharplevel = m_ctrSharplevel.GetPos();
	m_nSharPening =  m_ctrSharplevel.GetPos();

	*pResult = 0;
}

void CDown_Clear_OCXPropPage::OnRadioAn()  //������
{
	if(m_nSceneOldType == 0)  // ���ԭ����ѡ���������ȥ��Ч��
	{
		m_nAlgMask &=(~ 128); //ȥ����ǿ
		m_nSceneOldType = m_nSceneType = -1;;
		UpdateData(FALSE);
		m_nAlgCount --;
		Sleep(100);

		return;
	}
	
	// TODO: Add your control notifica tion handler code here

	if(m_nSceneOldType >=0) // ԭ�����Ѿ�ѡ���� �Ͳ����ж��㷨��������Ϊ�⼸��RAdio ��һ���
	{

	}
	else
	{
		if(m_nAlgCount>=3)
		{
			MessageBox("���ͬʱ֧��������Ч");

			if(m_nSceneOldType != -1) //�Ѿ���ѡ����� 
			{
				m_nSceneType = m_nSceneOldType;
			}
			else
			{
				m_nSceneType = m_nSceneOldType = -1;
			}
			UpdateData(FALSE);
			return;
		}
		m_nAlgCount ++;
	}



	m_nAlgMask |= 128; //��ǿ
	//m_apx.SceneType  =0;   // ͼ������: (0: ������) (1: ���) (2: ����) (3: ������)
	m_nSceneOldType = m_nSceneType = 0;
}

void CDown_Clear_OCXPropPage::OnRadioLg() //���
{
	// TODO: Add your control notification handler code here
	if(m_nSceneOldType == 1)
	{
		m_nAlgMask &=(~ 128); //ȥ����ǿ
		m_nSceneOldType = m_nSceneType = -1;
		UpdateData(FALSE);
		m_nAlgCount --;
		return;

	}
	if(m_nSceneOldType >=0) // ԭ�����Ѿ�ѡ���� �Ͳ����ж��㷨��������Ϊ�⼸��RAdio ��һ���
	{
		
	}
	else
	{
		if(m_nAlgCount>=3)
		{
			MessageBox("���ͬʱ֧��������Ч");

			if(m_nSceneOldType != -1) //�Ѿ���ѡ����� 
			{
				m_nSceneType = m_nSceneOldType;
			}
			else
			{
				m_nSceneType = m_nSceneOldType = -1;
			}
			UpdateData(FALSE);
			return;
		}
		m_nAlgCount ++;
	}
	
	m_nAlgMask |= 128; //��ǿ
	m_nSceneType = 1;
	m_nSceneOldType = m_nSceneType ; // 
}

void CDown_Clear_OCXPropPage::OnRadioWy() // ����
{
	// TODO: Add your control notification handler code here
	TRACE("OnRadioWy\n");

	if(m_nSceneOldType == 2)
	{
		m_nAlgMask &=(~ 128); //ȥ����ǿ
		m_nSceneOldType =m_nSceneType = -1; //= 
		UpdateData(FALSE);
		//((CButton *)GetDlgItem(IDC_RADIO_WY))->SetCheck(FALSE);//
		PostMessage(WM_DECSHOW,RADIO_UPDATE,0);

		m_nAlgCount --;
		return;

	}

	if(m_nSceneOldType >=0) // ԭ�����Ѿ�ѡ���� �Ͳ����ж��㷨��������Ϊ�⼸��RAdio ��һ���
	{

	}
	else
	{
		if(m_nAlgCount>=3)
		{
			MessageBox("���ͬʱ֧��������Ч");

			if(m_nSceneOldType != -1) //�Ѿ���ѡ����� 
			{
				m_nSceneType = m_nSceneOldType;
			}
			else
			{
				m_nSceneType = m_nSceneOldType = -1;
			}
			UpdateData(FALSE);
			return;
		}
		m_nAlgCount ++;
	}
	
	m_nAlgMask |= 128; //��ǿ
	//m_apx.SceneType  =2; 
	m_nSceneOldType = 2;
}

void CDown_Clear_OCXPropPage::OnRadioLcj() //������
{
	// TODO: Add your control notification handler code here
	if(m_nSceneOldType == 3)
	{
		m_nAlgMask &=(~ 128); //ȥ����ǿ
		m_nSceneOldType = m_nSceneType = -1;
		m_nAlgCount --;

		UpdateData(FALSE);
		return;

	}
	if(m_nSceneOldType >=0) // ԭ�����Ѿ�ѡ���� �Ͳ����ж��㷨��������Ϊ�⼸��RAdio ��һ���
	{

	}
	else
	{
		if(m_nAlgCount>=3)
		{
			MessageBox("���ͬʱ֧��������Ч");

			if(m_nSceneOldType != -1) //�Ѿ���ѡ����� 
			{
				m_nSceneType = m_nSceneOldType;
			}
			else
			{
				m_nSceneType = m_nSceneOldType = -1;
			}
			UpdateData(FALSE);
			return;
		}
		m_nAlgCount ++;
	}
	m_nAlgMask |= 128; //��ǿ
	m_nSceneOldType = m_nSceneType = 3;

}


LRESULT CDown_Clear_OCXPropPage::OnDecShow(WPARAM wParam,LPARAM lParam)
{
	switch(wParam )
	{
	case SETRANGE:  //SETRANGE
		m_sliderPlay.SetRange(0,lParam);
		break;
	case DECFAILED:  //DECFAILED
		SetPlayState(PLAY_NORMAL);
		break;
	case SETPOS:  //SETPOS
		m_sliderPlay.SetPos(lParam);
		break;
	case STOPPLAY:
		SetPlayState(PLAY_STOP);
		break;
	case STARTIMAGESHOW:
		m_hPlayWnd = GetDlgItem(IDC_STATIC_PLAY_LOCAL)->GetSafeHwnd();
		m_hStartImageShow =  VSNET_ClientStartImageShow(m_hPlayWnd,m_lWidth,m_lHeight);
		break;
	case MP4FAILED:
		StopPlay();
		break;
	case RADIO_UPDATE:
		UpdateData(FALSE);
		break;
	case 2:  //  ���ô��ڵĴ�С

		TRACE("%d------%d\n",m_rectVedio.right-m_rectVedio.left,m_rectVedio.bottom-m_rectVedio.top);
		TRACE(" m_lWidth= %ld,m_lHeight = %ld----\n", m_lWidth ,m_lHeight );
		float  fWidthRate;// =((float) m_lWidth)/(float)(m_rectVedio.right-m_rectVedio.left);
		float  fHeightRate ;//=((float) m_lHeight) /(float)(m_rectVedio.bottom-m_rectVedio.top);

		if(m_lWidth>m_lHeight)
		{
			fWidthRate =((float)  m_lWidth)/(float)m_lHeight;
			int nTemp=0;
			//	nTemp = m_rectVedio.bottom -m_rectVedio.top;
			//nTemp = m_rectVedioInit.bottom -m_rectVedioInit.top;
			nTemp = m_rectVedioInit.Width();
			//nTemp = m_rectVedioInit.Height();
			TRACE("nTemp %d ----%f--\n",nTemp,fWidthRate);
			int pannel;
			//	m_rectVedio.bottom =m_rectVedio.top+((float)nTemp/fWidthRate);
			m_rectVedio.bottom =0+((float)nTemp/fWidthRate);

			pannel = ((m_rectVedioInit.bottom-m_rectVedioInit.top)-m_rectVedio.bottom)/2;

			m_rectVedio.bottom += pannel;
			m_rectVedio.top =0;
			m_rectVedio.top+= pannel;
			TRACE("pannel %d ------\n",pannel);
		}
		else 
		{
			fHeightRate =((float) m_lHeight)/(float)m_lWidth;
			int nTemp=0;
			//	nTemp = m_rectVedio.right- m_rectVedio.left;
			//nTemp = m_rectVedioInit.right- m_rectVedioInit.left;
			nTemp = m_rectVedioInit.Height();
			int pannel;
			m_rectVedio.right =0+((float)nTemp/fHeightRate);
			pannel = ((m_rectVedioInit.right-m_rectVedioInit.left)-	m_rectVedio.right)/2;

			m_rectVedio.right += pannel;
			m_rectVedio.left = 0;
			m_rectVedio.left += pannel;


		}
		m_lShowWidth =  m_rectVedio.Width();
		m_lShowHeight = m_rectVedio.Height();
		GetDlgItem(IDC_STATIC_PLAY_LOCAL)->MoveWindow(m_rectVedio);

	break;

	case 1: // ˢ�´���

		VSNET_ClientRefreshImageShow(m_hStartImageShow);	
	break;

		}
	return TRUE;
}
void CDown_Clear_OCXPropPage::OnBnClickedBtnOpen()
{
	// TODO: Add your control notification handler code here
	CFileDialog fileDlg(TRUE);
	//�ı�Ի������
	fileDlg.m_ofn.lpstrTitle = "ѡ���ļ�";

	fileDlg.m_ofn.lpstrFilter = "avi Files(*.avi)\0*.avi\0mp4 Files(*.mp4)\0*.mp4\0\0";//"Text Files(*.avi)\0*.avi\0All Files(*.*)\0*.*\0\0";
	//����Ĭ�ϵ���չ��
	fileDlg.m_ofn.lpstrDefExt = "avi";	


	if(IDOK == 	fileDlg.DoModal())
	{
		m_szFileName =  fileDlg.GetPathName();
		if(m_szFileName.IsEmpty())
		{
			MessageBox("�ļ�����Ϊ�գ�����ϸѡ���ļ���");
			return ;

		}

		CString szTemp;
		szTemp = m_szFileName.Right(3);

		if(szTemp.Compare("mp4")== 0)
		{
			m_nType = 1; 

		}
		else if(szTemp.Compare("avi") == 0)
		{
			m_nType = 2;
		}
		else
		{
			m_nType = -1;

		}
		SetPlayState(PLAY_READY);

	}
	else
	{
		return ;

	}



}

void CDown_Clear_OCXPropPage::OnNMCustomdrawSliderBlowup(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	// TODO: Add your control notification handler code here
	*pResult = 0;
}

void CDown_Clear_OCXPropPage::OnNMCustomdrawSliderLight(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	// TODO: Add your control notification handler code here
	*pResult = 0;
}

void CDown_Clear_OCXPropPage::OnNMCustomdrawSliderDellump(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	// TODO: Add your control notification handler code here
	*pResult = 0;
}

void CDown_Clear_OCXPropPage::OnNMCustomdrawSliderCheck(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	// TODO: Add your control notification handler code here
	*pResult = 0;
}

BOOL CDown_Clear_OCXPropPage::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following block was added by the ToolTips component.
	{
		// Let the ToolTip process this message.
		m_tooltip.RelayEvent(pMsg);
	}
	return COlePropertyPage::PreTranslateMessage(pMsg);	// CG: This was added by the ToolTips component.
}

void CDown_Clear_OCXPropPage::OnRadioFs() 
{
	TRACE("OnRadioFs\n");

	// TODO: Add your control notification handler code here
	if(m_nColorOldType == 0)
	{
		m_nAlgMask &=(~2);// ȥ-> ��ɫ;
		m_nColorOldType  = m_nColorType  = -1;
		UpdateData(FALSE);
		m_nAlgCount--;
		return;

	}
	if(m_nColorOldType >=0) // ԭ�����Ѿ�ѡ���� �Ͳ����ж��㷨��������Ϊ�⼸��RAdio ��һ���
	{

	}
	else
	{
		if(m_nAlgCount>=3)
		{
			MessageBox("���ͬʱ֧��������Ч");

			if(m_nColorOldType  != -1) //�Ѿ���ѡ����� 
			{
				m_nColorType = m_nColorOldType;
			}
			else
			{
				m_nColorType = m_nColorOldType = -1;
			}
			UpdateData(FALSE);
			return;
		}
		m_nAlgCount ++;
	}
	
	m_nColorOldType = m_nColorType = 0;
	
	m_nAlgMask &=(~16);//ȥ>ɫ������ ;
	m_nAlgMask |= 2;//-> ��ɫ;
}

void CDown_Clear_OCXPropPage::OnRadioSdjh() 
{
	// TODO: Add your control notification handler code here
	if(m_nColorOldType == 1)
	{
		m_nAlgMask &=(~16);// ȥ-> ɫ������ ;
		m_nColorOldType = m_nColorType  = -1;
		UpdateData(FALSE);
		m_nAlgCount--;
		return;

	}
	if(m_nColorOldType >=0) // ԭ�����Ѿ�ѡ���� �Ͳ����ж��㷨��������Ϊ�⼸��RAdio ��һ���
	{

	}
	else
	{
		if(m_nAlgCount>=3)
		{
			MessageBox("���ͬʱ֧��������Ч");

			if(m_nColorOldType  != -1) //�Ѿ���ѡ����� 
			{
				m_nColorType = m_nColorOldType;
			}
			else
			{
				m_nColorType = m_nColorOldType = -1;
			}
			UpdateData(FALSE);
			return;
		}
		m_nAlgCount ++;
	}

	m_nColorOldType = m_nColorType = 1;
	m_nAlgMask &=(~2);//-> ��ɫ;
	m_nAlgMask |= 16;//->ɫ������ ;


}

HBRUSH CDown_Clear_OCXPropPage::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = COlePropertyPage::OnCtlColor(pDC, pWnd, nCtlColor);
	if(pWnd->GetDlgCtrlID() == IDC_STATIC_PLAY_LOCAL) 	
	{	
		pDC->SetBkColor(RGB(111,111,100));
		HBRUSH B = CreateSolidBrush(RGB(111,111,100));
		return (HBRUSH) B;
	}
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(RGB(255,255, 255));
	//  pWnd->SetFont(cFont);
	//HBRUSH B = CreateSolidBrush(RGB(92,92,92));
	
	HBRUSH B = CreateSolidBrush(RGB(75,75,75));
	return (HBRUSH) B;
	
//	return hbr;
}

void CDown_Clear_OCXPropPage::OnNMCustomdrawSliderPlay(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	// TODO: Add your control notification handler code here
	*pResult = 0;
}

//void CDown_Clear_OCXPropPage::OnBnClickedBtnDellump()
//{
//	// TODO: Add your control notification handler code here
//}

void CDown_Clear_OCXPropPage::OnNMCustomdrawSliderSharpening(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	// TODO: Add your control notification handler code here
	*pResult = 0;
}

void CDown_Clear_OCXPropPage::OnBtnDellump() 
{
	// TODO: Add your control notification handler code here
	
	if(m_bBtnDellump)
	{
		m_nAlgCount --;	
		m_nAlgMask &=(~256);  // 256 ȥ��

		if(m_nAlgCount <0 ) m_nAlgCount =0;
		m_bBtnDellump = FALSE;
		GetDlgItem(IDC_SLIDER_DELLUMP)->EnableWindow(FALSE);
		m_btnDelLump.SetIcon(m_hDellumpDisableIcon);
	}
	else
	{
		if(m_nAlgCount>=3)
		{
			MessageBox("���ͬʱ֧������Ч��!");
			return;

		}
		m_nAlgCount ++;	
		m_nAlgMask |=256;
		m_bBtnDellump = TRUE;
		GetDlgItem(IDC_SLIDER_DELLUMP)->EnableWindow(TRUE);
		m_btnDelLump.SetIcon(m_hDellumpEnableIcon);
	}
}

void CDown_Clear_OCXPropPage::OnBtnContast() 
{
	// TODO: Add your control notification handler code here

	if(m_bBtnContrast)
	{
		m_nAlgCount --;	
		m_nAlgMask &=(~8);   // 8 �Աȶ�

		if(m_nAlgCount <0 ) m_nAlgCount =0;
		m_bBtnContrast = FALSE;
		GetDlgItem(IDC_SLIDER_CONTRAST)->EnableWindow(FALSE);
		m_btnContrast.SetIcon(m_hContrastDisableIcon);

	}
	else
	{
		if(m_nAlgCount>=3)
		{
			MessageBox("���ͬʱ֧������Ч��!");
			return;	
		}
		m_nAlgCount ++;
		m_nAlgMask |=8;
		m_bBtnContrast = TRUE;
		GetDlgItem(IDC_SLIDER_CONTRAST)->EnableWindow(TRUE);
		m_btnContrast.SetIcon(m_hContrastEnableIcon);
	}
	
}

void CDown_Clear_OCXPropPage::OnBtnLight() 
{
	// TODO: Add your control notification handler code here

	if(m_bBtnLight)
	{
		m_nAlgCount --;	
		m_nAlgMask &=(~4);   // 4 ����

		if(m_nAlgCount <0 ) m_nAlgCount =0;
		m_bBtnLight = FALSE;
		GetDlgItem(IDC_SLIDER_LIGHT)->EnableWindow(FALSE);
		m_btnLight.SetIcon(m_hLightDisableIcon);
	}
	else
	{
		if(m_nAlgCount>=3)
		{
			MessageBox("���ͬʱ֧������Ч��!");
			return;

		}
		m_nAlgCount ++;
		m_nAlgMask |=4;
		m_bBtnLight = TRUE;
		GetDlgItem(IDC_SLIDER_LIGHT)->EnableWindow(TRUE);
		m_btnLight.SetIcon(m_hLightEnableIcon);
	}
}

void CDown_Clear_OCXPropPage::OnBtnSharpeng() 
{
	// TODO: Add your control notification handler code here

	if(m_bBtnSharpeng)
	{
		m_nAlgCount --;	
		m_nAlgMask &=(~1024);   // 1024��

		if(m_nAlgCount <0 ) m_nAlgCount =0;
		m_bBtnSharpeng = FALSE;
		GetDlgItem(IDC_SLIDER_SHARPENING)->EnableWindow(FALSE);
		m_btnSharpening.SetIcon(m_hSharpenDisableIcon);

	}
	else
	{
		if(m_nAlgCount>=3)
		{
			MessageBox("���ͬʱ֧������Ч��!");
			return;

		}
		m_nAlgCount ++;
		m_nAlgMask |=1024;
		m_bBtnSharpeng = TRUE;
		GetDlgItem(IDC_SLIDER_SHARPENING)->EnableWindow(TRUE);
		m_btnSharpening.SetIcon(m_hSharpenEnableIcon);
	}
}

void CDown_Clear_OCXPropPage::OnNMCustomdrawSliderContrast(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	// TODO: Add your control notification handler code here
	*pResult = 0;
}
 void CDown_Clear_OCXPropPage::OnNMReleasedcaptureSliderLight(NMHDR *pNMHDR, LRESULT *pResult)
{	// TODO: Add your control notification handler code here
	*pResult = 0;
}
HCURSOR CDown_Clear_OCXPropPage::GetSysHandCursor()
{
	 TCHAR		strWinDir[MAX_PATH] = {0};
	 HCURSOR		hHandCursor			= NULL;
	 hHandCursor = ::LoadCursor(NULL, MAKEINTRESOURCE(32649));
	 
	 // Still no cursor handle - load the WinHelp hand cursor
	 if( hHandCursor == NULL )
	 {
		 GetWindowsDirectory(strWinDir, MAX_PATH);
		 strcat(strWinDir, _T("\\winhlp32.exe"));
		 
		 // This retrieves cursor #106 from winhlp32.exe, which is a hand pointer
		 HMODULE hModule = ::LoadLibrary(strWinDir);
		 DWORD	dwErr = GetLastError();
		 if( hModule != NULL )
		 {
			 HCURSOR	 hTempCur = ::LoadCursor(hModule, MAKEINTRESOURCE(106));
			 hHandCursor = (hTempCur != NULL) ? CopyCursor(hTempCur) : NULL;
			 FreeLibrary(hModule);
		 }
	 }
	 return hHandCursor;
}
 void CDown_Clear_OCXPropPage::InitSliderUi()
 {
	 
	 m_hHandCur = this->GetSysHandCursor();
	 ASSERT( m_hHandCur != NULL );
	 
	 m_sliderPlay.SetFlipCursor(m_hHandCur);  // ���Ž�����
	 m_sliderPlay.BuildThumbItem(IDB_BITMAP_THUMB, 6, 12);
	 m_sliderPlay.BuildBackItem(IDB_BITMAP_NORMAL, IDB_BITMAP_ACTIVE);
	 m_sliderPlay.SetLineSize(0);
 
	 m_ctrSharplevel.SetFlipCursor(m_hHandCur);
	 m_ctrSharplevel.BuildThumbItem(IDB_BITMAP_THUMB, 6, 12);
	 m_ctrSharplevel.BuildBackItem(IDB_BITMAP_NORMAL_SHORT, IDB_BITMAP_ACTIVE_SHORT);
	 m_ctrSharplevel.SetLineSize(0);

	 m_ctrdebolckSharpness.SetFlipCursor(m_hHandCur);
	 m_ctrdebolckSharpness.BuildThumbItem(IDB_BITMAP_THUMB, 6, 12);
	 m_ctrdebolckSharpness.BuildBackItem(IDB_BITMAP_NORMAL_SHORT, IDB_BITMAP_ACTIVE_SHORT);
	 m_ctrdebolckSharpness.SetLineSize(0);

	   //����
	 m_ctrLightness.SetFlipCursor(m_hHandCur);
	 m_ctrLightness.BuildThumbItem(IDB_BITMAP_THUMB, 6, 12);
	 m_ctrLightness.BuildBackItem(IDB_BITMAP_NORMAL_SHORT, IDB_BITMAP_ACTIVE_SHORT);
	 m_ctrLightness.SetLineSize(0);

	    //�Աȶ�
	 m_ctrContrast.SetFlipCursor(m_hHandCur);
	 m_ctrContrast.BuildThumbItem(IDB_BITMAP_THUMB, 6, 12);
	 m_ctrContrast.BuildBackItem(IDB_BITMAP_NORMAL_SHORT, IDB_BITMAP_ACTIVE_SHORT);
	 m_ctrContrast.SetLineSize(0);
//	 m_ctrScale;     //
 }
int CDown_Clear_OCXPropPage::SetAllNoCheck()  //��ȡ�����Ĺ�ѡ����
{
	if(((CButton*)GetDlgItem(IDC_CHECK_ANCJ))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_ANCJ))->SetCheck(0);
	if(((CButton*)GetDlgItem(IDC_CHECK_LG))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_LG))->SetCheck(0);
	if(((CButton*)GetDlgItem(IDC_CHECK_LCJ))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_LCJ))->SetCheck(0);
	if(((CButton*)GetDlgItem(IDC_CHECK_WY))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_WY))->SetCheck(0);
	return 1;

}
 void CDown_Clear_OCXPropPage::OnBnClickedCheckAncj()  //������
 {
	 // TODO: �ڴ����ӿؼ�֪ͨ�����������

	if(((CButton*)GetDlgItem(IDC_CHECK_ANCJ))->GetCheck())
	{
		if(((CButton*)GetDlgItem(IDC_CHECK_LG))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_LG))->SetCheck(0);
		if(((CButton*)GetDlgItem(IDC_CHECK_LCJ))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_LCJ))->SetCheck(0);
		if(((CButton*)GetDlgItem(IDC_CHECK_WY))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_WY))->SetCheck(0);
	
		if(m_nSceneType == -1) // = -1 ˵��ԭ��û��ѡ����ô �㷨���;�Ҫ++
		{
			if(m_nAlgCount>=3)
			{
				if(((CButton*)GetDlgItem(IDC_CHECK_ANCJ))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_ANCJ))->SetCheck(0);
				MessageBox("���ͬʱ֧��������Ч");
				return;
			}
			m_nAlgCount ++;	
		}
	

		m_nAlgMask |= 128; //��ǿ
		//m_apx.SceneType  =0;   // ͼ������: (0: ������) (1: ���) (2: ����) (3: ������)
		m_nSceneType = 0;
		return;
	}
	else
	{

		//	SetAllNoCheck();
		m_nAlgMask &=(~ 128); //ȥ����ǿ
		m_nSceneType = -1;

		m_nAlgCount --;
		if(m_nAlgCount <0) m_nAlgCount =0;
		return;
		
	}

 }

 void CDown_Clear_OCXPropPage::OnBnClickedCheckLg() //���
 {
	 // TODO: �ڴ����ӿؼ�֪ͨ�����������
	 if(((CButton*)GetDlgItem(IDC_CHECK_LG))->GetCheck())
	 {
		 if(((CButton*)GetDlgItem(IDC_CHECK_ANCJ))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_ANCJ))->SetCheck(0);
		 if(((CButton*)GetDlgItem(IDC_CHECK_LCJ))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_LCJ))->SetCheck(0);
		 if(((CButton*)GetDlgItem(IDC_CHECK_WY))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_WY))->SetCheck(0);
	
		 if(m_nSceneType == -1) // = -1 ˵��ԭ��û��ѡ����ô �㷨���;�Ҫ++
		 {
			 if(m_nAlgCount>=3)
			 {
				 if(((CButton*)GetDlgItem(IDC_CHECK_LG))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_LG))->SetCheck(0);
				 MessageBox("���ͬʱ֧��������Ч");
				 return;
			 }
			 m_nAlgCount ++;	
		 }


		 m_nAlgMask |= 128; //��ǿ
		 //m_apx.SceneType  =0;   // ͼ������: (0: ������) (1: ���) (2: ����) (3: ������)
		 m_nSceneType = 1;
		 return;
	 }
	 else
	 {

		 //	SetAllNoCheck();
		 m_nAlgMask &=(~ 128); //ȥ����ǿ
		 m_nSceneType = -1;
		 m_nAlgCount --;
		 if(m_nAlgCount <0) m_nAlgCount =0;
		 return;

	 }
 }

 void CDown_Clear_OCXPropPage::OnBnClickedCheckWy()  // ����
 {
	 // TODO: �ڴ����ӿؼ�֪ͨ�����������
	 if(((CButton*)GetDlgItem(IDC_CHECK_WY))->GetCheck())
	 {
		 if(((CButton*)GetDlgItem(IDC_CHECK_ANCJ))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_ANCJ))->SetCheck(0);
		 if(((CButton*)GetDlgItem(IDC_CHECK_LCJ))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_LCJ))->SetCheck(0);
		 if(((CButton*)GetDlgItem(IDC_CHECK_LG))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_LG))->SetCheck(0);
	
		 if(m_nSceneType == -1) // = -1 ˵��ԭ��û��ѡ����ô �㷨���;�Ҫ++
		 {
			 if(m_nAlgCount>=3)
			 {
				 if(((CButton*)GetDlgItem(IDC_CHECK_WY))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_WY))->SetCheck(0);
				 MessageBox("���ͬʱ֧��������Ч");
				 return;
			 }
			 m_nAlgCount ++;	
		 }


		 m_nAlgMask |= 128; //��ǿ
		 //m_apx.SceneType  =0;   // ͼ������: (0: ������) (1: ���) (2: ����) (3: ������)
		 m_nSceneType = 2;
		 return;
	 }
	 else
	 {

		 //	SetAllNoCheck();
		 m_nAlgMask &=(~ 128); //ȥ����ǿ
		 m_nSceneType = -1;
		 m_nAlgCount --;
		 if(m_nAlgCount <0) m_nAlgCount =0;
		 return;

	 }
 }

 void CDown_Clear_OCXPropPage::OnBnClickedCheckLcj()  //������
 {
	 // TODO: �ڴ����ӿؼ�֪ͨ�����������
	 if(((CButton*)GetDlgItem(IDC_CHECK_LCJ))->GetCheck())
	 {
		 if(((CButton*)GetDlgItem(IDC_CHECK_ANCJ))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_ANCJ))->SetCheck(0);
		 if(((CButton*)GetDlgItem(IDC_CHECK_WY))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_WY))->SetCheck(0);
		 if(((CButton*)GetDlgItem(IDC_CHECK_LG))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_LG))->SetCheck(0);
	
		 if(m_nSceneType == -1) // = -1 ˵��ԭ��û��ѡ����ô��Ҫ�ж��㷨���� �㷨���;�Ҫ++
		 {
			 if(m_nAlgCount>=3)
			 {
				 if(((CButton*)GetDlgItem(IDC_CHECK_LCJ))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_LCJ))->SetCheck(0);
				 MessageBox("���ͬʱ֧��������Ч");
				 return;
			 }
			 m_nAlgCount ++;	
		 }


		 m_nAlgMask |= 128; //��ǿ
		 //m_apx.SceneType  =0;   // ͼ������: (0: ������) (1: ���) (2: ����) (3: ������)
		 m_nSceneType = 3;
		 return;
	 }
	 else
	 {

		 //	SetAllNoCheck();
		 m_nAlgMask &=(~ 128); //ȥ����ǿ
		 m_nSceneType = -1;
		 m_nAlgCount --;
		 if(m_nAlgCount <0) m_nAlgCount =0;
		 return;

	 }
 }

 void CDown_Clear_OCXPropPage::OnBnClickedCheckFs() // ��ɫ	
 {
	 // TODO: �ڴ����ӿؼ�֪ͨ�����������
	 if(((CButton*)GetDlgItem(IDC_CHECK_FS))->GetCheck())
	 {
		 if(m_nAlgCount>=3)
		 {
			 if(((CButton*)GetDlgItem(IDC_CHECK_FS))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_FS))->SetCheck(0);
			 MessageBox("���ͬʱ֧��������Ч");
			 return;
		 }
	
		 m_nAlgCount ++;	
		 m_nAlgMask |= 2; //��ɫ

		 return;
	 }
	 else
	 {
		 m_nAlgMask &=(~ 2); //ȥ ��ɫ
		 m_nAlgCount --;
		 if(m_nAlgCount<0) m_nAlgCount =0;

		 return;

	 }
 }
  
 void CDown_Clear_OCXPropPage::OnBnClickedCheckSdjh()  // ɫ������

 {
	 // TODO: �ڴ����ӿؼ�֪ͨ�����������
	 if(((CButton*)GetDlgItem(IDC_CHECK_SDJH))->GetCheck())
	 {
		 if(m_nAlgCount>=3)
		 {
			 if(((CButton*)GetDlgItem(IDC_CHECK_SDJH))->GetCheck()) ((CButton*)GetDlgItem(IDC_CHECK_SDJH))->SetCheck(0);
			 MessageBox("���ͬʱ֧��������Ч");
			 return;
		 }

		 m_nAlgCount ++;	
		 m_nAlgMask |= 16; //  ɫ������

		 return;
	 }
	 else
	 {
		 m_nAlgMask &=(~ 16); //ȥ ɫ������
		 
		 m_nAlgCount --;
		 if(m_nAlgCount<0) m_nAlgCount =0;

		 return;

	 }
 }
