#if !defined(AFX_DOWN_CLEAR_OCX_H__4B6E89E5_C23E_4B7F_B363_AFE555E354AE__INCLUDED_)
#define AFX_DOWN_CLEAR_OCX_H__4B6E89E5_C23E_4B7F_B363_AFE555E354AE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Down_Clear_OCX.h : main header file for DOWN_CLEAR_OCX.DLL

#if !defined( __AFXCTL_H__ )
	#error include 'afxctl.h' before including this file
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXApp : See Down_Clear_OCX.cpp for implementation.

class CDown_Clear_OCXApp : public COleControlModule
{
public:
	BOOL InitInstance();
	int ExitInstance();
};

extern const GUID CDECL _tlid;
extern const WORD _wVerMajor;
extern const WORD _wVerMinor;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DOWN_CLEAR_OCX_H__4B6E89E5_C23E_4B7F_B363_AFE555E354AE__INCLUDED)
