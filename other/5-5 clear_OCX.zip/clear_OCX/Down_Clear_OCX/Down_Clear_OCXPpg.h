#if !defined(AFX_DOWN_CLEAR_OCXPPG_H__88FB38AC_F5C5_41AA_B191_F22CAD4170EB__INCLUDED_)
#define AFX_DOWN_CLEAR_OCXPPG_H__88FB38AC_F5C5_41AA_B191_F22CAD4170EB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <list>
using namespace std;


#pragma comment(lib,"../lib/NetDownLoad.lib")
#include "DownLoad.h"


#include <AFXMT.H>
#include "RenderAlgFacade.h"
#include "afxwin.h"

#include "BitSlider.h"
#include "BtnST.h"
// Down_Clear_OCXPpg.h : Declaration of the CDown_Clear_OCXPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CDown_Clear_OCXPropPage : See Down_Clear_OCXPpg.cpp.cpp for implementation.
#define PLAY_STOP   0
#define PLAY_NORMAL 1
#define PLAY_PAUSE  2
#define PLAY_FAST   3
#define PLAY_SLOW   4
#define PLAY_PLAY   5
#define PLAY_READY  6
#define  LOCAL_PLAY_STATE 10
class CDown_Clear_OCXPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CDown_Clear_OCXPropPage)
	DECLARE_OLECREATE_EX(CDown_Clear_OCXPropPage)

// Constructor
public:
	CDown_Clear_OCXPropPage();

// Dialog Data
	//{{AFX_DATA(CDown_Clear_OCXPropPage)
	enum { IDD = IDD_PROPPAGE_DOWN_CLEAR_OCX };
	CBitSlider	m_ctrSharplevel;
	CBitSlider	m_ctrCalibBig;
	CBitSlider	m_ctrdebolckSharpness;
	CBitSlider	m_ctrLightness;
	CBitSlider	m_ctrContrast;
	CBitSlider	m_ctrScale;
	CBitSlider	m_sliderPlay;
	//int		m_nSceneType;
	int m_nSceneOldType;
	int		m_nScale;
	int		m_nColorType;
	int		m_nColorOldType;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	CToolTipCtrl m_tooltip;
	//{{AFX_MSG(CDown_Clear_OCXPropPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnBtnPaly();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnBtnStop();
	afx_msg void OnOutofmemorySliderPlay(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureSliderPlay(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnReleasedcaptureSliderBlowup(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureSliderLight(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureSliderContrast(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureSliderCheck(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureSliderDellump(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureSliderSharpening(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRadioAn();
	afx_msg void OnRadioLg();
	afx_msg void OnRadioWy();
	afx_msg void OnRadioLcj();
	afx_msg void OnRadioFs();
	afx_msg void OnRadioSdjh();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);

	afx_msg void OnBtnDellump();
	afx_msg void OnBtnContast();
	afx_msg void OnBtnLight();
	afx_msg void OnBtnSharpeng();
	//}}AFX_MSG
	afx_msg LRESULT OnDecShow(WPARAM wParam,LPARAM lParam);
	DECLARE_MESSAGE_MAP()
	
	
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);


	long  DowanloadByName(LPCTSTR sDVRFileName);
	CString  FindFile(long nChannel, NET_TIME StartTime ,NET_TIME StopTime);
	BOOL LogIn(LPCTSTR sDVRIP, short wDVRPort, LPCTSTR sUserName, LPCTSTR sPassword) ;
	BOOL LogOut();
	int  FindHandleAndGetPos(LONG hHandle);
	int   FindHandleAndStop(LONG hHandle);
	short GetDownloadPos(long hHandle) ;
	LONG  DowanloadByTime(long lChannel,NET_TIME StartTime ,NET_TIME StopTime,LONG hHandle, short nType) ;
	BOOL StopDownLoad(long hHandle) ;
	CDownLoad *m_pDownload;
	list<CDownLoad *> m_listDown;


	void SetPlayFileName(CString szFileName);
	
	void SetPlayState(int iState);
		
	void MP4Dec();

	BOOL Play(int nType);
	CRect m_rectVedio;
	CRect m_rectVedioInit;

	void StopPlay();

	BOOL m_bIsPlaying;
	int	m_nType ;   // �ļ�����  1 �� mp4   2 �� avi  -1 ��������
	HANDLE m_hThreadHandle ;

	LONG m_hStartImageShow;
	int m_nFrameTime;

	//DWORD m_nCurrentTime;
	BOOL m_bIsPause ;
	DWORD m_TotalTime;
	DWORD m_TotalFrames;
	
	HWND  m_hPlayWnd ;
	
	LONG m_lWidth;  // ��ʵ�Ŀ���
	LONG m_lHeight;

	LONG m_lShowWidth;
	LONG m_lShowHeight; //��ʾ�Ŀ���

	LONG m_lPlayPort;

	
	CMutex m_listMutex;
	BOOL m_bIsLogin ;//
	LONG m_lLogId;
	CString m_szFileName;  //�ļ���
	

	HBITMAP  m_hPlayEnableBit;

	HICON m_hPlayEnableIcon;
	HICON m_hPlayDisableIcon;
	
	HICON m_hPauseEnableIcon;
	HICON m_hPauseDisableIcon;
	
	HICON m_hStopEnableIcon;
	HICON m_hStopDisableIcon;
	
	HICON m_hOpenFileEnableIcon;
	HICON m_hOpenFileDisableIcon;

	HICON m_hLightEnableIcon;  //����
	HICON m_hLightDisableIcon;

	HICON m_hDellumpEnableIcon;   // ȥ��
	HICON m_hDellumpDisableIcon;

	HICON m_hContrastEnableIcon; // �Աȶ�
	HICON m_hContrastDisableIcon;

	HICON m_hSharpenEnableIcon;  //��
	HICON m_hSharpenDisableIcon;
	////////////////////////////
	CRectTracker m_rectTracker;
	BOOL  IsInVedio(CPoint point);
	BOOL m_bInRect;
	CRect m_clientVedioRect;


	CRect rect;
	BOOL IsLButtonDown;//�������Ƿ���
	CPoint pt_start;//��Ƥ���������ʼ�㣨����������ʱ��
	CPoint pt_end;//��Ƥ���������ֹ�㣨�������ɿ�ʱ��


	AlgorithmParamX m_apx ;
	int	m_nAlgMask;


	afx_msg void OnBnClickedBtnOpen();
	afx_msg void OnNMCustomdrawSliderBlowup(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawSliderLight(NMHDR *pNMHDR, LRESULT *pResult);
	int m_nContrast;    // �Աȶ�
	int m_nLight;       // ����
	int m_nDelLump;     // ȥ��
	int m_nCheck;       // У��
	int m_nSharPening;  // ��
	afx_msg void OnNMCustomdrawSliderDellump(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawSliderCheck(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMCustomdrawSliderPlay(NMHDR *pNMHDR, LRESULT *pResult);
	
//	afx_msg void OnBnClickedBtnDellump();
	CButtonST m_btnPlay;
	CButtonST m_btnTest;
	afx_msg void OnNMCustomdrawSliderSharpening(NMHDR *pNMHDR, LRESULT *pResult);
	CButtonST m_btnOpen;

	int m_nAlgCount;

	BOOL m_bBtnDellump;   //ȥ��
	BOOL m_bBtnContrast;// �Աȶ�
	BOOL m_bBtnLight;   //����
	BOOL m_bBtnSharpeng;// ��
	void InitSliderUi();
	HCURSOR			m_hHandCur;	
	HCURSOR GetSysHandCursor();

	afx_msg void OnNMCustomdrawSliderContrast(NMHDR *pNMHDR, LRESULT *pResult);
	CButtonST m_btnLight;
	CButtonST m_btnStop;
	CButtonST m_btnTest3;
	CButtonST m_btnDelLump;
	CButtonST m_btnContrast;
	CButtonST m_btnSharpening;
	void InitAlgBtn();
	afx_msg void OnNMReleasedcaptureSliderLight(NMHDR *pNMHDR, LRESULT *pResult);

	int m_nColorTypeIndex;
	afx_msg void OnBnClickedCheckAncj();
	afx_msg void OnBnClickedCheckLg();
	afx_msg void OnBnClickedCheckWy();
	afx_msg void OnBnClickedCheckLcj();
	afx_msg void OnBnClickedCheckFs();
	afx_msg void OnBnClickedCheckSdjh();
	int m_nSceneType;
	int SetAllNoCheck();


};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DOWN_CLEAR_OCXPPG_H__88FB38AC_F5C5_41AA_B191_F22CAD4170EB__INCLUDED)
