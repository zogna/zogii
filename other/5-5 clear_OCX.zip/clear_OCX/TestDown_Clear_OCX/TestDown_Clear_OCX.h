// TestDown_Clear_OCX.h : main header file for the TESTDOWN_CLEAR_OCX application
//

#if !defined(AFX_TESTDOWN_CLEAR_OCX_H__7C57292A_A69B_420B_84AB_EB8D64C8DC2B__INCLUDED_)
#define AFX_TESTDOWN_CLEAR_OCX_H__7C57292A_A69B_420B_84AB_EB8D64C8DC2B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTestDown_Clear_OCXApp:
// See TestDown_Clear_OCX.cpp for the implementation of this class
//

class CTestDown_Clear_OCXApp : public CWinApp
{
public:
	CTestDown_Clear_OCXApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestDown_Clear_OCXApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTestDown_Clear_OCXApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTDOWN_CLEAR_OCX_H__7C57292A_A69B_420B_84AB_EB8D64C8DC2B__INCLUDED_)
