// TestDown_Clear_OCXDlg.h : header file
//
//{{AFX_INCLUDES()
#include "down_clear_ocx.h"
//}}AFX_INCLUDES

#if !defined(AFX_TESTDOWN_CLEAR_OCXDLG_H__C2AE51F9_2A24_4670_866D_879195401BB1__INCLUDED_)
#define AFX_TESTDOWN_CLEAR_OCXDLG_H__C2AE51F9_2A24_4670_866D_879195401BB1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTestDown_Clear_OCXDlg dialog

class CTestDown_Clear_OCXDlg : public CDialog
{
// Construction
public:
	CTestDown_Clear_OCXDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTestDown_Clear_OCXDlg)
	enum { IDD = IDD_TESTDOWN_CLEAR_OCX_DIALOG };
	CDown_Clear_OCX	m_ocx;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestDown_Clear_OCXDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTestDown_Clear_OCXDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTDOWN_CLEAR_OCXDLG_H__C2AE51F9_2A24_4670_866D_879195401BB1__INCLUDED_)
