#include "StdAfx.h"
#define DOWNLOAD_DLL  
#include "DownLoad.h"
#include "HCNetSDK.h"
#include <string>
using namespace std;

/*
CDownLoad*   CreateInstance()
{
	return new CDownLoad();

}
*/


BOOL SDK_Init()
{

	int nRet = 0;
	nRet = NET_DVR_Init();
	
	NET_DVR_SetConnectTime(2000, 1); 
	NET_DVR_SetReconnect(10000, true);
	return nRet;

}
 BOOL SDK_Cleanup()
{
	return NET_DVR_Cleanup();
}


CDownLoad::CDownLoad()
{ 
//	m_lUserID = -1;
	m_sDVRIP = NULL;
	m_wDVRPort = 0;
	m_sUserName = 0;
	m_sPassword = 0;
	m_lPos = 0;
//	m_lLoginID = -1;
	m_IsDownloading = FALSE;
	m_lLoginID =-1;

	m_nStartDChan = -1;



}


int   CDownLoad::LogIn(char *sDVRIP,WORD wDVRPort,char *sUserName,char *sPassword)
{

	if( m_lLoginID !=-1)
	{
		return 1;

	}
	if(sDVRIP == NULL || sUserName == NULL || sPassword == NULL)
	{
		return -2;//
	}

	m_lLoginID = NET_DVR_Login_V30(sDVRIP,wDVRPort, sUserName,sPassword,0);
	NET_DVR_IPPARACFG_V40 IPAccessCfgV40;
	DWORD nRet = -1;

	if(m_lLoginID < 0)
	{
	
		return -1; //��½ʧ��
	}
	NET_DVR_GetDVRConfig(m_lLoginID,NET_DVR_GET_IPPARACFG_V40,0, &IPAccessCfgV40,sizeof(NET_DVR_IPPARACFG_V40 ), &nRet);
	if(IPAccessCfgV40.dwStartDChan>0)
	{
		m_nStartDChan= IPAccessCfgV40.dwStartDChan;
		
	}
	

	return 1;
}

int   CDownLoad::Logout()
{
	if(m_lLoginID == -1)
	{
		return 0;
	}
	if(m_lDownloadHandle != -1)
		NET_DVR_StopGetFile(m_lDownloadHandle);

	return  NET_DVR_Logout(m_lLoginID);
}
/************************************************************************/
/*return :

/*  1   �������سɹ�
/* -1   û�е�¼
   -3   ��������ʧ��    
   -4   �����ļ���                                                    */
/************************************************************************/
int CDownLoad::DowanloadByName( char *sDVRFileName,char *sSavedFileName)
{
	if(m_lLoginID == -1)
	{
		return -1; // û�е�¼
	}
	if( m_IsDownloading)
	{
		return -2;//�Ѿ���һ��������
	}	
	char *pFileName = sDVRFileName;	

	m_lDownloadHandle = NET_DVR_GetFileByName (m_lLoginID,pFileName,sSavedFileName);

	if (m_lDownloadHandle >= 0)
	{
		if(!NET_DVR_PlayBackControl(m_lDownloadHandle, NET_DVR_PLAYSTART, 0, NULL))
		{
			return -3;// ��������ʧ��
		}
		m_IsDownloading = TRUE;
		return 1;// �������سɹ�
		
	}
	else
	{
		return -4; // �����ļ���
	}
}


/************************************************************************/
/*1;// �������سɹ�
/*    -1; //û�е�¼
-3;// ��������ʧ��  
 -4;//��ʱ������ʧ��                                                               */
/************************************************************************/
int CDownLoad::DowanloadByTime(LONG lChannel, NET_TIME StartTime, NET_TIME StopTime, char *sSavedFileName,int nType)
{
	LONG channelTemp = lChannel;
	if(m_nStartDChan >0)
	{
		channelTemp += (m_nStartDChan-1);

	}
	if(m_lLoginID == -1)
	{
		return -1; // û�е�¼
	}
	if(m_IsDownloading)
	{
		return -2 ;// �Ѿ����ļ���������
	}

	NET_DVR_TIME DVR_startTime;
	DVR_startTime.dwYear = StartTime.dwYear;
	DVR_startTime.dwMonth = StartTime.dwMonth;
	DVR_startTime.dwDay  = StartTime.dwDay;
	DVR_startTime.dwHour = StartTime.dwHour;
	DVR_startTime.dwMinute = StartTime.dwMinute;
	DVR_startTime.dwSecond = StartTime.dwSecond;
	
	NET_DVR_TIME DVR_stopTime;
	DVR_stopTime.dwYear = StopTime.dwYear;
	DVR_stopTime.dwMonth = StopTime.dwMonth;
	DVR_stopTime.dwDay  = StopTime.dwDay;
	DVR_stopTime.dwHour = StopTime.dwHour;
	DVR_stopTime.dwMinute = StopTime.dwMinute;
	DVR_stopTime.dwSecond = StopTime.dwSecond;
	
	NET_DVR_PLAYCOND  struDownloadCond={0};
	//struDownloadCond.dwChannel=lChannel; //ͨ����
	struDownloadCond.dwChannel=channelTemp; //ͨ����
	struDownloadCond.struStartTime = DVR_startTime ; 
	 struDownloadCond.struStopTime =  DVR_stopTime;

	//m_lDownloadHandle =  NET_DVR_GetFileByTime(m_lLoginID,lChannel,&DVR_startTime, &DVR_stopTime, sSavedFileName);
	m_lDownloadHandle =  NET_DVR_GetFileByTime_V40(m_lLoginID,sSavedFileName,&struDownloadCond);

	if(m_lDownloadHandle >= 0)
	{

		//if(!NET_DVR_PlayBackControl(m_lDownloadHandle, NET_DVR_PLAYSTART,0, NULL))
		if(!NET_DVR_PlayBackControl_V40(m_lDownloadHandle, NET_DVR_PLAYSTART,0, NULL))
		{
			return -3;// ��������ʧ��

		}
		m_IsDownloading = TRUE;
		return 1;// �������سɹ�

	}
	else
	{
		return  -4;//��ʱ������ʧ��
	}


}


 /************************************************************************/
 /* return
  /*-1��ʾʧ�ܣ�0��100��ʾ���صĽ��ȣ�100��ʾ���ؽ�����������Χ0-100������200�������������쳣                                                                     */
 /************************************************************************/
int CDownLoad::GetDownloadPos()
{
	int  pos;
	if(m_lDownloadHandle <0)
	{
		return -1;

	}
	pos = NET_DVR_GetDownloadPos(m_lDownloadHandle);
	if(pos == 100)
	{
		NET_DVR_StopGetFile(m_lDownloadHandle);
		m_IsDownloading = FALSE;
		m_lDownloadHandle = -1;

	}
	else if(pos == 200) // �����쳣
	{
		NET_DVR_StopGetFile(m_lDownloadHandle);
		m_IsDownloading = FALSE;
		m_lDownloadHandle = -1;		
	}
	return pos;

}

/************************************************
int CDownLoad::GetDownloadPosByTime()
{
	int  pos;
	pos = NET_DVR_GetDownloadPos(m_lDownloadHandle);
	if(pos == 100)
	{
		NET_DVR_StopGetFile(m_lDownloadHandle);
		m_IsDownloading = FALSE;
		m_lDownloadHandle = -1;
		
	}
	else if(pos == 200) // �����쳣
	{
		
		NET_DVR_StopGetFile(m_lDownloadHandle);
		m_IsDownloading = FALSE;
		m_lDownloadHandle = -1;		
	}
	return pos;
	
}
**********/



void CopyNetDvrTimeToNetTime(NET_TIME &nettime,NET_DVR_TIME &netdvrtime)
{
	nettime.dwYear = netdvrtime.dwYear;
	nettime.dwMonth = netdvrtime.dwMonth;
	nettime.dwDay  = netdvrtime.dwDay;
	nettime.dwHour = netdvrtime.dwHour;
	nettime.dwMinute = netdvrtime.dwMinute;
	nettime.dwSecond = netdvrtime.dwSecond;
	

}

int  CDownLoad::FindFileAndFileTime2struct(LONG lChannel,NET_TIME StartTime,NET_TIME StopTime ,int nFileType ,void *pUser,FILEINFO *pFileInfo,int max)
{
	LONG channelTemp = lChannel;
	if(m_nStartDChan >0)
	{
		channelTemp += (m_nStartDChan-1);
		
	}
	NET_DVR_FILECOND_V40 m_struFileCond;
	memset(&m_struFileCond,0,sizeof(NET_DVR_FILECOND_V40));
	//m_struFileCond.lChannel = nChannel;

	m_struFileCond.lChannel = channelTemp;
	NET_DVR_TIME DVR_startTime;
	DVR_startTime.dwYear = StartTime.dwYear;
	DVR_startTime.dwMonth = StartTime.dwMonth;
	DVR_startTime.dwDay  = StartTime.dwDay;
	DVR_startTime.dwHour = StartTime.dwHour;
	DVR_startTime.dwMinute = StartTime.dwMinute;
	DVR_startTime.dwSecond = StartTime.dwSecond;

	NET_DVR_TIME DVR_stopTime;
	DVR_stopTime.dwYear = StopTime.dwYear;
	DVR_stopTime.dwMonth = StopTime.dwMonth;
	DVR_stopTime.dwDay  = StopTime.dwDay;
	DVR_stopTime.dwHour = StopTime.dwHour;
	DVR_stopTime.dwMinute = StopTime.dwMinute;
	DVR_stopTime.dwSecond = StopTime.dwSecond;

	m_struFileCond.struStartTime = DVR_startTime;
	m_struFileCond.struStopTime = DVR_stopTime;

	m_struFileCond.dwFileType = nFileType;
	m_struFileCond.dwIsLocked = 0xff;	
	m_struFileCond.dwUseCardNo = 0;
	m_lFileHandle = NET_DVR_FindFile_V40(m_lLoginID, &m_struFileCond);
	
	if (m_lFileHandle < 0)
	{
		return -1;
	}
	LONG lRet = -1;
	NET_DVR_FINDDATA_V40 struFileInfo;
	memset(&struFileInfo, 0, sizeof(struFileInfo));

	int nFileCount =0;

	while(1)
	{
		lRet = NET_DVR_FindNextFile_V40(m_lFileHandle, &struFileInfo);
		if (lRet == NET_DVR_FILE_SUCCESS)
		{		
	
			FILEINFO temp={0};
			strcpy(temp.m_bufFileName,struFileInfo.sFileName);

			CopyNetDvrTimeToNetTime(temp.m_startTime,struFileInfo.struStartTime);
			CopyNetDvrTimeToNetTime(temp.m_stopTime,struFileInfo.struStopTime);
			temp.m_dwFileSize = struFileInfo.dwFileSize;	
			if(nFileCount<max)
			{
				memcpy(&pFileInfo[nFileCount],&temp,sizeof(FILEINFO));
			}
			
			nFileCount ++;
		}
		else
		{
			if (lRet == NET_DVR_ISFINDING)
			{
				Sleep(5);
				continue;
			}
			if ((lRet == NET_DVR_NOMOREFILE) || (lRet == NET_DVR_FILE_NOFIND))
			{
				break;
			}
			else
			{
				break;
			}
		}
	}

	NET_DVR_FindClose_V30(m_lFileHandle);
	m_lFileHandle = -1;

	if(nFileCount>0)
	{
		return nFileCount;
	}
	else
	{
		return 0 ;
	}
}

/*
int  CDownLoad::FindFileAndFileTime(LONG nChannel,NET_TIME StartTime,NET_TIME StopTime ,std::vector<FILEINFO * > &FileInfo)
{
	NET_DVR_FILECOND_V40 m_struFileCond;
	memset(&m_struFileCond,0,sizeof(NET_DVR_FILECOND_V40));
	m_struFileCond.lChannel = nChannel;
	NET_DVR_TIME DVR_startTime;
	DVR_startTime.dwYear = StartTime.dwYear;
	DVR_startTime.dwMonth = StartTime.dwMonth;
	DVR_startTime.dwDay  = StartTime.dwDay;
	DVR_startTime.dwHour = StartTime.dwHour;
	DVR_startTime.dwMinute = StartTime.dwMinute;
	DVR_startTime.dwSecond = StartTime.dwSecond;

	NET_DVR_TIME DVR_stopTime;
	DVR_stopTime.dwYear = StopTime.dwYear;
	DVR_stopTime.dwMonth = StopTime.dwMonth;
	DVR_stopTime.dwDay  = StopTime.dwDay;
	DVR_stopTime.dwHour = StopTime.dwHour;
	DVR_stopTime.dwMinute = StopTime.dwMinute;
	DVR_stopTime.dwSecond = StopTime.dwSecond;

	m_struFileCond.struStartTime = DVR_startTime;
	m_struFileCond.struStopTime = DVR_stopTime;

	m_struFileCond.dwFileType = 0xff;
	m_struFileCond.dwIsLocked = 0xff;	
	m_struFileCond.dwUseCardNo = 0;
	m_lFileHandle = NET_DVR_FindFile_V40(m_lLoginID, &m_struFileCond);
	
	if (m_lFileHandle < 0)
	{
		return -1;
	}
	LONG lRet = -1;
	NET_DVR_FINDDATA_V40 struFileInfo;
	memset(&struFileInfo, 0, sizeof(struFileInfo));

	int nFileCount =0;


	vector<FILEINFO> FileInfoTemp;


	while(1)
	{
		lRet = NET_DVR_FindNextFile_V40(m_lFileHandle, &struFileInfo);
		if (lRet == NET_DVR_FILE_SUCCESS)
		{		

			FILEINFO *temp = new FILEINFO;
			strcpy(temp->m_bufFileName,struFileInfo.sFileName);

			CopyNetDvrTimeToNetTime(temp->m_startTime,struFileInfo.struStartTime);
			CopyNetDvrTimeToNetTime(temp->m_stopTime,struFileInfo.struStopTime);
			temp->m_dwFileSize = struFileInfo.dwFileSize;			
			FileInfo.push_back(temp);

			nFileCount ++;
		}
		else
		{
			if (lRet == NET_DVR_ISFINDING)
			{
				Sleep(5);
				continue;
			}
			if ((lRet == NET_DVR_NOMOREFILE) || (lRet == NET_DVR_FILE_NOFIND))
			{
				break;
			}
			else
			{
				break;
			}
		}
	}

	NET_DVR_FindClose_V30(m_lFileHandle);
	m_lFileHandle = -1;

	if(nFileCount>0)
	{
	//	FileInfo.push_back(FileInfoTemp[1]);
		return nFileCount;
	}
	else
	{
		return 0 ;
	}
}
int  CDownLoad::FindFileAndFileTime(LONG nChannel,NET_TIME StartTime,NET_TIME StopTime ,vector<FILEINFO > *FileInfo)
{
	NET_DVR_FILECOND_V40 m_struFileCond;
	memset(&m_struFileCond,0,sizeof(NET_DVR_FILECOND_V40));
	m_struFileCond.lChannel = nChannel;
	NET_DVR_TIME DVR_startTime;
	DVR_startTime.dwYear = StartTime.dwYear;
	DVR_startTime.dwMonth = StartTime.dwMonth;
	DVR_startTime.dwDay  = StartTime.dwDay;
	DVR_startTime.dwHour = StartTime.dwHour;
	DVR_startTime.dwMinute = StartTime.dwMinute;
	DVR_startTime.dwSecond = StartTime.dwSecond;

	NET_DVR_TIME DVR_stopTime;
	DVR_stopTime.dwYear = StopTime.dwYear;
	DVR_stopTime.dwMonth = StopTime.dwMonth;
	DVR_stopTime.dwDay  = StopTime.dwDay;
	DVR_stopTime.dwHour = StopTime.dwHour;
	DVR_stopTime.dwMinute = StopTime.dwMinute;
	DVR_stopTime.dwSecond = StopTime.dwSecond;

	m_struFileCond.struStartTime = DVR_startTime;
	m_struFileCond.struStopTime = DVR_stopTime;

	m_struFileCond.dwFileType = 0xff;
	m_struFileCond.dwIsLocked = 0xff;	
	m_struFileCond.dwUseCardNo = 0;
	m_lFileHandle = NET_DVR_FindFile_V40(m_lLoginID, &m_struFileCond);
	
	if (m_lFileHandle < 0)
	{
		return -1;
	}
	LONG lRet = -1;
	NET_DVR_FINDDATA_V40 struFileInfo;
	memset(&struFileInfo, 0, sizeof(struFileInfo));

	int nFileCount =0;


	vector<FILEINFO> FileInfoTemp;


	while(1)
	{
		lRet = NET_DVR_FindNextFile_V40(m_lFileHandle, &struFileInfo);
		if (lRet == NET_DVR_FILE_SUCCESS)
		{		

			FILEINFO temp;
			strcpy(temp.m_bufFileName,struFileInfo.sFileName);

			CopyNetDvrTimeToNetTime(temp.m_startTime,struFileInfo.struStartTime);
			CopyNetDvrTimeToNetTime(temp.m_stopTime,struFileInfo.struStopTime);
			temp.m_dwFileSize = struFileInfo.dwFileSize;			
			FileInfoTemp.push_back(temp);

			nFileCount ++;
		}
		else
		{
			if (lRet == NET_DVR_ISFINDING)
			{
				Sleep(5);
				continue;
			}
			if ((lRet == NET_DVR_NOMOREFILE) || (lRet == NET_DVR_FILE_NOFIND))
			{
				break;
			}
			else
			{
				break;
			}
		}
	}

	NET_DVR_FindClose_V30(m_lFileHandle);
	m_lFileHandle = -1;

	if(nFileCount>0)
	{
	//	FileInfo->push_back(FileInfoTemp[1]);
		return nFileCount;
	}
	else
	{
		return 0 ;
	}
}
*/


BOOL CDownLoad::FindFile(LONG lChannel,NET_TIME StartTime,NET_TIME StopTime ,char *pBuff,int nSize,int nFileType)
{

	//  NET_DVR_FILECOND_V40 struFileCond={0};
	NET_DVR_FILECOND struFileCond={0};
	LONG channelTemp = lChannel;
	if(m_nStartDChan >0)
	{
		channelTemp += (m_nStartDChan-1);
		
	}
	//struFileCond.lChannel = lChannel;
	struFileCond.lChannel = channelTemp;
	struFileCond.dwFileType = nFileType;   // �����ļ�
	struFileCond.dwIsLocked = 0xff;   // 0xff��ʾ�����ļ�

	struFileCond.dwUseCardNo = 0;     //


	NET_DVR_TIME DVR_startTime;
	DVR_startTime.dwYear = StartTime.dwYear;
	DVR_startTime.dwMonth = StartTime.dwMonth;
	DVR_startTime.dwDay  = StartTime.dwDay;
	DVR_startTime.dwHour = StartTime.dwHour;
	DVR_startTime.dwMinute = StartTime.dwMinute;
	DVR_startTime.dwSecond = StartTime.dwSecond;

	NET_DVR_TIME DVR_stopTime;
	DVR_stopTime.dwYear = StopTime.dwYear;
	DVR_stopTime.dwMonth = StopTime.dwMonth;
	DVR_stopTime.dwDay  = StopTime.dwDay;
	DVR_stopTime.dwHour = StopTime.dwHour;
	DVR_stopTime.dwMinute = StopTime.dwMinute;
	DVR_stopTime.dwSecond = StopTime.dwSecond;

	struFileCond.struStartTime = DVR_startTime;
	struFileCond.struStopTime = DVR_stopTime;

	m_lFileHandle = NET_DVR_FindFile_V30(m_lLoginID, &struFileCond);

//	m_lFileHandle = NET_DVR_FindFile_V30(m_lLoginID, &struFileCond);
	if (m_lFileHandle < 0)
	{

		return FALSE;
	}
	LONG lRet = -1;
	//NET_DVR_FINDDATA_V40 struFileInfo;
	NET_DVR_FINDDATA_V30 struFileInfo;
	memset(&struFileInfo, 0, sizeof(struFileInfo));

	string FileName ;

	char szLan[128] = {0};
	int nFileCount =0;
	
	while(1)
	{
		lRet = NET_DVR_FindNextFile_V30(m_lFileHandle, &struFileInfo);
		if (lRet == NET_DVR_FILE_SUCCESS)
		{		
			//strcpy(pFileName, struFileInfo.sFileName);
			if(nFileCount>1000)  break;
			string temp = struFileInfo.sFileName;
			FileName += temp;
			FileName +=";";
		
			nFileCount ++;
		}
		else
		{
			if (lRet == NET_DVR_ISFINDING)
			{
				Sleep(5);
				continue;
			}
			if ((lRet == NET_DVR_NOMOREFILE) || (lRet == NET_DVR_FILE_NOFIND))
			{
				break;
			}
			else
			{

				break;
			}
		}
	}
	NET_DVR_FindClose_V30(m_lFileHandle);

	m_lFileHandle = -1;
	if(nFileCount>0)
	{
		
		try
		{
			int nBufCount = FileName.length()+20;
			if(nBufCount>nSize)  return FALSE;

			sprintf(pBuff,"%d;%s",nFileCount ,FileName.c_str());

			return TRUE;

		}
		catch(...)
		{
			return FALSE;
		}

	}
	else
	{
		if( lRet == NET_DVR_FILE_EXCEPTION )
		{
			return FALSE;	
		}
		else
		{
			sprintf(pBuff,"0;");
			return TRUE;
		}

	}
}


void CDownLoad::GetLogId(LONG *logId)
{
	(*logId) = m_lLoginID;

}

void CDownLoad::SetLogId(LONG logId)
{
	m_lLoginID = logId ;
	
}

BOOL CDownLoad::StopDownLoad()
{
	if(!NET_DVR_StopGetFile(m_lDownloadHandle))
	{
		return FALSE;
	
	}

	m_IsDownloading = FALSE;
	return TRUE;
}

