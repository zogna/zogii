/*
#ifdef DOWNLOAD_DLL

#define  DOWNLOAD_DLL_API extern "C" __declspec(dllexport)
#else
#define  DOWNLOAD_DLL_API extern "C" __declspec(dllimport)

#endif //DLL_API




DOWNLOAD_DLL_API LONG  NET_DownLoadByName(char *sDVRIP,WORD wDVRPort,char *sUserName,char *sPassword,\
											 char *sDVRFileName,char *sSavedFileName);

DOWNLOAD_DLL_API int  NET_GetDownloadPos(LONG hHandle);
DOWNLOAD_DLL_API int  NET_StopDownloadPos(LONG hHandle);
//DOWNLOAD_DLL_API char*  NET_GetIndexFileName(char *sDVRIP,WORD wDVRPort,char *sUserName,char *sPassword,);

//NET_DVR_FindFile_V40(LONG lUserID,LPNET_DVR_FILECOND_V40 pFindCond)

  */