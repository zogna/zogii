========================================================================
       Email Check program.
       Witten by Sergey Chepurin
       Developed in Visual C++ 6.0 on C/C++ with MFC,  04.2009
	   Upgraded to VC++ 2008, 04.2011
========================================================================
----------------------------------------------------------------------------------------
NOTE on VS C++ 6.0:   bulding "Relase" version of the application set /MTd compiler's 
	option instead of /MT (thus, using the LIBCMTD.LIB debug library instead of LIBCMT.LIB). 
	Otherwise you'll get the "Access violation" error when reading the mail's file.
------------------------------------------------------------------------------------
1. Can read only ASCII (Latin alphabet) email from multiple POP accounts.
2. Can receive attachments but they have to be decoded by external base64 decoding applications (for example, online services).
3. Text in languages outside ASCII have to be decoded by external quoted printable decoding applications (for example, online services).
------------------------------------------------------------------------------------------------------

AppWizard has created this Email application for you.  This application
not only demonstrates the basics of using the Microsoft Foundation classes
but is also a starting point for writing your application.

This file contains a summary of what you will find in each of the files that
make up your Email application.

Email.dsp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.dsp) file, but they should export the makefiles locally.

Email.h
    This is the main header file for the application.  It includes other
    project specific headers (including Resource.h) and declares the
    CEmailApp application class.

Email.cpp
    This is the main application source file that contains the application
    class CEmailApp.

Email.rc
    This is a listing of all of the Microsoft Windows resources that the
    program uses.  It includes the icons, bitmaps, and cursors that are stored
    in the RES subdirectory.  This file can be directly edited in Microsoft
	Visual C++.

Email.clw
    This file contains information used by ClassWizard to edit existing
    classes or add new classes.  ClassWizard also uses this file to store
    information needed to create and edit message maps and dialog data
    maps and to create prototype member functions.

res\Email.ico
    This is an icon file, which is used as the application's icon.  This
    icon is included by the main resource file Email.rc.

res\Email.rc2
    This file contains resources that are not edited by Microsoft 
	Visual C++.  You should place all resources not editable by
	the resource editor in this file.



/////////////////////////////////////////////////////////////////////////////

For the main frame window:

MainFrm.h, MainFrm.cpp
    These files contain the frame class CMainFrame, which is derived from
    CFrameWnd and controls all SDI frame features.

/////////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named Email.pch and a precompiled types file named StdAfx.obj.

Resource.h
    This is the standard header file, which defines new resource IDs.
    Microsoft Visual C++ reads and updates this file.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.

If your application uses MFC in a shared DLL, and your application is 
in a language other than the operating system's current language, you
will need to copy the corresponding localized resources MFC42XXX.DLL
from the Microsoft Visual C++ CD-ROM onto the system or system32 directory,
and rename it to be MFCLOC.DLL.  ("XXX" stands for the language abbreviation.
For example, MFC42DEU.DLL contains resources translated to German.)  If you
don't do this, some of the UI elements of your application will remain in the
language of the operating system.

/////////////////////////////////////////////////////////////////////////////
License information:

This product includes an open source and code available under MIT license 
(free software license).  
			
Initial code is partially taken from NetManager program - an open source 			
by Petr Stejskal (www.codeguru.com, released on December 1998).
It was corrected (when needed) and adapted by S.Chepurin, 02.2009.

Other open source code used:
	- POP3 protocol wrapper class is written by Asif Rasheed and
	updated by Robert E. Peters (www.codeguru.com), 1998.
	- SMTP and Base64 encode wrapper class is written by PJ Naughter 
	(www.naughter.com).

This product includes software (Base64 decode functions) developed by Bob Trower, 
Trantor Standard Systems Inc. Available under MIT license.
/////////////////////////////////////////////////////////////////////////////
Copyright information:

Copyright (c) 2001 Bob Trower, Trantor Standard Systems Inc.

                Permission is hereby granted, free of charge, to any person
                obtaining a copy of this software and associated
                documentation files (the "Software"), to deal in the
                Software without restriction, including without limitation
                the rights to use, copy, modify, merge, publish, distribute,
                sublicense, and/or sell copies of the Software, and to
                permit persons to whom the Software is furnished to do so,
                subject to the following conditions:

                The above copyright notice and this permission notice shall
                be included in all copies or substantial portions of the
                Software.

                THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
                KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
                WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
                PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
                OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
                OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
                OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
                SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.



