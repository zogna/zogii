// MailReceive.cpp : implementation file
//

#include "stdafx.h"

#include "Email.h"
#include "Pop3.h"

#include <iostream.h>//common input/output operations in C++
#include <fstream.h>//input/output files in C++


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define _AFX_SOCK_THREAD_STATE AFX_MODULE_THREAD_STATE
#define _afxSockThreadState AfxGetModuleThreadState()


//Variables used in MailAccount.cpp translation unit:
int nEditAccount;//condition variable
int nItem=0;		//item's number in the list 

//Variables used in this translation unit:
//variable to store name of selected account (the server connected)
CString csMailAccount;
CString userName;//variable to store username 
int nMailNum ;
CString csFileName;//file to store received emails

CString csInQuotes;//name of attachment file in quotes to compose a start search pattern
CString csBoundary;//attachment's boundary string to compose an end search pattern
CString csAttachmentFile;//name of attachment file
//CString csExtension;//file's extension

//Conditon variable to clear the "Mails" list box 
//if communication was interrupted by the user:
int nSocketClosed=0;
//Variable used to get the thread id:
int nThreadID; 

//Condition variable providing option 
//to delete/leave a copy of the mail on server: 
int nDeleteFromServer=1;

///Related to Base64 decode:///////////////////////////////////
// 
// Translation Table to decode Base64 (created by B.Trower)
static const char cd64[]="|$$$}rstuvwxyz{$$$$$$$>?@ABCDEFGHIJKLMNOPQRSTUVW$$$$$$XYZ[\\]^_`abcdefghijklmnopq";

/////////////////////////////////////////////////////////////////////////////
// CMailPop3 dialog

IMPLEMENT_DYNCREATE(CMailPop3, CDialog)

CMailPop3::CMailPop3() : CDialog(CMailPop3::IDD)
{
	//{{AFX_DATA_INIT(CMailPop3)
	//}}AFX_DATA_INIT
	
	//Usual MFC way to set an icon for a dialog:
	//m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	//m_hIcon = ::LoadIcon(AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_MAILBOX));

}

CMailPop3::~CMailPop3()
{
}

void CMailPop3::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMailPop3)
	DDX_Control(pDX, IDC_SERVERS, m_Servers);
	DDX_Control(pDX, IDC_MAILS, m_Mails);
	DDX_Control(pDX, IDC_PROGRESS_RECEIVE, m_ProgressBar);
	DDX_Control(pDX, IDC_MESSAGE, m_Message);
	DDX_Text(pDX, IDC_MESSAGE, m_sMessage);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMailPop3, CDialog)
	//{{AFX_MSG_MAP(CMailPop3)
	ON_COMMAND(ID_DONT_DELETE, OnDontDelete)
	ON_COMMAND(ID_DELETE_MESSAGES, OnDeleteFromServer)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_EDIT, OnEdit)
	ON_BN_CLICKED(IDC_REMOVE, OnRemove)
	ON_BN_CLICKED(IDC_RECEIVE, OnReceive)
	ON_NOTIFY(NM_DBLCLK, IDC_MAILS, OnReadMail)
	ON_NOTIFY(NM_DBLCLK, IDC_SERVERS, OnDblclkServers)
	ON_WM_SIZE()//calls ::OnSize after the window's size has changed
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMailPop3 member functions

BOOL CMailPop3::OnInitDialog() 
{
//Set the user defined icon for a dialog:
   SetIcon(AfxGetApp()->LoadIcon(IDI_MAILBOX), FALSE);
   SetIcon(AfxGetApp()->LoadIcon(IDI_MAILBOX), TRUE);

///////////////////////////////////////////////////////////////
//Prepare images to insert in header fields or list items:

	CDialog::OnInitDialog();

//Create image lists for header items:
	HD_ITEM hdrItem;
	CImageList * m_pImageHdrSmall;
	CEmailApp     *pApp;

	m_pImageHdrSmall = new CImageList();
	ASSERT(m_pImageHdrSmall != NULL);    // allocation failure checking
	// fill in image lists:
	m_pImageHdrSmall->Create(16, 16, ILC_MASK, 2, 2);
	m_pImageHdrSmall->Add(pApp->LoadIcon(IDI_CHECKMARK));
	//Image of clip to be used in "Attachment" column instead of text:
	m_pImageHdrSmall->Add(pApp->LoadIcon(IDI_CLIP));
//////////////////////////////////////////////////////////
// Create image list for column items:
	CImageList * m_pImageList;
	CImageList * m_pImageListSmall;
	m_pImageList = new CImageList();
	m_pImageListSmall = new CImageList();
	ASSERT(m_pImageList != NULL && m_pImageListSmall != NULL);    // serious allocation failure checking
	// fill in image lists (we'll use the same images as for the header):
	m_pImageList->Create(32, 32, TRUE,  2, 2);
	m_pImageListSmall->Create(16, 16, TRUE, 2, 2);
	m_pImageListSmall->Add(pApp->LoadIcon(IDI_CHECKMARK));
	m_pImageListSmall->Add(pApp->LoadIcon(IDI_CLIP));
/////////////////////////////////////////////////////////////
//1.Create a list control structure (set size and name to the columns):

	  m_Servers.InsertColumn(0, _T("POP3 server"));
	  m_Servers.SetColumnWidth(0, 150);
	  m_Servers.InsertColumn(1, _T("Username"));
	  m_Servers.SetColumnWidth(1, 200);
		
	  m_Mails.InsertColumn(0, _T("Account"));
	  m_Mails.SetColumnWidth(0, 100);
	  m_Mails.InsertColumn(1, _T(""));
	  m_Mails.SetColumnWidth(1, 40);

///Add an image to the "Attachment" header field:
  // retrieve embedded header control
	CHeaderCtrl* pHdrCtrl= NULL;
	pHdrCtrl= m_Mails.GetHeaderCtrl();

	pHdrCtrl->SetImageList(m_pImageHdrSmall);
	// add bmaps to each header item
	pHdrCtrl->GetItem(1, &hdrItem);
	hdrItem.mask= HDI_IMAGE | HDI_FORMAT;
	hdrItem.iImage= 1;
	hdrItem.fmt= HDF_LEFT | HDF_IMAGE | HDF_STRING;
	pHdrCtrl->SetItem(1, &hdrItem);

/////////////////////////////////////////////
	m_Mails.InsertColumn(2, _T("From"));
	m_Mails.SetColumnWidth(2, 220);
	m_Mails.InsertColumn(3, _T("Subject"));
	m_Mails.SetColumnWidth(3, 245);
	m_Mails.InsertColumn(4, _T("Date"));
	m_Mails.SetColumnWidth(4, 155);
///////////////////////////////////////////////////////
  //Allows to select the entire item's row (you can select any subitem):
	m_Servers.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_ONECLICKACTIVATE);
	m_Mails.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_ONECLICKACTIVATE |LVS_EX_SUBITEMIMAGES );

//2.Read account's initial data (use default, if absent): 

    char   IniFile[MAX_PATH]; 
    CHAR inBuf1[180]; 
	CHAR inBuf2[180];
   
//2.1 Get the path to current directory:
	GetCurrentDirectory(MAX_PATH, IniFile);
	
	//Add the name of .ini file to the path to current directory,
	//thus, assembling a full path:
	lstrcat( IniFile, "\\Settings.ini" ); 

//2.2 Get the account's data from .ini file: 
    ACCOUNT account;
	//First, get the total number of accounts:

	GetPrivateProfileString ("Accounts", "Number", 
							"0", inBuf2, 180, 
							IniFile);
	iNumAccounts=atoi(inBuf2);

	//Before you begin to use it, set the size of an MFC array:
	m_aAccounts.SetSize(iNumAccounts,NULL);
	
	//The account's numbering starts from one, thus initial i=1:
	for (int i=1; i<=iNumAccounts; i++)
		{	
		wsprintf(inBuf1,"%d", i);
	
		GetPrivateProfileString ("IncomingMail", inBuf1, 
								"", inBuf2, 180, 
								IniFile);
	//The array indexing starts from zero, thus initial index = i-1 
	//(because i is already=1):
		m_aAccounts[i-1].sServer =inBuf2;

		GetPrivateProfileString ("Username", inBuf1, 
								"", inBuf2, 180, 
								IniFile); 
		
		m_aAccounts[i-1].sUsername =inBuf2;

		GetPrivateProfileString ("Password", inBuf1, 
								"", inBuf2, 80, 
								IniFile); 
	
		m_aAccounts[i-1].sPassword =inBuf2;
	
		GetPrivateProfileString ("Port", inBuf1, 
								"", inBuf2, 20, 
								IniFile);
	
		m_aAccounts[i-1].nPort =atoi(inBuf2);
///////////////////////////////////////////////////////////////////////////
 
//2.3 Show the account's data in list control:
	
		//Retrieve the number of items in a MFC list view control:
		int nItem = m_Servers.GetItemCount();

		//Insert an item into the MFC list view control:
		m_Servers.InsertItem(nItem, LPCTSTR(m_aAccounts[i-1].sServer));
	
		//Change the text of a list view item or subitem
		//(int nItem, int nSubItem, LPTSTR lpszText), 
		// here, the subitem in second column:
		m_Servers.SetItemText(nItem, 1, LPCTSTR(m_aAccounts[i-1].sUsername ));
		m_aAccounts.Add(account);

		}
  return TRUE;  // return TRUE unless you set the focus to a control
	           
}
/////////////////////////////////////////
//Function to resize main dialog window
//(called by framework after the window's size has changed):
void CMailPop3::OnSize (UINT nType, int cx, int cy)
{
//  nType - Specifies the type of resizing requested,
//  cx,cy - new width and height of the client area
    //CWnd::OnSize(nType, cx, cy);

//Function prototype:
// void MoveWindow( int x, int y, int nWidth, int nHeight, BOOL bRepaint = TRUE );

//The task is to resize the dialog area with list boxes, edit box, 
//buttons and progress bar.	
	//Buttons (fixed size, only moved accordingly):
	CButton* pButton1 = (CButton *)GetDlgItem(IDC_ADD);
	pButton1->MoveWindow(cx-85, 20, 75, 25);
	CButton* pButton2 = (CButton *)GetDlgItem(IDC_EDIT);
	pButton2->MoveWindow(cx-85, 47, 75, 25);
	CButton* pButton3 = (CButton *)GetDlgItem(IDC_REMOVE);
	pButton3->MoveWindow(cx-85, 74, 75, 25);
	CButton* pButton4 = (CButton *)GetDlgItem(IDC_RECEIVE);
	pButton4->MoveWindow(cx-85, 101, 75, 25);
	CButton* pButton5 = (CButton *)GetDlgItem(IDC_REPLY);
	pButton5->MoveWindow(cx-85, 128, 75, 25);

	//List boxes (resizing width with fixed height): 
	m_Servers.MoveWindow (10, 20, cx-150, 130);
	m_Mails.MoveWindow (10, 170, cx-20, 180);

	//Edit box (resizing width with fixed height):
	m_Message.MoveWindow (10, 355, cx-20, 295);

	//Progress bar (fixed size, only moved accordingly):
	CProgressCtrl* pProgressBar = (CProgressCtrl *)GetDlgItem(IDC_PROGRESS_RECEIVE);
    pProgressBar->MoveWindow(10, cy-25, 120, 20);

//Call UpdateWindow member function to update the client area by sending 
//a WM_PAINT message if the update region is not empty.
//Also UpdateWindow function sends the window its first WM_PAINT message:
	//UpdateWindow();
} 
/////////////////////////////////////////////////////////////////////////////
//Function to add new account:
void CMailPop3::OnAdd() 
{
 CMailAccount dlg;

  if(dlg.DoModal() == IDOK)
  {
   		int nItem = m_Servers.GetItemCount();
		m_Servers.InsertItem(nItem, LPCTSTR(dlg.m_sServer));
		m_Servers.SetItemText(nItem, 1, LPCTSTR(dlg.m_sUsername));
    
		ACCOUNT account;
		account.sServer = dlg.m_sServer;
		account.nPort = dlg.m_nPort;
		account.sUsername = dlg.m_sUsername;
		account.sPassword = dlg.m_sPassword;
		m_aAccounts.Add(account);

		iNumAccounts =nItem;//get the new total number of accounts
  }
}

/////////////////////////////////////////////////////////////////////////////
//Function to edit selected account:
void CMailPop3::OnEdit() 
{

  CMailAccount dlg;
  nItem = -1;
  
  while((nItem = m_Servers.GetNextItem(nItem, LVNI_SELECTED)) != -1 )
  {
    dlg.m_sServer = m_aAccounts[nItem].sServer;
    dlg.m_nPort = m_aAccounts[nItem].nPort;
    dlg.m_sUsername = m_aAccounts[nItem].sUsername;
    dlg.m_sPassword = m_aAccounts[nItem].sPassword;

    nEditAccount =1;//set the condition variable

	if(dlg.DoModal() == IDOK)
    {
      
	  m_Servers.SetItemText(nItem, 0, LPCTSTR(dlg.m_sServer));
      m_Servers.SetItemText(nItem, 1, LPCTSTR(dlg.m_sUsername));
    
      ACCOUNT account;
      account.sServer = dlg.m_sServer;
      account.nPort = dlg.m_nPort;
      account.sUsername = dlg.m_sUsername;
      account.sPassword = dlg.m_sPassword;
      m_aAccounts.SetAt(nItem, account);

	  iNumAccounts =nItem;		  
    }
  }
}

/////////////////////////////////////////////////////////////////////////////
//Function to remove selected account:
void CMailPop3::OnRemove() 
{

  if(MessageBox("Do you want to remove account?", NULL, MB_ICONQUESTION | MB_YESNO) != IDNO)
  {
    int nItem = -1;
    while((nItem = m_Servers.GetNextItem(nItem, LVNI_SELECTED)) != -1)
    {
      m_Servers.DeleteItem(nItem);
      m_aAccounts.RemoveAt(nItem);

	//Save new configuration in .ini:

   char IniFile[MAX_PATH]; 
   char inBuf[180];
   char szTemporary[80];
   HANDLE  hFile; 
   
	//Get the path to current directory:
	GetCurrentDirectory(MAX_PATH, IniFile);

	//Add to path the name of .ini file:
	lstrcat( IniFile, "\\Settings.ini" ); 
	
    //We have to rewrite the .ini file every time the item is deleted:
     if( hFile = CreateFile( IniFile, 
                           GENERIC_WRITE, 
                           FILE_SHARE_READ, 
                           NULL, 
                           CREATE_ALWAYS,//use this option to create new file 
                           FILE_ATTRIBUTE_NORMAL, 
                           NULL)) 			
     CloseHandle(hFile); 

	 nItem = m_Servers.GetItemCount();
	 wsprintf(inBuf,"%d", nItem);
	 WritePrivateProfileString("Accounts", 
                               "Number", 
                                inBuf , 
                                IniFile);

	 
 	 for (int i=1; i<=nItem; i++)
		{  
		wsprintf(inBuf,"%d", i);
        WritePrivateProfileString("IncomingMail", 
                                   inBuf, 
                                   m_aAccounts[i-1].sServer, 
                                   IniFile);

		WritePrivateProfileString("Username", 
                                   inBuf, 
                                   m_aAccounts[i-1].sUsername , 
                                   IniFile); 

		WritePrivateProfileString("Password", 
                                   inBuf, 
                                   m_aAccounts[i-1].sPassword , 
                                   IniFile);

		wsprintf(szTemporary,"%d", m_aAccounts[i-1].nPort);
		WritePrivateProfileString("Port", 
                                   inBuf, 
                                   szTemporary , 
                                   IniFile);	
	
		}
//////////////////////////////////////////////////////////////////////
      nItem = -1;
    }
  }

}
////////////////////////////////////////////////////////////////////////
//Function to select mail account and receive mail if on-line:
void CMailPop3::OnDblclkServers() 
{
  	m_Mails.DeleteAllItems();//clear the Mails list control

	int nItem = -1;

	while((nItem = m_Servers.GetNextItem(nItem, LVNI_SELECTED)) != -1 )
	{ 
	//Define the name of the server connected (or selected).
	//This name is used to create file to receive emails:
		csMailAccount =m_aAccounts[nItem].sServer;
		csFileName =csMailAccount + (".dat");

		OnReceive();
	}
}
/////////////////////////////////////////////////////////////////////////////
//Function to receive mail and write it in the file:
void CMailPop3::OnReceive() 
{
 
//1. To have the new socket, create the instance of CThreadInfo class 
//   (structure/union) where we have a member of CPop3Comm class.
//   It is done to be able to pass a pointer to the socket in worker thread:
     CThreadInfo m_CThreadInfo;
     
 //2.Connect the POP3 server:
  int nItem = -1;
  while((nItem = m_Servers.GetNextItem(nItem, LVNI_SELECTED)) != -1)
  {  
/////////////////////////////////////////////////////////////////////
//Show progress bar while connecting to the server:

	int m_Min = 0;
	int m_Max = 100;
	m_ProgressBar.SetRange (m_Min, m_Max);
	m_ProgressBar.SetStep (1);

	//Set initial position of progress bar:
	m_ProgressBar.SetPos (0);
//1. Autorization state:////////////////////////////////////////////
	m_CThreadInfo.m_Pop3Comm.SetHost(m_aAccounts[nItem].sServer);
	csMailAccount =m_aAccounts[nItem].sServer;
    m_CThreadInfo.m_Pop3Comm.SetPort(m_aAccounts[nItem].nPort);
    m_CThreadInfo.m_Pop3Comm.SetUser(m_aAccounts[nItem].sUsername);
	userName = m_aAccounts[nItem].sUsername;
    m_CThreadInfo.m_Pop3Comm.SetPassword(m_aAccounts[nItem].sPassword);

	m_ProgressBar.SetPos (5);//set intermidiate position of progress bar
   
    if(!m_CThreadInfo.m_Pop3Comm.Connect())
    {	
	  m_ProgressBar.SetPos (10);//set intermidiate position of progress bar
	  AfxMessageBox(m_CThreadInfo.m_Pop3Comm.GetErrorMessage());
	  m_ProgressBar.SetPos (0);//reset progress bar
      return;
    }
//Restore the condition variable if communication was interrupted by the user
//(it is used later in this function when output message parameters):
	nSocketClosed=0;

///////////////////////////////////////////////////////////////
//Pass the pointer to the CThreadInfo class (structure/union) to the worker thread:
    AfxBeginThread(ThreadProc, &m_CThreadInfo);

//2.Transaction state://///////////////////////////////////////////////
	m_ProgressBar.SetPos (15);//set intermidiate position of progress bar
	
	//2.1 Get number of mails (STAT)    
	if(!m_CThreadInfo.m_Pop3Comm.Statistics())
    {
     m_ProgressBar.SetPos (20);//set intermidiate position of progress bar
	  AfxMessageBox(m_CThreadInfo.m_Pop3Comm.GetErrorMessage());
	  m_ProgressBar.SetPos (0);//reset progress bar
      return;
    }

	m_ProgressBar.SetPos (25);//set intermidiate position of progress bar
	m_Mails.DeleteAllItems();//clear the Mails list
    nMailNum = m_CThreadInfo.m_Pop3Comm.GetNumberOfMails();//get the number of mails

	int nMsgSize;//variable to calculate the size of single message

	// Open file to write the received messages
	// (output and append data).
	// Put it here to make visible outside the "for" loop:
	
	//Get the name of server selected and create an output file:
	csFileName =csMailAccount + (".dat");
	ofstream outfile(csFileName,ios::out, ios::app);
	
	//Get the mails:
	for(nItem = 0; nItem <nMailNum; nItem++)
    {
      //2.2.Get information regarding the size of a single message
	  //or all the messages in a mail drop (LIST):
	  m_CThreadInfo.m_Pop3Comm.List();

	  if ((nMailNum % 2) == 0)//if even number of messages 
	  {
		nMsgSize=m_CThreadInfo.m_Pop3Comm.GetMessageSize(nItem);
	  }
	  else//if odd number of messages 
		nMsgSize=m_CThreadInfo.m_Pop3Comm.GetMessageSize(nItem+1);

	  //2.3 Display a given message's header (TOP).
	  //List box is 0-based, but message's numbering is 1-based,
	  //thus, add 1 to the list view first line:
	  m_CThreadInfo.m_Pop3Comm.GetTop(nItem+1,nMsgSize); 
	  
	  //Output the server's name:
	  m_Mails.InsertItem(nItem, csMailAccount);
	  //Output mail fields (Attachment, From, Subject, Date):
	  if (m_CThreadInfo.m_Pop3Comm.t_Attachment == "text/plain;")
	  {
		m_CThreadInfo.m_Pop3Comm.t_Attachment = "";
	  }
	  
	  if (nSocketClosed ==0)
	  {
		  m_Mails.SetItemText(nItem, 1, m_CThreadInfo.m_Pop3Comm.t_Attachment);
		  m_Mails.SetItemText(nItem, 2, m_CThreadInfo.m_Pop3Comm.t_From);
		  m_Mails.SetItemText(nItem, 3, m_CThreadInfo.m_Pop3Comm.t_Subject);
		  m_Mails.SetItemText(nItem, 4, m_CThreadInfo.m_Pop3Comm.t_Date);
	  }
	  else//if communication is interrupted by the user
	  {
		  m_Mails.DeleteAllItems();//clear the Mails list box
	  }
	  
	  //2.4 Retrieve a message from the host(RETR):	  
	  m_CThreadInfo.m_Pop3Comm.Retrieve(nItem+1);
	 
	  //Save messages in disk file:
	  m_sMessage = m_CThreadInfo.m_Pop3Comm.GetMsgContents();
	  
	  // the C++ way to write in file (attribute ::app to append data):	 
	  //ofstream outfile("Messages.dat",ios::out, ios::app);//open file for output
		outfile<<"Message "<<nItem<<"\n";
		outfile<<m_sMessage<<"\n"<<"\n";
		outfile<<"End of message "<<nItem<<"\n";
		//outfile.close();
/////////////////////////////////////////////////////////
	  
	  m_ProgressBar.SetPos (30+nItem*10);//set position of progress bar
  
	  if (nDeleteFromServer==0)
	  //Delete the message from server's mailbox:
	  m_CThreadInfo.m_Pop3Comm.Delete(nItem+1);	 
    }
	m_ProgressBar.SetPos (100);//set final position of progress bar

	
	//Close the output file (put it out of the writing "for" loop 
	// to open empty file for every new connection to the mail server):
	outfile.close();
  
	//Disconnect from the server:
	m_CThreadInfo.m_Pop3Comm.Disconnect();
	m_ProgressBar.SetPos (0);//reset progress bar

//If mail is received successfully, post message to the worker thread to close 
//the socket controlling message box (for explanation on the following code 
//see "Remarks" section in MSDN article on PostThreadMessage API):
	 PostThreadMessage(nThreadID, WM_QUIT, 0, 0);
	 //to create a message queue needed to handle PostThreadMessage:
	 Sleep(0);
	 PostThreadMessage(nThreadID, WM_QUIT, 0, 0);

  }//end of "while" loop
 
}
/////////////////////////////////////////////////////////////////////////////
//Function to read the headers of received messages:
void CMailPop3::OnReadHeaders() 
{
    nItem=0;//set initial value

	CString csFileName;//name of the file on disk
    CString fileString;//string to search for pattern
    //variables to store contents of email fields:
    CString t_Attachment,t_To,t_From,t_Subject,t_Date;

    //Get the name of server selected to compose the name of output file:
    csFileName =csMailAccount + (".dat");
	
	char stringChar;//character to be added from the file
	FILE* pSearchFile;//pointer to the file object

	m_Mails.DeleteAllItems();//clear the Mails list control
	
	// Open email's file to search for patterns:
	if ((pSearchFile = fopen(csFileName,"r"))==NULL)
		{
		MessageBox("Error: can not open file "+(csFileName)+\
			(".\nCheck if this file is present in program's directory."),\
						NULL, MB_ICONWARNING  | MB_OK );
		return;
		}

	else
		{	
		while ((stringChar=getc(pSearchFile) )!= EOF)  
			{
			fileString += (CString) stringChar;//add in characters from the file
		
			if((stringChar != 10) && (stringChar !=13) )//if not NewLine and CarriageReturn
				{
				//compose the string...
				}
			else //get the string and search for a pattern
				{ 
				fileString.TrimLeft();//remove leading whitespace characters
				fileString.TrimRight();//remove trailing whitespace characters
				if (fileString.Find('\r')!=-1) // remove CarriageReturn character
					fileString=fileString.Left(fileString.GetLength()-1);
				if (fileString.Find('\n')!=-1) // remove NewLine character
					fileString=fileString.Left(fileString.GetLength()-1);
					fileString.TrimLeft(); //remove leading whitespace characters
					fileString.TrimRight();//remove trailing whitespace characters
			
				if (fileString.Find("From:")==0)  
					{
					t_From=fileString.Right(fileString.GetLength()-sizeof("From:"));		
					//Output the server's name:
					m_Mails.InsertItem(nItem, csMailAccount);
					//Output the field "From" (it is a second field but first found in text):
					m_Mails.SetItemText(nItem, 2, t_From);				
					}	
				if (fileString.Find("Subject:")==0)  
					{			
					t_Subject=fileString.Right(fileString.GetLength()-sizeof("Subject:"));
					m_Mails.SetItemText(nItem, 3, t_Subject);				
					}			
			    if (fileString.Find("Date:")==0)  
					{		
					t_Date=fileString.Right(fileString.GetLength()-sizeof("Date:"));
					m_Mails.SetItemText(nItem, 4, t_Date);			
					}
			    if (fileString.Find("Content-Type:")==0)  
					{
					t_Attachment=fileString.Right(fileString.GetLength()-sizeof("Content-Type:"));
					
					if (t_Attachment == "text/plain;")
						{
						t_Attachment = "";
						}
					m_Mails.SetItemText(nItem, 1, t_Attachment);
					nItem++;//increment to put items in the right order on the list
					}
	// Note: by now, it is only coded to define the attachment of Content-type "application"
	// (i.e. attached files with .zip, .exe or other extentions).	
				//If there is an attachment, get the name of file:
				if (fileString.Find("filename=")==0)  
					{
					csInQuotes =fileString.Right(fileString.GetLength()-sizeof("filename=")+1);
					CString csTemporary =fileString.Right(fileString.GetLength()-sizeof("filename="));
					csAttachmentFile= csTemporary.Left(csTemporary.GetLength()-1);
					//csExtension = csAttachmentFile.Right(3);
					}
				//Get the attachment boundary pattern:
				if (fileString.Find("boundary=")==0)  
					{
					CString csTemporary =fileString.Right(fileString.GetLength()-sizeof("boundary="));
					csBoundary= csTemporary.Left(csTemporary.GetLength()-1);	
					}

				fileString ="";//clear the contents to insert new string from file				
				}	
			}
		}
	 fclose(pSearchFile);
	 nItem=0;
}
//////////////////////////////////////////////////////////////////////////////////
//Function to read the selected message:
void CMailPop3::OnReadMail() 
{
	CString fileString;//string to read from file
 
	//Use name of selected account to get the name of email's file:
	csFileName =csMailAccount + (".dat");

	//File object opened to read:
	CStdioFile ioFileObject(csFileName,CFile::modeRead);
	
	int nMsgLength, nMsgStart,nMsgEnd;
	CString csMessageString;//string to store the selected message
	
    //String used to create pattern "Message+number" to search in text
	//(to get the start of selected message):
	CString csStrStart= "Message ";
    //String used to create pattern "End of message+number" to search in text
	//to get the end of selected message):
	CString csStrEnd = "End of message ";
	
	char szStrNumber[8];//to store the line number 

	CString csTemporary; 

	int nItem = -1;

	while((nItem = m_Mails.GetNextItem(nItem, LVNI_SELECTED)) != -1)
	{
		//Add nItem number to the string:
		sprintf(szStrNumber, "%d",nItem);
		//Compose the pattern with line number:
		csStrStart = csStrStart+szStrNumber;
		csStrEnd = csStrEnd+szStrNumber;

	//Read the file until the searching pattern "End of message+nItem" is found:
		while (fileString.Find(csStrEnd)!=0)
		{			
			if (!ioFileObject.ReadString(fileString))
			{			
				MessageBox("Error: can not read the file "+(csFileName),\
							NULL, MB_ICONWARNING  | MB_OK );						
				return;
			}		
			//Compose the string from the separate strings read from file:
			csMessageString= csMessageString + fileString + "\n";
		
			//Get the start and end points of the message: 
			nMsgStart = csMessageString.Find(csStrStart);
			nMsgEnd = csMessageString.Find(csStrEnd);	
			//Calculate the size of message (-1 to remove the leading \n character):
			nMsgLength = nMsgEnd-nMsgStart+sizeof(csStrEnd)+sizeof(csStrStart)-1;	
		}
	//Get only the selected message from the read data:	
		csTemporary = csMessageString.Right(nMsgLength);
		
		//Remove "End of message " and \n\r characters to be shown int Edit Box Edit box "m_Message":
		m_sMessage= csTemporary.Left(csTemporary.GetLength()-(csStrEnd.GetLength()+3));
		//Display the message in Edit box "m_Message":
		m_Message.SetWindowText(m_sMessage);
		
		//Remove "End of message " and \n character in the end of string
		//(to be used later to extract attachment if found):
		m_sMessage= csTemporary.Left(csTemporary.GetLength()-(csStrEnd.GetLength()+2));
	}
	ioFileObject.Close();
}


//////////////////////////////////////////////////////////////////////////////////
//Function to leave a copy of the message on server after receiving mail:
void CMailPop3::OnDontDelete() 
{
 	MessageBox("Copy of the message will be left on Server.",\
						NULL, MB_ICONINFORMATION | MB_OK );	

	// Get the top level menu from the main application window.
    CWnd*  pMainWindow = AfxGetMainWnd();
	CMenu* pMenu = pMainWindow->GetMenu();

	//Places a check mark next to a menu item:
	pMenu->CheckMenuItem(ID_DONT_DELETE,  MF_CHECKED);
	//Removes a check mark from a menu item:
	pMenu->CheckMenuItem(ID_DELETE_MESSAGES, MF_UNCHECKED);
	
	//Copy of the message will be left on server:
	nDeleteFromServer=1;
}

//////////////////////////////////////////////////////////////////////////////////
//Function to delete messages from server after receiving mail:
void CMailPop3::OnDeleteFromServer()
{
 	MessageBox("Messages will be deleted from Server.",\
						NULL, MB_ICONINFORMATION | MB_OK );	

	// Get the top level menu from the main application window.
    CWnd*  pMainWindow = AfxGetMainWnd();
	CMenu* pMenu = pMainWindow->GetMenu();
 
	//Places a check mark next to a menu item:
	pMenu->CheckMenuItem(ID_DELETE_MESSAGES, MF_CHECKED);
	//Removes a check mark from a menu item:
	pMenu->CheckMenuItem(ID_DONT_DELETE,  MF_UNCHECKED);
	//Messages will be deleted from server:
	nDeleteFromServer=0;
}

/////////////////////////////////////////////////////////////////////////////
//Function to implement the worker thread used to close the connection:
UINT ThreadProc(LPVOID pParam)
{
// This is the standard method to pass the pointer to the object in the worker thread.	
// Note that we can not share the same socket between different threads,
// but here we use the second thread only to be able to close the connection 
// if the communication got stuck. The recommended method with attach/detach
// socket is not applicable in this case because after "detach" made to pass 
// the socket's handle to the other thread it can not be used in the main thread anymore.

	CThreadInfo* pSocket = (CThreadInfo*)pParam;

//Get the thread id used to send PostThreadMessage from CMailPop3::OnReceive() function:
	nThreadID = GetCurrentThreadId(); 

	// Check if we have handle to the socket notification window:
	//_AFX_SOCK_THREAD_STATE* pState = _afxSockThreadState;
    //ASSERT(pState->m_hSocketWindow != NULL);

	  if(MessageBox(NULL,"You can stop the transfer if it got stuck or takes too long:\
	   \n\"Retry\" is to close the connection to retry mail receive, \n\"Cancel\" is to close this dialog.",\
	   "Email Message", \
	   MB_ICONINFORMATION|MB_RETRYCANCEL|MB_TASKMODAL) == IDRETRY) 
		{ 
		//If "yes"-
		//shut down the socket (receive and send operations):
			nSocketClosed=1;
		    pSocket->m_Pop3Comm.m_Socket.ShutDown(2);
			//pSocket->m_Pop3Comm.m_Socket.CancelBlockingCall();
			//pSocket->m_Pop3Comm.m_Socket.Close();
			return 1;
		} 

	else //If "no", return from the function.
		{ 
			return 0;
		}

  return 0;
}
/////////////////////////////////////////////////////////////////////////////
//Base64 decode related functions.
//
/////////////////////////////////////////////////////////////////////////////
//Decode 4 '6-bit' characters into 3 8-bit binary bytes
void CMailPop3::Decodeblock(unsigned char szIn[4], unsigned char szOut[3])
{   
//Using left/right shift and bitwise OR
//- compose the first byte from first and part of second 6 bit blocks:
	szOut[0] = (unsigned char) (szIn[0] << 2 | szIn[1] >> 4);
//- compose the second byte from part of second and part of third 6 bit blocks:
    szOut[1] = (unsigned char) (szIn[1] << 4 | szIn[2] >> 2);
//- compose the third byte from part of third and fourth 6 bit blocks:    
	szOut[2] = (unsigned char) (((szIn[2] << 6) & 0xc0) | szIn[3]);

//  Example (you can use hex editor to get values of not readable characters):
//	- decode the first character (part of the "magic number" PK) in every.zip file.
//    szIn[0] = 0x14 (20 decimal)=> 00010100
//    szIn[1] = 0x04 (4 decimal) => 00000100
//  Shift is used to extract 6 bit block (or its part) from the byte it is stored in. 
//	  szIn[0] after left shift on 2 positions  = 01010000
//	  szIn[1] after right shift on 4 positions = 00000000
//	  After bitwise OR the resulting szOut[0]  = 01010000
//	  
//	  The binary 01010000 is 0x50, or 80 decimal, or 'P'
}
//////////////////////////////////////////////////////////////////////////
// Decode a base64 encoded stream discarding padding, line breaks and noise
void CMailPop3::Decode(FILE *inputFile, FILE *outputFile)
{
    unsigned char szIn[4],szOut[3],chCurrent;
    int i, nLength;

    while(!feof(inputFile)) 
	{
        
		//In this "for" cycle we'll assign every file character 
		//the coresponding character from decoding table:
		for(nLength=0, i=0; i<4 && !feof(inputFile); i++) 
		{
            chCurrent = 0;
            while(!feof(inputFile) && chCurrent==0) 
			{
                //read a character from file:
				chCurrent = (unsigned char)getc(inputFile);
				//assign corresponding character from the decoding table (or 0):
                chCurrent = (unsigned char)((chCurrent<43||chCurrent>122)?0:cd64[chCurrent-43]);
                
				if(chCurrent) 
				{
                    //assign corresponding to '$' (or 0):
					chCurrent=(unsigned char)((chCurrent == '$')?0:chCurrent - 61);
                }
            }
            if( !feof(inputFile)) 
			{
                nLength++;
                if(chCurrent) 
				{
                    //fill in the input szIn[4] 4 bytes array:
					szIn[i] = (unsigned char)(chCurrent - 1);
                }
            }
            else 
			{
                szIn[i] = 0;
            }

        }//end of "for" cycle
		//Now, we have filled szIn[4] array to decode.
		
		if(nLength) 
		{
            //Decode the input szIn[4] array into output szOut[3] 3 bytes array:
			Decodeblock(szIn, szOut);
            for(i=0; i<nLength-1; i++) 
			{
                //write decoded array in output file:
				putc(szOut[i],outputFile);
            }
        }
    }//end of "while" loop
 
 //Close the input/output files:
 fclose(inputFile);
 fclose(outputFile);
 
}

