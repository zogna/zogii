#if !defined(AFX_PAGEMAILACCOUNT_H__792E75A7_5468_11D2_8102_9EC3A8472A4A__INCLUDED_)
#define AFX_PAGEMAILACCOUNT_H__792E75A7_5468_11D2_8102_9EC3A8472A4A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PageMailAccount.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPageMailAccount dialog

class CPageMailAccount : public CDialog
{
// Construction
public:
	CPageMailAccount(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPageMailAccount)
	enum { IDD = IDD_PAGE_MAIL_ACCOUNT };
	CString	m_sPassword;
	CString	m_sServer;
	CString	m_sUsername;
	int		m_nPort;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPageMailAccount)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPageMailAccount)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGEMAILACCOUNT_H__792E75A7_5468_11D2_8102_9EC3A8472A4A__INCLUDED_)
