//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Email.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_EMAILTYPE                   129
#define IDD_SMTP                        130
#define IDI_MAILBOX                     134
#define IDD_MAIL_CONFIG                 135
#define IDD_MAIL_POP3                   136
#define IDD_MAIL_ACCOUNT                137
#define IDI_SENDMAIL                    138
#define IDI_CLIP                        139
#define IDI_CHECKMARK                   140
#define IDB_BITMAP1                     141
#define IDB_BITMAP2                     143
#define IDC_TEXT                        1000
#define IDC_FROM                        1001
#define IDC_TO                          1002
#define IDC_SUBJECT                     1003
#define IDC_CLEAR                       1005
#define IDB_DELCURRENT                  1006
#define IDB_SETTINGS                    1007
#define IDC_ATTACHMENTS                 1008
#define IDB_ATTACHMENTS                 1009
#define IDB_SEND                        1010
#define IDC_WITHSIGNATURE               1011
#define IDC_WITHDATE                    1012
#define IDC_WITHMAILER                  1013
#define IDC_NUMBER_OF_CHARS             1014
#define IDC_TEXT_SIGNATURE              1015
#define IDC_SERVER                      1016
#define IDC_XMAILER                     1017
#define IDC_TABCTRL_OUTPUT              1018
#define IDB_CANCEL                      1019
#define IDC_ADD                         1020
#define IDC_EDIT                        1021
#define IDC_REMOVE                      1022
#define IDC_RECEIVE                     1023
#define IDC_SERVERS                     1024
#define IDC_MAILS                       1025
#define IDC_VIEW                        1026
#define IDC_REPLY                       1027
#define IDC_DELETE                      1028
#define IDC_POP3_SAVE                   1029
#define IDC_POP3_SERVER                 1030
#define IDC_PORT                        1031
#define IDC_POP3_USERNAME               1032
#define IDC_POP3_PASSWORD               1033
#define IDC_PROGRESS_RECEIVE            1034
#define IDC_PROGRESS_SEND               1037
#define IDC_MESSAGE                     1038
#define IDC_MAILER                      1039
#define IDC_QUIT                        1040
#define IDC_ACCOUNTS                    1041
#define IDC_INBOX                       1042
#define IDC_DISCONNECT                  1043
#define ID_RECEIVE_MAIL                 32772
//#define ID_READ_MAIL                    32774
#define ID_DONT_DELETE                  32776
#define ID_DELETE_MESSAGES              32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
