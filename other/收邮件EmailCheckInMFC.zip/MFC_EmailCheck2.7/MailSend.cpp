// MailSend.cpp : implementation file
//

#include "stdafx.h"

#include "SMTP.h"
#include "Email.h"

#define UNICODE 

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CComboEx class 
//
// Constructor:
CComboEx::CComboEx()
{
	m_bAutoComplete = TRUE;
}
// Destructor:
CComboEx::~CComboEx()
{
}

//Message Map.
//  MFC provides an alternative to the switch statement used in traditional 
//  Windows programs to handle messages sent to a window. A mapping from messages 
//  to member-functions may be defined so that when a message is to be handled 
//  by a window, the appropriate member function is called automatically. 
//  This message-map facility is designed to be similar to virtual functions 
//  but has additional benefits not possible with C++ virtual functions.

BEGIN_MESSAGE_MAP(CComboEx, CComboBox)
	//{{AFX_MSG_MAP(CComboEx)
	ON_CONTROL_REFLECT(CBN_EDITUPDATE, OnEditUpdate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

////////////////////////////////////////////
// AutoComplete function
//   When you type text in an edit box, and the first few characters of the text 
//   you type match an existing entry in combo box, the AutoComplete feature 
//   will automatically fill the remaining characters. 
void CComboEx::OnEditUpdate() 
{
  DWORD dwCurSel = GetEditSel();
  int nStart = dwCurSel >> 16;
  int nEnd = dwCurSel & 0xffff;

  //Return if we are not going to auto update the text:
	if (!m_bAutoComplete) return;

	// Get the text in the edit box:
	CString str;
	GetWindowText(str);
	int nLength = str.GetLength();

	// Search for the string in the combo box that is prefixed
	// by the text in the edit box
	if (SelectString(-1, str) == CB_ERR) 
		SetWindowText(str);		// No text selected, so restore what was there before

	// Set the text selection as the additional text that we have added
  if(nEnd < nLength)
    SetEditSel(nStart, nEnd);//completes the text
  else
    SetEditSel(nLength, -1); //no completion
}
////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// CMailConfig dialog

CMailConfig::CMailConfig(CWnd* pParent /*=NULL*/)
	: CDialog(CMailConfig::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMailConfig)
	m_sSignature = _T("");
	m_sServer = _T("");
	m_sXMailer = _T("Email Client 2.0");
	//}}AFX_DATA_INIT
}


void CMailConfig::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMailConfig)
	DDX_Control(pDX, IDC_TEXT_SIGNATURE, m_Signature);
	DDX_Text(pDX, IDC_TEXT_SIGNATURE, m_sSignature);
	DDX_Text(pDX, IDC_SERVER, m_sServer);
	DDX_Text(pDX, IDC_MAILER, m_sXMailer);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMailConfig, CDialog)
	//{{AFX_MSG_MAP(CMailConfig)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMailConfig member functions

void CMailConfig::OnOK() 
{

	UpdateData();

	CDialog::OnOK();
}

/////////////////////////////////////////////////////////////////////////////
// ::OnInitDialog function.
//		This function specifies whether the application has set the input focus 
//		to one of the controls in the dialog box. 
//		This member function is called in response to the WM_INITDIALOG message. 
//		This message is sent to the dialog box during the Create, CreateIndirect, 
//		or DoModal calls, which occur immediately before the dialog box is displayed. 

BOOL CMailConfig::OnInitDialog() 
{
  
  CDialog::OnInitDialog();
	
  CWnd* pWnd = GetWindow(GW_CHILD);
  while(pWnd)
  {
    int nID = pWnd->GetDlgCtrlID();
    if (nID != -1)
    pWnd = pWnd->GetWindow(GW_HWNDNEXT);
  }
	
	return TRUE;  // Returns TRUE unless you set the focus to a control
	              // (the exception is OCX Property Pages that should return FALSE).
}


/////////////////////////////////////////////////////////////////////////////
// CSmtpDlg dialog member functions:

// Use the IMPLEMENT_DYNCREATE macro with the DECLARE_DYNCREATE macro 
// to enable objects of CObject-derived classes to be created dynamically 
// at run time. The framework uses this ability to create new objects dynamically, 
// for example, when it reads an object from disk during serialization.
IMPLEMENT_DYNCREATE(CSmtpDlg, CDialog)

//Constructor:
CSmtpDlg::CSmtpDlg() : CDialog(CSmtpDlg::IDD)
{
	
	//{{AFX_DATA_INIT(CSmtpDlg)
	m_sFrom = _T("");
	m_sSubject = _T("");
	m_sText = _T("");
	m_sTo = _T("");
	m_bClear = FALSE;
	m_bWithDate = FALSE;
	//m_bWithMailer = FALSE;
	m_bWithSignature = FALSE;
	//}}AFX_DATA_INIT
}
//Destructor:
CSmtpDlg::~CSmtpDlg()
{
}

//DoDataExchange is called by the framework to exchange and validate dialog data:
void CSmtpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSmtpDlg)
	DDX_Control(pDX, IDC_ATTACHMENTS, m_Attachments);
	DDX_Control(pDX, IDC_TEXT, m_Text);
	DDX_CBString(pDX, IDC_FROM, m_sFrom);
	DDV_MaxChars(pDX, m_sFrom, 256);
	DDX_CBString(pDX, IDC_SUBJECT, m_sSubject);
	DDV_MaxChars(pDX, m_sSubject, 256);
	DDX_Text(pDX, IDC_TEXT, m_sText);
	DDV_MaxChars(pDX, m_sText, 64000);
	DDX_CBString(pDX, IDC_TO, m_sTo);
	DDV_MaxChars(pDX, m_sTo, 256);
	DDX_Check(pDX, IDC_CLEAR, m_bClear);
	DDX_Check(pDX, IDC_WITHDATE, m_bWithDate);
	DDX_Check(pDX, IDC_WITHSIGNATURE, m_bWithSignature);
	DDX_Control(pDX, IDC_PROGRESS_SEND, m_ProgressBar);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSmtpDlg, CDialog)
	//{{AFX_MSG_MAP(CSmtpDlg)
	ON_BN_CLICKED(IDB_SEND, OnSend)
	ON_BN_CLICKED(IDB_SETTINGS, OnSettings)
	ON_BN_CLICKED(IDB_CANCEL, OnCancel)
	ON_EN_CHANGE(IDC_TEXT, OnChangeText)
	ON_BN_CLICKED(IDC_WITHSIGNATURE, OnWithSignature)
	ON_BN_CLICKED(IDC_WITHSIGNATURE, OnWithDate)
	ON_BN_CLICKED(IDB_ATTACHMENTS, OnAttachments)
	ON_CBN_SETFOCUS(IDC_ATTACHMENTS, OnSetfocusAttachments)
	ON_CBN_EDITUPDATE(IDC_ATTACHMENTS, OnEditupdateAttachments)
	ON_CBN_SELCHANGE(IDC_ATTACHMENTS, OnSelchangeAttachments)	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSmtpDlg message handlers

// ::OnInitDialog
//     This function specifies whether the application has set the input focus 
//     to one of the controls in the dialog box. 
BOOL CSmtpDlg::OnInitDialog() 
{
  //Set the user defined icon for a dialog:
  SetIcon(AfxGetApp()->LoadIcon(IDI_SENDMAIL), FALSE);
  SetIcon(AfxGetApp()->LoadIcon(IDI_SENDMAIL), TRUE);
  
  CDialog::OnInitDialog();
  
  m_Subject.SubclassDlgItem(IDC_SUBJECT, this);
  m_From.SubclassDlgItem(IDC_FROM, this);
  m_To.SubclassDlgItem(IDC_TO, this);
  	
///////Read stored initial data: 
    char   IniFile[MAX_PATH]; 
    CHAR inBuf[1024]; 
   
	//get the path to current directory:
	GetCurrentDirectory(MAX_PATH, IniFile);
	//add to path the name of .ini file:
	lstrcat( IniFile, "\\Settings.ini" ); 

	CMailConfig MailConfig;
	GetPrivateProfileString ("OutgoingMail", "SMTP", 
                           "", inBuf, 180, 
                            IniFile); 
	MailConfig.m_sServer = inBuf;
	GetPrivateProfileString ("XMailer", "Name", 
                           "", inBuf, 180, 
                            IniFile);
	MailConfig.m_sXMailer =inBuf;
	GetPrivateProfileString ("Signature", "Name", 
                           "", inBuf, 180, 
                            IniFile); 
	MailConfig.m_sSignature = inBuf;

	m_sServer = MailConfig.m_sServer;
	m_sXMailer = MailConfig.m_sXMailer;
	m_sSignature = MailConfig.m_sSignature;

///////////////////////////////////////////////////
    OnChangeText();

	return TRUE; // Returns TRUE unless you set the focus to a control
	             // (the exception is OCX Property Pages that should return FALSE).
}

/////////////////////////////////////////////////////////////////////////////
//CSmtpDlg::OnSend function.
//   SMTP dialog function to handle message's info and text to be sent: 

void CSmtpDlg::OnSend() 
{
//Member function to initialize data in a dialog box, 
//or to retrieve and validate dialog data.
	UpdateData();

//Show progress bar while connecting to the server:

	int m_Min = 0;
	int m_Max = 100;
	m_ProgressBar.SetRange (m_Min, m_Max);
	m_ProgressBar.SetStep (1);

	//Set initial position of progress bar:
	m_ProgressBar.SetPos (0);
///////////////////////////////////////////////////////////     
  //1.Handle input in form - name<address>:
  CString sFromName;//sender's name
  CString sFromEmail;//sender's e-mail address
  CString sToName;//recipient's name
  CString sToEmail;//recipient's e-mail address
  int nFrom = m_sFrom.Find(_T('<'));//find character "<" starting at left, -1 if not found

  if(nFrom != -1)
  {
    sFromName = m_sFrom.Left(nFrom);
    sFromEmail = m_sFrom.Right(m_sFrom.GetLength() - nFrom);
	
	//return nCount (second) characters starting at zero-based nFirst (first):
    sFromEmail = sFromEmail.Mid(1, sFromEmail.GetLength() - 2);	

	//Compose the complete address:
	sFromEmail = sFromName+ "@"+ sFromEmail;	
  }
  else
  {
    sFromEmail = m_sFrom;//2. Else, copy entered address from ComboBox
  }
  
  int nTo = m_sTo.Find(_T('<'));
  if(nTo != -1)
  {
    sToName = m_sTo.Left(nTo);
    sToEmail = m_sTo.Right(m_sTo.GetLength() - nTo);
    sToEmail = sToEmail.Mid(1, sToEmail.GetLength() - 2);
	
	//Compose the complete address:
	sToEmail = sToName+ "@"+ sToEmail;
  }
  else
  {
    sToEmail = m_sTo;
  }
 
  if ((sToEmail== "") || (sFromEmail== ""))
  {
	//Error message:
	MessageBox("Error: empty recipient's (To:) or sender's (From:) field.",\
				NULL, MB_ICONWARNING | MB_OK );	
	return;
  }  
/////Use CTime::GetCurrentTime to get the date and time:
	CTime timeDate = CTime::GetCurrentTime();
	//For example: "02, February 2009" 
	CString csDate = timeDate.Format( "%d, %B %Y" );

////////////////////////
  m_ProgressBar.SetPos (5);//set intermidiate position of progress bar

  CSMTPConnection Smtp;
  if(!Smtp.Connect(m_sServer))
  {
    DWORD dwError = ::GetLastError();
    CString sResponse = Smtp.GetLastCommandResponse();
	m_ProgressBar.SetPos (10);//set intermidiate position of progress bar
	//Error message:
	MessageBox("Error: failed to connect to SMTP server.\
		\nCheck the connection and name of SMTP server.",\
		NULL, MB_ICONWARNING | MB_OK );
	m_ProgressBar.SetPos (0);//reset progress bar
    return;
  }
  m_ProgressBar.SetPos (20);//set intermidiate position of progress bar

  CSMTPMessage Message(m_sXMailer, m_bWithDate, m_bWithMailer);
  CSMTPAddress From(sFromName, sFromEmail);
  Message.m_From = From;
  CSMTPAddress To(sToName, sToEmail);
  Message.AddRecipient(To);
  Message.m_sSubject = m_sSubject;

 //Add signature and/or date to the messsage text:   
  if ((m_bWithSignature == TRUE)&&(m_bWithDate == TRUE))
  {
	//message with signature and date:
	 Message.AddBody(m_sText + '\n' + m_sSignature + '\n'+ csDate);
  }
  else if ((m_bWithSignature == TRUE)&&(m_bWithDate == FALSE))
  {
	//message with signature: 
	  Message.AddBody(m_sText + '\n' + m_sSignature);
  }
  else if ((m_bWithSignature == FALSE)&&(m_bWithDate == TRUE))
  {
	//message with date:
	  Message.AddBody(m_sText + '\n' + csDate);
  }
  else if ((m_bWithSignature == FALSE)&&(m_bWithDate == FALSE))
  {
	//message without signature and date:
	  Message.AddBody(m_sText);
  }
 
  Message.m_ReplyTo = CSMTPAddress(_T(""), _T("aa@aaa.com"));

  CArray<CSMTPAttachment*, CSMTPAttachment*&> apAttachments;

  CString sAttachment;
  CSMTPAttachment* pAttachment;
  int nAttachments = m_Attachments.GetCount();
  if(nAttachments != CB_ERR && nAttachments != 0)
  {
    for(int i = 0; i < nAttachments; i++)
    {
      pAttachment = new CSMTPAttachment;
      apAttachments.Add(pAttachment);

      m_Attachments.GetLBText(i, sAttachment);
      pAttachment->Attach(sAttachment);
      Message.AddAttachment(pAttachment);
	}
  }

  m_ProgressBar.SetPos (30);//set intermidiate position of progress bar
  if(!Smtp.SendMessage(Message))
  {
    DWORD dwError = ::GetLastError();
    CString sResponse = Smtp.GetLastCommandResponse();
	m_ProgressBar.SetPos (40);//set intermidiate position of progress bar
	//Error message:
	MessageBox("Error: failed to send the e-mail message.\
		\nCheck the recipient's and sender's addresses.",\
		NULL, MB_ICONWARNING | MB_OK );
	m_ProgressBar.SetPos (0);//reset progress bar
    return;
  }
  else
  {
   m_ProgressBar.SetPos (100);//set intermidiate position of progress bar
	//Confirmation that e-mail was sent to the recipient:
	MessageBox("Confirmation: message is sent to the recipient.",\
		NULL, MB_ICONINFORMATION | MB_OK );

    if(m_bClear)
    {
      m_Text.SetSel(0, -1);
      m_Text.Clear();
      m_To.SetEditSel(0, -1);
      m_To.Clear();
      m_Subject.SetEditSel(0, -1);
      m_Subject.Clear();
      m_Attachments.ResetContent();
    }
  }
 
  Smtp.Disconnect();
  m_ProgressBar.SetPos (0);//reset progress bar

  nAttachments = apAttachments.GetSize();
  for(int i = 0; i < nAttachments; i++)
    delete apAttachments.GetAt(i);
  apAttachments.RemoveAll();
}

/////////////////////////////////////////////////////////////////////////////
//CSmtpDlg::OnAttachments function.
//   Function to select file for attachment.

void CSmtpDlg::OnAttachments() 
{
  CFileDialog BrowseDialog(TRUE);
  if(BrowseDialog.DoModal() == IDOK)
  {
    CString sPath = BrowseDialog.GetPathName();
    if(!sPath.IsEmpty())
    {
      m_Attachments.EnableWindow(TRUE);
      m_Attachments.SetWindowText(sPath);
      m_Attachments.AddString(sPath);
    }
  }
}

/////////////////////////////////////////////////////////////////////////////
//CSmtpDlg::OnSettings function.
//   Function to handle settings of SMTP server ("Mail settings" dialog).

void CSmtpDlg::OnSettings()
{
//Read stored initial data: 
    char   IniFile[MAX_PATH]; 
    CHAR inBuf1[256];
    CHAR inBuf2[1024]; 
	//get the path to current directory:
	GetCurrentDirectory(MAX_PATH, IniFile);
	//add to path the name of .ini file:
	lstrcat( IniFile, "\\Settings.ini" ); 
  
	GetPrivateProfileString ("OutgoingMail", "SMTP", 
                           "", inBuf1, 180, 
                            IniFile);
	m_sServer = inBuf1;
	GetPrivateProfileString ("XMailer", "Name", 
                           "", inBuf1, 180, 
                            IniFile); 
	m_sXMailer = inBuf1;
	GetPrivateProfileString ("Signature", "Name", 
                           "", inBuf2, 180, 
                            IniFile); 
	
    m_sSignature = inBuf2;
///////////////////////////////////////////////////	
  CMailConfig MailConfig;
  MailConfig.m_sSignature = m_sSignature;
  MailConfig.m_sServer = m_sServer;
  MailConfig.m_sXMailer = m_sXMailer;
  if(MailConfig.DoModal() == IDOK)
  {
    m_sSignature = MailConfig.m_sSignature;
    m_sServer = MailConfig.m_sServer;
    m_sXMailer = MailConfig.m_sXMailer;
 
	//Save entered server's name and signature in .ini file:
	SaveSettings(m_sServer, m_sSignature); 
    OnChangeText();
  }
}
/////////////////////////////////////////////////////////////////////////////

void CSmtpDlg::OnChangeText() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here

//Member function to initialize data in a dialog box, 
//or to retrieve and validate dialog data.
// From MSDN "DoDataExchange is called by the UpdateData member function. 
// Just before the dialog box is first displayed on the screen, 
// the framework calls the UpdateData function with an argument of FALSE, 
// which sets the contents of the edit boxes to the values of the member variables."
	
  UpdateData();

  int nLength = m_sText.GetLength();

  if(m_bWithSignature)
    nLength += m_sSignature.GetLength();

  CString sLength;
  sLength.Format("%d", nLength);
  
}
/////////////////////////////////////////////////////////////////////////////
void CSmtpDlg::OnWithSignature() 
{
  OnChangeText();	
}
/////////////////////////////////////////////////////////////////////////////
void CSmtpDlg::OnWithDate() 
{
  OnChangeText();	
}

/////////////////////////////////////////////////////////////////////////////
void CSmtpDlg::OnSetfocusAttachments() 
{
  CString sText;
  m_Attachments.GetWindowText(sText);
  if(sText.IsEmpty() && m_Attachments.GetCount() == 0)
    m_Attachments.EnableWindow(FALSE);
}
/////////////////////////////////////////////////////////////////////////////
void CSmtpDlg::OnEditupdateAttachments() 
{
  OnSetfocusAttachments();	
}
/////////////////////////////////////////////////////////////////////////////
void CSmtpDlg::OnSelchangeAttachments() 
{
  OnSetfocusAttachments();	
}

/////////////////////////////////////////////////////////////////////////////
void CSmtpDlg::SaveSettings(CString sServer, CString sSignature) 
{
  
    char   IniFile[MAX_PATH]; 
  
    HANDLE  hFile; 
   
	//get the path to current directory:
	GetCurrentDirectory(MAX_PATH, IniFile);
	//add to path the name of .ini file:
	lstrcat( IniFile, "\\Settings.ini" ); 
	
    
     if( hFile = CreateFile( IniFile, 
                           GENERIC_WRITE, 
                           FILE_SHARE_READ, 
                           NULL, 
                           OPEN_ALWAYS, 
                           FILE_ATTRIBUTE_NORMAL, 
                           NULL)) 			
        CloseHandle(hFile); 
   
        WritePrivateProfileString("OutgoingMail", 
                                  "SMTP", 
                                   sServer, 
                                   IniFile);
		 WritePrivateProfileString("XMailer", 
                                  "Name", 
                                   m_sXMailer, 
                                   IniFile);

		WritePrivateProfileString("Signature", 
                                  "Name", 
                                   sSignature, 
                                   IniFile); 


}
/////////////////////////////////////////////////////////////////////////////
void CSmtpDlg::OnCancel() 
{
	//The framework calls this member function when the user 
	//clicks the Cancel button or presses the ESC key 
	//in a modal or modeless dialog box. 
	CDialog::OnCancel();	
}
/////////////////////////////////////////////////////////////////////////////