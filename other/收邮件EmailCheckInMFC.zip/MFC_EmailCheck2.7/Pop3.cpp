/*----------------------------------------------------------------------------------------------- 
// Pop3.cpp: Defines the class behaviors for the application. 
// This code is POP3 Protocol wrapper class written by Asif Rasheed and
// updated by Robert E. Peters (www.codeguru.com), 1998.
---------------------------------------------------------------------------------------------------*/ 

#include "stdafx.h" 

#include "Pop3.h"

#include <iostream.h>//common input/output operations in C++
#include <fstream.h>//input/output files in C++

#ifdef _DEBUG 
#define new DEBUG_NEW 
#undef THIS_FILE 
static char THIS_FILE[] = __FILE__; 
#endif 

#define TEMP_LIST "TempList.dat" // file used to temporary store the result of LIST command
#define TEMP_TOP  "TempTop.dat"	 // file used to temporary store the result of TOP command

//////////////////////////////////////////////////////////////////// 
// CPop3Comm Class implementation (communication using POP3 protocol)
////////////////////////////////////////////////////////////////////// 

////////////////////////////////////////////////////////////////////// 
// Construction/Destruction 
////////////////////////////////////////////////////////////////////// 
CPop3Comm::CPop3Comm() 
{ 
	if (!m_Socket.Create()) MessageBox(NULL,"Error: can not create the socket.","Warning",MB_OK);
} 

CPop3Comm::~CPop3Comm() 
{ 
 m_Socket.Close(); 
} 

BOOL CPop3Comm::Connect(CString & Host, int Port, CString & User, CString & Password) 
{ 
 char inBuf [512]; 

 if (!m_Socket.Connect(Host,Port)) // 110 is default POP3 port 
 { 
  m_ErrorMessage = _T("Error: could not connect to the server ")+(Host)+(".\nCheck the network connection."); 
  return FALSE; 
 } 
 else 
 { 
  if(CheckResponse(CONNECTION_CHECK)==FALSE) 
   return FALSE; 

  wsprintf (inBuf, "USER %s\r\n", (LPCSTR) User); 
  m_Socket.Send(inBuf, strlen (inBuf));//send USER command to server 
  if(CheckResponse(USER_CHECK)==FALSE) 
   return FALSE; 

  wsprintf (inBuf, "PASS %s\r\n", (LPCSTR) Password); 
  m_Socket.Send(inBuf, strlen (inBuf)); //send PASS command to server 
  if (CheckResponse(PASSWORD_CHECK)==FALSE) 
   return FALSE; 

  return TRUE; 
 } 

} 

BOOL CPop3Comm::Delete(int MsgNumber) 
{ 
 char inBuf [512]; 

 wsprintf (inBuf, "DELE %d\r\n",MsgNumber ); 
 m_Socket.Send(inBuf, strlen (inBuf)); //send DELE command to server 
 if (CheckResponse(DELETE_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

BOOL CPop3Comm::Disconnect() 
{ 
 char inBuf [512]; 

 wsprintf (inBuf, "QUIT \r\n"); 
 m_Socket.Send(inBuf, strlen (inBuf));//send QUIT command to server  
 if (CheckResponse(QUIT_CHECK)==FALSE) 
  return FALSE; 
 else 
 {
	m_Socket.Close(); 
	return TRUE; 
 }
} 

BOOL CPop3Comm::Noop() 
{ 
 char inBuf [512]; 

 wsprintf (inBuf, "NOOP  \r\n"); 
 m_Socket.Send(inBuf, strlen (inBuf)); //send NOOP command to server 
 if (CheckResponse(NOOP_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

// Return the message size for given message number: 
int CPop3Comm::GetMessageSize(int MsgNumber) 
{ 
 if(m_SizeOfMsg.GetSize() < MsgNumber) 
  return 0; 
 else 
  return m_SizeOfMsg[MsgNumber]; 
} 

BOOL CPop3Comm::Reset() 
{ 
 char inBuf [512]; 

 wsprintf (inBuf, "RSET \r\n"); 
 m_Socket.Send(inBuf, strlen (inBuf));//send RSET command to server  
 if (CheckResponse(RSET_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

// Message will hold the message body: 
BOOL CPop3Comm::Retrieve(int  MsgNumber) 
{ 
 char inBuf [512]; 

 m_todisk=FALSE;
 wsprintf (inBuf, "RETR %d\r\n",MsgNumber );
 m_Socket.Send(inBuf, strlen (inBuf));//send RETR command to server  
 if (CheckResponse(RETR_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

BOOL CPop3Comm::Retrieve(int  MsgNumber, CString fileName) 
{ 
 char inBuf [512]; 

 if (SetOutputFile(fileName)) m_todisk=TRUE;
 else
 {
	m_ErrorMessage = _T("Error (POP3): failed to open output file.");
	 return FALSE;
 }
 wsprintf (inBuf, "RETR %d\r\n",MsgNumber );
 m_Socket.Send(inBuf, strlen (inBuf)); 
 if (CheckResponse(RETR_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

BOOL CPop3Comm::Statistics() 
{ 
 char inBuf [512]; 

 wsprintf (inBuf, "STAT \r\n"); 
 m_Socket.Send(inBuf, strlen (inBuf)); //send STAT command to server 
 if (CheckResponse(STAT_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

CString CPop3Comm::GetMsgContents() 
{ 
 return m_MsgContents; 
} 

int CPop3Comm::GetNumberOfMails() 
{ 
 return m_NumberMail; 
} 

int CPop3Comm::GetTotalMailSize() 
{ 

  return m_TotalSize; 
} 
//////////////////////////////////////////////////////////////////
CString CPop3Comm::GetHeaderItem(const CString& sName) const
{
	//Value which will be returned by this function
	CString sField;
	
	//Get the message header (add an extra "\r\n" at the
	//begining to aid in the parsing)  
	CString sHeader(_T("\r\n"));
	sHeader += GetHeader();
	CString sUpCaseHeader(sHeader);
	sUpCaseHeader.MakeUpper();
	
	CString sUpCaseName(sName);
	sUpCaseName.MakeUpper();
	
	//Find the specified line in the header
	CString sFind(CString(_T("\r\n")) + sUpCaseName + _T(":"));
	int nFindLength = sFind.GetLength();
	int nFindStart = sUpCaseHeader.Find(sFind);
	int nFind = nFindStart;
	//for (int i=0; i<nItem; i++) 
	//{
		//Get ready for the next loop around
		sUpCaseHeader = sUpCaseHeader.Right(sUpCaseHeader.GetLength() - nFind - nFindLength);
		nFind = sUpCaseHeader.Find(sFind);
		
		if (nFind == -1)
			return _T(""); //Not found
		else
			nFindStart += (nFind + nFindLength);
	//}
	
	if (nFindStart != -1)
		nFindStart += (3 + sName.GetLength());
	if (nFindStart != -1)
	{
		BOOL bFoundEnd = FALSE;
		int i = nFindStart;
		int nLength = sHeader.GetLength();
		do
		{
			//Examine the current 3 characters
			TCHAR c1 = _T('\0');
			if (i < nLength)
				c1 = sHeader[i];
			TCHAR c2 = _T('\0');
			if (i < (nLength-1))
				c2 = sHeader[i+1];
			TCHAR c3 = _T('\0');
			if (i < (nLength-2))
				c3 = sHeader[i+2];
			
			//Have we found the terminator
			if ((c1 == _T('\0')) ||
				((c1 == _T('\r')) && (c2 == _T('\n')) && (c3 != _T(' ')) && c3 != _T('\t')))
			{
				bFoundEnd = TRUE;
			}
			else
			{
				//Move onto the next character	
				++i;
			}
		}
		while (!bFoundEnd);
		sField = sHeader.Mid(nFindStart, i - nFindStart);
		
		//Remove any embedded "\r\n" sequences from the field
		int nEOL = sField.Find(_T("\r\n"));
		while (nEOL != -1)
		{
			sField = sField.Left(nEOL) + sField.Right(sField.GetLength() - nEOL - 2);
			nEOL = sField.Find(_T("\r\n"));
		}
		
		//Replace any embedded "\t" sequences with spaces
		int nTab = sField.Find(_T('\t'));
		while (nTab != -1)
		{
			sField = sField.Left(nTab) + _T(' ') + sField.Right(sField.GetLength() - nTab - 1);
			nTab = sField.Find(_T('\t'));
		}
		
		//Remove any leading or trailing white space from the Field Body
		sField.TrimLeft();
		sField.TrimRight();
	}
	
	return sField;
}

CString CPop3Comm::GetHeader() const
{
	//Value which will be returned by this function
	CString sHeader;
	
	//Find the divider between the header and body
	CString sMessage(m_pszMessage);
	int nFind = sMessage.Find(_T("\r\n\r\n"));
	if (nFind != -1)
		sHeader = sMessage.Left(nFind);
	else
	{
		//No divider, then assume all the text is the header
		sHeader = sMessage;
	}
	
	return sHeader;
}


/////////////////////////////////////////////////////////////////
BOOL CPop3Comm::Connect() 
{ 
 return Connect(m_Host, m_port, m_User, m_Password); 
} 

void CPop3Comm::SetHost(CString Host) 
{ 
 m_Host = Host; 
} 

CString CPop3Comm::GetHost() 
{ 
 return m_Host; 
} 

void CPop3Comm::SetUser(CString User) 
{ 
 	m_User = User; 
} 

CString CPop3Comm::GetUser() 
{ 
 return m_User; 
} 

void CPop3Comm::SetPassword(CString Password) 
{ 
 m_Password = Password; 
} 

CString CPop3Comm::GetPassword() 
{ 
 return m_Password; 
} 

BOOL CPop3Comm::CheckResponse(int ResponseType) 
{ 
 
//TCP receive window size (the amount of received data in bytes, 
//that can be buffered at one time on a connection, 8K by default):	
 char inBuf[8192];  
 int	iBytesReceived,iBytesToSkip;
 BOOL	bReadyToReceive;

 //Prepare buffer to receive data setting array's elements in zero:
 for (int i=0;i<sizeof(inBuf);i++) 
  inBuf[i]='\0'; 

 iBytesReceived=m_Socket.Receive(inBuf, sizeof(inBuf)); 

 // Sleep() often specifies the number of milliseconds 
 // that write operation will be delayed if the read buffer is not full
 // thus preventing to trash the network:
 //   Sleep(100);

 switch (ResponseType) 
 { 
  case CONNECTION_CHECK: 
   if (strnicmp(inBuf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error (POP3): connection failure."); 
    return FALSE; 
   } 
   break; 

  case USER_CHECK: 
   if (strnicmp(inBuf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error (POP3): wrong user name."); 
    return FALSE; 
   } 
   break; 
  case PASSWORD_CHECK: 
   if (strnicmp(inBuf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error (POP3): wrong password."); 
    return FALSE; 
   } 
   break; 
  case QUIT_CHECK: 
   if (strnicmp(inBuf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error (POP3): error occured during QUIT."); 
    return FALSE; 
   } 
   break; 
  case DELETE_CHECK: 
   if (strnicmp(inBuf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error (POP3): error occured during DELE."); 
    return FALSE; 
   } 
   break; 
  case RSET_CHECK: 
   if (strnicmp(inBuf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error (POP3): error occured during RSET."); 
    return FALSE; 
   } 
   break; 
  case STAT_CHECK: 
   if (strnicmp(inBuf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error (POP3): error occured during STAT."); 
    return FALSE; 
   } 
   else 
   { 
    BOOL EmailNumber = TRUE; 
    for (char *szTemp = inBuf; *szTemp != '\0'; szTemp++) 
    { 
     if (*szTemp == '\t' || *szTemp == ' ') 
     { 
      if(EmailNumber == TRUE) 
      { 
       m_NumberMail = atoi(szTemp); 
       EmailNumber = FALSE; 
      } 
      else 
      { 
       m_TotalSize = atoi(szTemp); 
       return TRUE; 
      } 
     } 
    } 
   } 
   break; 
  case NOOP_CHECK: 
   if (strnicmp(inBuf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error (POP3): error occured during NOOP."); 
    return FALSE; 
   } 
   break; 
  case LIST_CHECK: 
	if (strnicmp(inBuf,"-ERR", 4) == 0) 
	{ 
	    m_ErrorMessage = _T("Error (POP3): error occured during LIST."); 
		return FALSE; 
	} 
	else 
	{ 
		m_outputfile.Open(TEMP_LIST,CFile::modeCreate|CFile::modeWrite);
		if (m_outputfile==0)
		{
			//receive the rest of data and return false:
			if ((iBytesReceived!=0) && (iBytesReceived==sizeof(inBuf))) iBytesReceived=m_Socket.Receive(inBuf, sizeof(inBuf));

			m_ErrorMessage = _T("Error (POP3): error creating temporary input file.");
			return FALSE;
		}

	   bReadyToReceive=FALSE;
	   if (strnicmp(inBuf,"+OK \r\n", 6) == 0) iBytesToSkip=6;
	   else  iBytesToSkip=4;			//iBytesToSkip +OK(SPACE)
	   while (!bReadyToReceive)
	   {
			if (iBytesReceived==SOCKET_ERROR)
			{
				m_outputfile.Close();
				bReadyToReceive=TRUE;
				m_ErrorMessage = _T("Error (POP3): error reading from socket.");
				return FALSE;
			}
			else
			{
				m_outputfile.Write(inBuf+iBytesToSkip,iBytesReceived-iBytesToSkip);
				iBytesToSkip=0;
				if (
					((inBuf[iBytesReceived-3]=='.')&&(inBuf[iBytesReceived-2]=='\r')&&(inBuf[iBytesReceived-1]=='\n')) ||
					(iBytesReceived==0) ||
					((inBuf[0]='O')&&(inBuf[1]=='K')&&(inBuf[iBytesReceived-3]=='.')&&(inBuf[iBytesReceived-2]=='\r')&&(inBuf[iBytesReceived-1]=='\n'))
					)
				{
					bReadyToReceive=TRUE;
					m_outputfile.Close();
				}
				else
				{
					iBytesReceived=m_Socket.Receive(inBuf, sizeof(inBuf));
				}
			}
	   }

		return MakeMsgList();
   }
   break; 
  case RETR_CHECK: 
   if (strnicmp(inBuf,"-ERR", 4) == 0) 
   { 
    m_ErrorMessage = _T("Error (POP3): error occured during RETR."); 
	if (m_todisk) m_outputfile.Close();
    return FALSE; 
   } 
   else 
   { 
	   iBytesToSkip=0;
	   if (strnicmp(inBuf,"+OK", 3) == 0)
	   {
		   int j=0;
		   while (inBuf[j]!='R') j++;
		   iBytesToSkip=j;
	   }
	bReadyToReceive=FALSE;
    while (!bReadyToReceive)
	{
		if (iBytesReceived==SOCKET_ERROR)
		{
			if (m_todisk) m_outputfile.Close();
			bReadyToReceive=TRUE;
			m_ErrorMessage = _T("Error (POP3): error reading from socket.");
			return FALSE;
		}
		else
		{
			if (m_todisk) m_outputfile.Write(inBuf+iBytesToSkip,iBytesReceived-iBytesToSkip);
			iBytesToSkip=0;
			if (
				((inBuf[iBytesReceived-3]=='.')&&(inBuf[iBytesReceived-2]=='\r')&&(inBuf[iBytesReceived-1]=='\n')) ||
				(iBytesReceived==0)
				)
			{
				bReadyToReceive=TRUE;
				if (m_todisk) m_outputfile.Close();
			}
			else
			{
				iBytesReceived=m_Socket.Receive(inBuf, sizeof(inBuf)); 
			}
		}
	}	
	if (!m_todisk) m_MsgContents = inBuf; 
/*///////////////////////////////////////////////////////////////	
    ofstream logfile("Logfile.txt",ios::app);//open file "Logfile.txt" for output
    logfile<<"m_MsgContents: "<<m_MsgContents<<"\n";
	//logfile<<"iBytesReceived : "<<iBytesReceived <<"\n";
	logfile.close();
						
//////////////////////////////////////////////////////*/
   } 
   break; 
  case TOP_CHECK: 
	m_outputfile.Open(TEMP_TOP,CFile::modeCreate|CFile::modeWrite);
	if (m_outputfile==0)
	{
		//receive the rest of data and return false;
		if ((iBytesReceived!=0) && (iBytesReceived==sizeof(inBuf))) iBytesReceived=m_Socket.Receive(inBuf, sizeof(inBuf));
		m_ErrorMessage = _T("Error (POP3): creating temporary input file.");
		return FALSE;
	}

   bReadyToReceive=FALSE;
   if (strnicmp(inBuf,"+OK \r\n", 6) == 0) iBytesToSkip=6;
   else  iBytesToSkip=4;			//iBytesToSkip +OK(SPACE)
   while (!bReadyToReceive)
   {
		if (iBytesReceived==SOCKET_ERROR)
		{
			//receive the rest of data and return false;
			if ((iBytesReceived!=0) && (iBytesReceived==sizeof(inBuf))) iBytesReceived=m_Socket.Receive(inBuf, sizeof(inBuf));
			m_outputfile.Close();
			bReadyToReceive=TRUE;
			m_ErrorMessage = _T("Error (POP3): error reading from socket.");
			return FALSE;
		}
		else
		{
			m_outputfile.Write(inBuf+iBytesToSkip,iBytesReceived-iBytesToSkip);
			iBytesToSkip=0;
			if (
				((inBuf[iBytesReceived-3]=='.')&&(inBuf[iBytesReceived-2]=='\r')&&(inBuf[iBytesReceived-1]=='\n')) ||
				(iBytesReceived==0)
				)
			{
				bReadyToReceive=TRUE;
				m_outputfile.Close();
			}
			else
			{
				iBytesReceived=m_Socket.Receive(inBuf, sizeof(inBuf));
			}
		}
   }
   if (ExtractTop(TEMP_TOP))
   {
	CFile::Remove(TEMP_TOP);
	return TRUE;
   }
   else
   {
	CFile::Remove(TEMP_TOP);
	return FALSE;
   }


   break; 
 } 
 return TRUE; 
} 

CString CPop3Comm::GetErrorMessage() 
{ 
 return m_ErrorMessage; 
} 

BOOL CPop3Comm::List() 
{ 
 char inBuf [512]; 

 wsprintf (inBuf, "LIST  \r\n"); 
 m_Socket.Send(inBuf, strlen (inBuf)); 
 if (CheckResponse(LIST_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 

BOOL CPop3Comm::GetTop(int MsgNumber, int Length) 
{ 
 char inBuf [512]; 

 m_todisk=FALSE;
 wsprintf (inBuf, "TOP %d %d\r\n",MsgNumber,Length );
 m_Socket.Send(inBuf, strlen (inBuf)); 
 if (CheckResponse(TOP_CHECK)==FALSE) 
  return FALSE; 
 else 
  return TRUE; 
} 


void CPop3Comm::SetPort(int port)
{
	m_port=port;
}


BOOL CPop3Comm::SetOutputFile(CString fileName)
{
TRY
{
	m_outputfile.Open(fileName,CFile::modeCreate|CFile::modeWrite);
	return TRUE;
}
CATCH( CFileException, e )
{
	MessageBox(NULL,"error opening output file.","Error (POP3):",MB_OK);
	return FALSE;
}
END_CATCH
}

BOOL CPop3Comm::ExtractTop(CString fileName)
{
	CString tcstring;
	int pos;

TRY{
	CStdioFile f(fileName,CFile::modeRead);
	while (f.ReadString(tcstring))
	{
		tcstring.TrimLeft(); 
		tcstring.TrimRight();
		if (tcstring.Find('\r')!=-1) // if Carriage Return
			tcstring=tcstring.Left(tcstring.GetLength()-1);
		if (tcstring.Find('\n')!=-1) // if New Line
			tcstring=tcstring.Left(tcstring.GetLength()-1);
			tcstring.TrimLeft(); 
			tcstring.TrimRight();

		if (pos=tcstring.Find("To:")==0) 
			t_To=tcstring.Right(tcstring.GetLength()-sizeof("To:"));
		if (pos=tcstring.Find("From:")==0) 
			t_From=tcstring.Right(tcstring.GetLength()-sizeof("From:"));
		if (pos=tcstring.Find("Subject:")==0) 
			t_Subject=tcstring.Right(tcstring.GetLength()-sizeof("Subject:"));
		if (pos=tcstring.Find("Date:")==0) 
			t_Date=tcstring.Right(tcstring.GetLength()-sizeof("Date:"));
		if (pos=tcstring.Find("Content-Type:")==0) 
			t_Attachment=tcstring.Right(tcstring.GetLength()-sizeof("Content-Type:"));
	}
	f.Close();
	//if ((t_To=="")||(t_From=="")||(t_Date=="")) return FALSE;
	if (t_To == "") return FALSE;
	else return TRUE;
}
CATCH( CFileException, e ){
	m_ErrorMessage="Exception: could not open message file.";
	return FALSE;
}END_CATCH

}

BOOL CPop3Comm::MakeMsgList()
{
	m_SizeOfMsg.RemoveAll();
	CString tcstring;
	int j;

TRY{
	CStdioFile f(TEMP_LIST,CFile::modeRead);
	while (f.ReadString(tcstring))
	{
		tcstring.TrimLeft(); tcstring.TrimRight();
		if (tcstring.Find('\r')!=-1) tcstring=tcstring.Left(tcstring.GetLength()-1);
		if (tcstring.Find('\n')!=-1) tcstring=tcstring.Left(tcstring.GetLength()-1);
		tcstring.TrimLeft(); tcstring.TrimRight();
		j=tcstring.Find(' ');
		if (j!=-1)
		{
			tcstring=tcstring.Mid(j+1,tcstring.GetLength());
			m_SizeOfMsg.Add(atoi(tcstring));

		}
	}
	f.Close();
	CFile::Remove(TEMP_LIST);
	return TRUE;
}
CATCH( CFileException, e ){
	m_ErrorMessage="Exception: could not open TEMP_LIST file.";
	CFile::Remove(TEMP_LIST);
	return FALSE;
}END_CATCH
}
