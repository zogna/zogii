// MailAccount.cpp : implementation file
//

#include "stdafx.h"

#include "Email.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//These variables are defined in MailReceive.cpp translation unit:
extern int nEditAccount;//condition variable
extern int nItem;//item's number in the list 
/////////////////////////////////////////////////////////////////////////////
// CMailAccount dialog


CMailAccount::CMailAccount(CWnd* pParent /*=NULL*/)
	: CDialog(CMailAccount::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMailAccount)
	m_sPassword = _T("");
	m_sServer = _T("");
	m_sUsername = _T("");
	m_nPort = 110;
	//}}AFX_DATA_INIT
}


void CMailAccount::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMailAccount)
	DDX_Text(pDX, IDC_POP3_PASSWORD, m_sPassword);
	DDX_Text(pDX, IDC_POP3_SERVER, m_sServer);
	DDX_Text(pDX, IDC_POP3_USERNAME, m_sUsername);
	DDX_Text(pDX, IDC_PORT, m_nPort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMailAccount, CDialog)
	//{{AFX_MSG_MAP(CMailAccount)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

////////////////////////////////////////////////////////////////////////////
// CMailAccount message handlers

void CMailAccount::OnOK() 
{

//From MSDN: "For a modal dialog box, you can retrieve any data the user entered 
//when DoModal returns IDOK but before the dialog object is destroyed. 
//For a modeless dialog box, you can retrieve data from the dialog object 
//at any time by calling UpdateData with the argument TRUE 
//and then accessing dialog class member variables."
	
  UpdateData();//default TRUE argument

  if(m_sServer.IsEmpty() ||	m_sUsername.IsEmpty() || m_sPassword.IsEmpty())
  {
    AfxMessageBox("Error: you have to fill out all the fields.");
	return;
  }
  else 
  {

//Save account's data in file Settings.ini:
    char   IniFile[MAX_PATH];  
    HANDLE  hFile;
	char inBuf[180];
	char szBuffer[80];
    
	//get the path to current directory:
	GetCurrentDirectory(MAX_PATH, IniFile);
	
	//add to path the name of .ini file:
	lstrcat( IniFile, "\\Settings.ini" ); 

    
     if( hFile = CreateFile( IniFile, 
                           GENERIC_WRITE, 
                           FILE_SHARE_READ, 
                           NULL, 
                           OPEN_ALWAYS, 
                           FILE_ATTRIBUTE_NORMAL, 
                           NULL)) 			
        CloseHandle(hFile); 
	 	
		//First, get the total number of accounts:
		GetPrivateProfileString ("Accounts", "Number", 
								"0", szBuffer, 180, 
								IniFile);
		
	    
		 iNumAccounts=atoi(szBuffer);

		 //Add the account:
		 if (nEditAccount==0)
		 {
			 iNumAccounts++;
			 wsprintf(inBuf,"%d", iNumAccounts);
			 WritePrivateProfileString("Accounts", 
									  "Number", 
									   inBuf, 
									   IniFile);
   
			WritePrivateProfileString("IncomingMail", 
									   inBuf, 
									   m_sServer, 
									   IniFile);

			WritePrivateProfileString("Username", 
									   inBuf, 
									   m_sUsername, 
									   IniFile); 

			WritePrivateProfileString("Password", 
									   inBuf, 
									   m_sPassword, 
									   IniFile); 
		
			//convert int to char:
			wsprintf(szBuffer,"%d", m_nPort); 
			WritePrivateProfileString("Port", 
									   inBuf, 
									   szBuffer, 
									   IniFile); 

		 }
		 //Otherwise, edit the selected account:
		 else
		 {
			wsprintf(inBuf,"%d", nItem+1);
			   
			WritePrivateProfileString("IncomingMail", 
									   inBuf, 
									   m_sServer, 
									   IniFile);

			WritePrivateProfileString("Username", 
									   inBuf, 
									   m_sUsername, 
									   IniFile); 

			WritePrivateProfileString("Password", 
									   inBuf, 
									   m_sPassword, 
									   IniFile); 
		
			//convert int to char:
			wsprintf(szBuffer,"%d", m_nPort); 
			WritePrivateProfileString("Port", 
									   inBuf, 
									   szBuffer, 
									   IniFile); 
//////////////////////////////////////////////////////////
		 }	
	}
  	CDialog::OnOK();
}
