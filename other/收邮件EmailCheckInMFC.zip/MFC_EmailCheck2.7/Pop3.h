/*-------------------------------------------------------------------- 
 Pop3.h: main header file for the POP3 protocol (Pop3.cpp application) 
-----------------------------------------------------------------------*/ 

#if !defined(AFX_POP_H__A44B38B6_697C_11D1_881E_00001C302581__INCLUDED_) 
#define AFX_POP_H__A44B38B6_697C_11D1_881E_00001C302581__INCLUDED_ 

#define CONNECTION_CHECK 0 
#define USER_CHECK  1 
#define PASSWORD_CHECK 2 
#define QUIT_CHECK  3 
#define DELETE_CHECK 4 
#define RSET_CHECK  5 
#define STAT_CHECK  6 
#define NOOP_CHECK  7 
#define LIST_CHECK  8 
#define RETR_CHECK  9 
#define TOP_CHECK	10

///////////////////////////////////////////////////////////////////////////// 
//CPop3Comm class (communication using POP3 protocol)
//
class CPop3Comm
{ 
public: 
	BOOL MakeMsgList();
	BOOL ExtractTop(CString fname);
 void SetPort(int port);
 BOOL List(); 
 CWordArray m_SizeOfMsg; 
 CString GetErrorMessage();				// If there is any error this will return it method 
 CString GetPassword();					// Getting Password stored in class 
 void SetPassword(CString Password);   // Setting Password in class 
 CString GetUser();						// Getting user name stored in class 
 void SetUser(CString User);			// Setting user name in class 
 CString GetHost();						// Getting Host name (email server name) stored in class 
 void SetHost(CString Host);			// Setting Host name (email server name) in class 
 BOOL Connect();						// Connecting to email server 
 int GetTotalMailSize();                // it returns the Total Mail Size 
 int GetNumberOfMails();				// It return the number of mails 
 CString GetMsgContents();         
 BOOL Statistics();						// issue the STAT command on email server 
 BOOL Retrieve(int MsgNumber);			// Getting any particular mail message 
 BOOL Retrieve(int  MsgNumber,CString fname); // Getting any particular mail message to file
 BOOL Reset();							// issue the reset command on email server 
 int  GetMessageSize(int MsgNumber);    // Return a size of any particular mail 
 BOOL Noop();							// issue the NOOP command on email server 
 BOOL Disconnect();						// issue the QUIT command on email server 
 BOOL Delete(int MsgNumber);			// Deleteing a particular message from email server 
 BOOL Connect(CString& Host, int Port, CString& User, CString& Password); 
 BOOL GetTop(int MsgNumber, int Length);
 CString t_Attachment,t_To,t_From,t_Subject,t_Date;

 CString GetHeaderItem(const CString& sName) const;
 CString GetHeader() const;

 char* m_pszMessage;

 //Constructor/destructor:
 CPop3Comm(); 
 virtual ~CPop3Comm();
 
//CSocket is not private member because we have to
//access it from the other thread to close if communication got stuck:
 CSocket m_Socket;

private:
 CString m_ErrorMessage; 
 BOOL CheckResponse(int ResponseType); 
 BOOL SetOutputFile(CString fname);
 CString m_Password; 
 CString m_User; 
 CString m_Host; 
 CString m_MsgContents; 
 int	m_port;
 int m_TotalSize; 
 int m_NumberMail; 

 CStdioFile m_outputfile;
 BOOL	m_todisk;
}; 
#endif // !defined(AFX_POP_H__A44B38B6_697C_11D1_881E_00001C302581__INCLUDED_) 
