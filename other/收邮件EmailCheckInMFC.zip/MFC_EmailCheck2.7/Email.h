// Email.h : main header file for the EMAIL application
//

#if !defined(AFX_EMAIL_H__F08D76E5_83A3_4808_B666_32DD9913B983__INCLUDED_)
#define AFX_EMAIL_H__F08D76E5_83A3_4808_B666_32DD9913B983__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "Pop3.h"


//Global variables:
static int iNumAccounts;//to count the number of accounts
/////////////////////////////////////////////////////////////////////
//The worker thread used to close the socket if the communication 
//(implemented in user interface thread) got stuck:
UINT ThreadProc(LPVOID pParam);

///////////////////////////////////////////////////////////////////////
// CThreadInfo.
//	Class (structure/union) with information to be passed to the worker thread.
//	In this application we need only the pointer to the socket. 
//	The class itself is created as an example of how the data 
//  can be transfered in another thread (the object of this class 
//  is used also in CMailPop3):
class CThreadInfo: public CWinThread
{
public:
	int m_nEventTerminateThread;// condition variable
	HANDLE m_hEventTerminateThread;//handle to event
	CPop3Comm	m_Pop3Comm;//a socket
};
///////////////////////////////////////////////////////////////////////
// CEmailApp.
// See Email.cpp for the implementation of this class
//
class CEmailApp : public CWinApp
{
public:
	CEmailApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEmailApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Declarations:

public:
	//{{AFX_MSG(CEmailApp)
	afx_msg void OnAppAbout();
	
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CChildView window

class CChildView : public CWnd
{
// Construction
public:
	CChildView();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildView)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Declarations:
public:
	virtual ~CChildView();

	// Generated message map functions
protected:
	//{{AFX_MSG(CChildView)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
class CMainFrame : public CFrameWnd
{
	
public:
	CMainFrame();

protected: 
	DECLARE_DYNAMIC(CMainFrame)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	//}}AFX_VIRTUAL

// Declarations:
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CChildView    m_wndView;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSetFocus(CWnd *pOldWnd);
			// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CComboEx class

class CComboEx : public CComboBox
{
// Construction
public:
	CComboEx();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CComboEx)
	public:
	//virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Declarations:
public:
	virtual ~CComboEx();

	BOOL m_bAutoComplete;

	// Generated message map functions
protected:
	//{{AFX_MSG(CComboEx)
	afx_msg void OnEditUpdate();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CMailConfig dialog

class CMailConfig : public CDialog
{
// Construction
public:
	CMailConfig(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMailConfig)
	enum { IDD = IDD_MAIL_CONFIG };
	CEdit	m_Signature;
	CString	m_sSignature;
	CString	m_sServer;
	CString	m_sXMailer;
	//}}AFX_DATA

  CToolTipCtrl m_ToolTip;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMailConfig)
	public:
	//virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Declarations:
protected:
	// Generated message map functions
	//{{AFX_MSG(CMailConfig)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// CMailPop3 dialog

class CMailPop3 : public CDialog
{
	DECLARE_DYNCREATE(CMailPop3)

// Construction
public:
	CMailPop3();
	~CMailPop3();

// Dialog Data
	//{{AFX_DATA(CMailPop3)
	enum { IDD = IDD_MAIL_POP3 };
	CListCtrl	m_Servers;
	CListCtrl	m_Mails;
	CEdit		m_Message;
	CString		m_sMessage;
	//}}AFX_DATA

	CString			m_InformMessage;
	CProgressCtrl   m_ProgressBar;

	CThreadInfo		m_CThreadInfo;//object of worker thread info class
    
	struct ACCOUNT
	{
	  CString sServer;
	  int nPort;
	  CString sUsername;
	  CString sPassword;
	}userAccount[100];
   
	CArray<ACCOUNT,ACCOUNT&> m_aAccounts;

//Base64 decode fuinctions:
	void Decodeblock(unsigned char szIn[4], unsigned char szOut[3]);
	void Decode(FILE *inputFile, FILE *outputFile);
	
// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CMailPop3)
	public:
	//virtual BOOL PreTranslateMessage(MSG* pMsg);

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	// Generated message map functions
	//{{AFX_MSG(CMailPop3)
	afx_msg void OnAdd();
	afx_msg void OnEdit();
	virtual BOOL OnInitDialog();
	afx_msg void OnRemove();
	afx_msg void OnReceive();
	afx_msg void OnReply();
	afx_msg void OnReadHeaders();
	afx_msg void OnReadMail();
	afx_msg void OnDblclkServers();
	afx_msg void OnDontDelete();
	afx_msg void OnDeleteFromServer();
	afx_msg void OnGetAttachment(); 
	afx_msg void OnSize (UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CMailAccount dialog

class CMailAccount : public CDialog
{
// Construction
public:
	CMailAccount(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMailAccount)
	enum { IDD = IDD_MAIL_ACCOUNT };
	CString	m_sPassword;
	CString	m_sServer;
	CString	m_sUsername;
	int		m_nPort;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMailAccount)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMailAccount)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EMAIL_H__F08D76E5_83A3_4808_B666_32DD9913B983__INCLUDED_)
