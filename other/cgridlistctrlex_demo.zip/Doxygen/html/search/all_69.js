var searchData=
[
  ['introduction',['Introduction',['../index.html',1,'']]],
  ['insertcolumntrait',['InsertColumnTrait',['../class_c_grid_list_ctrl_ex.html#afaadc6cb087a3278d8bea802e6994e59',1,'CGridListCtrlEx::InsertColumnTrait(int nCol, const CString &amp;strColumnHeading, int nFormat=LVCFMT_LEFT, int nWidth=-1, int nSubItem=-1, CGridColumnTrait *pTrait=NULL)'],['../class_c_grid_list_ctrl_ex.html#ae182fc1595ecdad45f8209f10af10492',1,'CGridListCtrlEx::InsertColumnTrait(int nCol, CGridColumnTrait *pTrait)']]],
  ['insertgroupheader',['InsertGroupHeader',['../class_c_grid_list_ctrl_groups.html#a0b4e593290b23e18de7fe7e80909d7f6',1,'CGridListCtrlGroups']]],
  ['inserthiddenlabelcolumn',['InsertHiddenLabelColumn',['../class_c_grid_list_ctrl_ex.html#a1821acd36833fa009d8dce2dad0ad3c3',1,'CGridListCtrlEx']]],
  ['internalcolumnpicker',['InternalColumnPicker',['../class_c_grid_list_ctrl_ex.html#ab49ad4743ad784718ea4e0844e60e4e8',1,'CGridListCtrlEx']]],
  ['internalcolumnprofileswitcher',['InternalColumnProfileSwitcher',['../class_c_grid_list_ctrl_ex.html#a3857b77fd2e349c16c6ef6d258023d46',1,'CGridListCtrlEx']]],
  ['iscellcallback',['IsCellCallback',['../class_c_grid_list_ctrl_ex.html#a1b4722e43184fb26a83870be364bb466',1,'CGridListCtrlEx']]],
  ['iscelleditoropen',['IsCellEditorOpen',['../class_c_grid_list_ctrl_ex.html#a6318b3e79b0be4091411b752a329cc6e',1,'CGridListCtrlEx']]],
  ['iscellreadonly',['IsCellReadOnly',['../class_c_grid_column_trait.html#aee67c96acc75df71b6b3d1989d386f7f',1,'CGridColumnTrait::IsCellReadOnly()'],['../class_c_grid_column_trait_image.html#a36318c4778486cc897dcddb98882ac25',1,'CGridColumnTraitImage::IsCellReadOnly()']]],
  ['iscolumnalwayshidden',['IsColumnAlwaysHidden',['../class_c_grid_list_ctrl_ex.html#a6903fae110bdfa193b9666bf14a76a2b',1,'CGridListCtrlEx']]],
  ['iscolumnalwaysvisible',['IsColumnAlwaysVisible',['../class_c_grid_list_ctrl_ex.html#a4f0d1cfed1833f6c28b504668d280752',1,'CGridListCtrlEx']]],
  ['iscolumnresizable',['IsColumnResizable',['../class_c_grid_list_ctrl_ex.html#a45778b09577d376073a883d243502034',1,'CGridListCtrlEx']]],
  ['iscolumnvisible',['IsColumnVisible',['../class_c_grid_list_ctrl_ex.html#a09811da39862290d7c0dc4a2a955c019',1,'CGridListCtrlEx']]],
  ['isgroupstateenabled',['IsGroupStateEnabled',['../class_c_grid_list_ctrl_groups.html#ae5a7ffe070b2bbc1d1d2212ccbece7b8',1,'CGridListCtrlGroups']]],
  ['isrowselected',['IsRowSelected',['../class_c_grid_list_ctrl_ex.html#a0b543152b1c270c8f267d718d841ba6f',1,'CGridListCtrlEx']]]
];
