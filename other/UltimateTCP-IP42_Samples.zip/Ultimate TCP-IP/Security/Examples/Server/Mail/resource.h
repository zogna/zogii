//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Main.rc
//
#define IDD_ABOUT                       102
#define IDD_DIALOG2                     103
#define IDI_ICON1                       106
#define IDD_DIALOG1                     107
#define IDD_DIALOG3                     108
#define IDD_MODIFY_USERS_INFO           109
#define IDD_SPLASH                      110
#define IDB_BITMAP1                     111
#define IDD_DIALOG_CONFIG               112
#define IDD_DIALOG_LIST                 113
#define IDC_BUTTON2                     1001
#define IDC_REMOVE_LOCAL_NAME           1001
#define IDC_ADD_ALIAS                   1001
#define IDC_BUTTON_USERS                1001
#define IDC_REMOVE_DNS_NAME             1002
#define IDC_EXIT                        1004
#define IDC_ABOUT                       1008
#define IDC_COMBO_PROTOCOL              1009
#define IDC_CONFIG                      1010
#define IDC_LIST1                       1011
#define IDC_EMAIL_ALIASES_LIST          1011
#define IDC_ADD_LOCAL_NAME              1012
#define IDC_LIST2                       1013
#define IDC_EDIT_CERT                   1013
#define IDC_ADD_DNS_NAME                1014
#define IDC_BUTTON_CERT                 1014
#define IDC_CHECK_AUTH                  1015
#define IDC_LIST3                       1016
#define IDC_USER_LIST                   1016
#define IDC_EDIT_PORT                   1016
#define IDC_ADD_USER                    1017
#define IDC_REMOVE_USER                 1018
#define IDC_EDIT1                       1019
#define IDC_MODIFY_USER_NAME            1019
#define IDC_EDIT2                       1020
#define IDC_MODIFY_PASSWORD             1020
#define IDC_EDIT_PORT_POP3              1020
#define IDC_EDIT3                       1021
#define IDC_NEW_EMAIL_ALIAS             1021
#define IDC_EDIT_ROOT_PATH              1021
#define IDC_USER_NAME                   1022
#define IDC_USER_PASSWORD               1023
#define IDC_USER_MAIL                   1024
#define IDC_REMOVE_ALIASE               1025
#define IDC_MODIFY_NEW_NAME             1026
#define IDC_GENRAL                      1027
#define IDC_SHUTDOWN                    1028
#define IDC_STARTUP                     1029
#define IDC_BUTTON_START                1030
#define IDC_CHECK_IMMEDIATE_NEG         1031
#define IDC_EDIT_MAX_THREAD             1031
#define IDC_EDIT_MAX_RETRIES            1032
#define IDC_EDIT_RETRY_INTERVAL         1034
#define IDC_BUTTON_DOMAIN_NAMES         1035
#define IDC_BUTTON_DNS_NAMES            1036
#define IDC_STATIC_TITLE                1037
#define IDC_BUTTON_USER_INFO            1038
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
