// Test_Del.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#define _WIN32_WINNT 0x400

#include <windows.h>
#include <wincrypt.h>

CMSG_SIGNER_INFO i;

int main(int argc, char* argv[])
{
	printf("Hello World!\n");
	return 0;
}

