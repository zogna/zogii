//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FTPs.rc
//
#define IDC_STATUS                      100
#define IDD_FTPS_SERVER                 101
#define IDI_ICON1                       102
#define IDD_ABOUT                       103
#define IDD_DIALOG1                     104
#define IDC_EDIT                        1000
#define IDC_BUTTON_START                1001
#define IDC_EDIT_PATH                   1002
#define IDC_BROWSE                      1003
#define IDC_SETPATH                     1004
#define IDC_EDIT_CERT                   1005
#define IDC_COMBO_PROTOCOL              1007
#define IDC_EDIT_PORT                   1008
#define IDC_CHECK_AUTH                  1009
#define IDC_BUTTON_CERT                 1010
#define IDC_STATIC_MSG                  1011
#define IDC_ABOUT                       1012
#define IDC_EXIT                        1013
#define IDC_IMPLICIT                    1015
#define IDC_DISABLE_SSL                 1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
