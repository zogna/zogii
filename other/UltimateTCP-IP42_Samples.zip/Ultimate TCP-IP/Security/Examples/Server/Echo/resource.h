//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by echo.rc
//
#define IDD_ECHO_SERVER                 102
#define IDD_ABOUT                       103
#define IDC_STATUS                      110
#define IDC_SETPATH                     1001
#define IDC_EXIT                        1002
#define IDC_ABOUT                       1003
#define IDC_BUTTON_START                1008
#define IDC_COMBO_PROTOCOL              1009
#define IDC_CHECK_AUTH                  1010
#define IDC_EDIT_CERT                   1011
#define IDC_BUTTON_CERT                 1012
#define IDC_STATIC_MSG                  1013
#define IDC_EDIT_PORT                   1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
