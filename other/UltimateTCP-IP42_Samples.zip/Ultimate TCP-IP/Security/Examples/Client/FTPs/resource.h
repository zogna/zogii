//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Test.rc
//
#define IDD_ABOUT                       101
#define IDB_BITMAP1                     103
#define IDI_ICON1                       104
#define IDC_DISCONNECT                  1000
#define IDC_CONNECT                     1001
#define IDC_LIST                        1002
#define IDC_LISTPASV                    1003
#define IDC_EXIT                        1004
#define IDC_EDIT                        1005
#define IDC_HISTORY                     1006
#define IDC_RETRPASV                    1007
#define IDC_RETRFILE                    1007
#define IDC_SENDPASV                    1008
#define IDC_SENDFILE                    1008
#define IDC_BACKCOLOR                   1009
#define IDC_FILENAME                    1011
#define IDC_DIRCHANGE                   1012
#define IDC_CHANGEDIR                   1013
#define IDC_EDIT2                       1014
#define IDC_EDIT3                       1015
#define IDC_EDIT4                       1016
#define IDC_ABOUT                       1018
#define IDC_FIREWALL                    1019
#define IDC_SAVEAS                      1020
#define IDC_TRANSFER_MODE               1021
#define IDC_TRANSFER_TYPE               1021
#define IDC_RADIO1                      1022
#define IDC_RADIO2                      1023
#define IDC_RADIO3                      1024
#define IDC_DOS                         1025
#define IDC_QUOTE_DATA                  1026
#define IDC_QUOTE                       1027
#define IDC_TEST_REST                   1028
#define IDC_SECURE_SSL                  1029
#define IDC_PORT                        1030
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
