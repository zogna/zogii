//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UTFingerServ.rc
//
#define IDS_PROJNAME                    100
#define IDB_FINGERSERV                  101
#define IDR_FINGERSERV                  102
#define IDS_TITLEFingerServProp         103
#define IDS_HELPFILEFingerServProp      104
#define IDS_DOCSTRINGFingerServProp     105
#define IDR_FINGERSERVPROP              106
#define IDD_FINGERSERVPROP              107
#define IDD_ABOUTDLG                    108
#define IDI_ICON_FINGERSERV             201
#define IDC_PORT                        201
#define IDC_PATH                        202
#define IDC_MAX_CONNECTIONS             203
#define IDC_VERSION_TEXT                204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         204
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
