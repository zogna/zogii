//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UTHttp.rc
//
#define IDS_PROJNAME                    100
#define IDB_HTTP                        101
#define IDR_HTTP                        102
#define IDS_TITLEHttpPropPage           103
#define IDS_HELPFILEHttpPropPage        104
#define IDS_DOCSTRINGHttpPropPage       105
#define IDR_HTTPPROPPAGE                106
#define IDD_ABOUTDLG                    108
#define IDD_HTTPPROPPAGE                109
#define IDC_EDITCONNECT_TO              201
#define IDI_ICON_HTTP                   201
#define IDC_MAX_LINES_TO_STORE          202
#define IDC_PROXY_NAME                  203
#define IDC_VERSION_TEXT                204
#define IDC_BLOCKING_MODE               205

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         204
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
