//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UTPing.rc
//
#define IDS_PROJNAME                    100
#define IDB_PING                        101
#define IDR_PING                        102
#define IDS_TITLEPingProp               103
#define IDS_HELPFILEPingProp            104
#define IDS_DOCSTRINGPingProp           105
#define IDR_PINGPROP                    106
#define IDD_ABOUTDLG                    108
#define IDD_PINGPROP                    109
#define IDI_ICON_PING                   201
#define IDC_DO_LOOKUP                   201
#define IDC_EDIT_MAX_TIME_OUTS          202
#define IDC_VERSION_TEXT                204
#define IDC_BLOCKING_MODE               205

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         203
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
