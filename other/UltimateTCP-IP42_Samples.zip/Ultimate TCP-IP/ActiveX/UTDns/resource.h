//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UTDns.rc
//
#define IDS_PROJNAME                    100
#define IDB_DNS                         101
#define IDR_DNS                         102
#define IDS_TITLEDNSPropPage            103
#define IDS_HELPFILEDNSPropPage         104
#define IDS_DOCSTRINGDNSPropPage        105
#define IDR_DNSPROPPAGE                 106
#define IDD_DNSPROPPAGE                 107
#define IDD_ABOUTDLG                    108
#define IDI_ICON_DNS                    201
#define IDC_EDIT_LOOKUP_TO              201
#define IDC_INCL_DEF_MX                 202
#define IDC_VERSION_TEXT                204
#define IDC_PROTOCOL_TYPE               204
#define IDC_BLOCKING_MODE               205

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        204
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         205
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
