//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UTFtpServ.rc
//
#define IDS_PROJNAME                    100
#define IDB_FTPSERVER                   101
#define IDR_FTPSERV                     102
#define IDS_TITLEFtpServPropPage        103
#define IDS_HELPFILEFtpServPropPage     104
#define IDS_DOCSTRINGFtpServPropPage    105
#define IDR_FTPSERVPROPPAGE             106
#define IDD_FTPSERVPROPPAGE             107
#define IDD_ABOUTDLG                    108
#define IDC_PORT                        201
#define IDI_ICON_FTPSERV                201
#define IDC_PATH                        202
#define IDC_MAX_CONNECTIONS             203
#define IDC_VERSION_TEXT                204
#define IDC_WELCOME                     204
#define IDC_EDIT_MAX_TIME_OUT           205

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         206
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
