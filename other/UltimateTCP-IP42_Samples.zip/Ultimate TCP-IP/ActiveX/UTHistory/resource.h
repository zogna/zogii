//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UTHistory.rc
//
#define IDS_PROJNAME                    100
#define IDB_HISTORY                     101
#define IDR_HISTORY                     102
#define IDS_TITLEHistoryPropPage        103
#define IDS_HELPFILEHistoryPropPage     104
#define IDS_DOCSTRINGHistoryPropPage    105
#define IDR_HISTORYPROPPAGE             106
#define IDD_HISTORYPROPPAGE             107
#define IDD_ABOUTDLG                    108
#define IDC_ENABLE_LOG                  201
#define IDI_ICON_HISTORY                201
#define IDC_TIME_LOG                    202
#define IDC_LOG_NAME                    203
#define IDC_VERSION_TEXT                204
#define IDC_MARGIN                      205
#define IDC_ALIGNMENT                   206
#define IDC_STYLE                       207
#define IDC_HISTORY_LENGTH              208
#define IDC_TIMESTAMP_FORMAT            209

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         210
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
