//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UTMail.rc
//
#define IDS_PROJNAME                    100
#define IDB_MAIL                        101
#define IDR_MAIL                        102
#define IDS_TITLEMailPropPage           103
#define IDS_HELPFILEMailPropPage        104
#define IDS_DOCSTRINGMailPropPage       105
#define IDR_MAILPROPPAGE                106
#define IDD_MAILPROPPAGE                107
#define IDD_ABOUTDLG                    108
#define IDI_ICON_MAIL                   201
#define IDC_EDITCONNECT_TO              201
#define IDC_RECEIVE_TIME_OUT            202
#define IDB_BITMAP1                     202
#define IDC_POP3_HOST_NAME              203
#define IDC_VERSION_TEXT                204
#define IDC_MAIL_HOST_NAME              204
#define IDC_BLOCKING_MODE               205
#define IDC_LOCAL_HOST_NAME             206
#define IDC_PASSWORD                    207
#define IDC_USER_NAME                   208

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         207
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
