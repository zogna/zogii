//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UTImap4.rc
//
#define IDS_PROJNAME                    100
#define IDB_IMAP4                       101
#define IDR_IMAP4                       102
#define IDS_TITLEIMAP4PropPage          103
#define IDS_HELPFILEIMAP4PropPage       104
#define IDS_DOCSTRINGIMAP4PropPage      105
#define IDR_IMAP4PROPPAGE               106
#define IDD_ABOUTDLG                    108
#define IDD_IMAP4PROPPAGE               109
#define IDC_EDITCONNECT_TO              201
#define IDI_ICON_IMAP4                  201
#define IDC_RECEIVE_TIME_OUT            202
#define IDC_NEW_MAIL_INTERVAL           203
#define IDC_VERSION_TEXT                204
#define IDC_MAIL_HOST_NAME              204
#define IDC_HOST_NAME                   204
#define IDC_BLOCKING_MODE               205
#define IDC_PASSWORD                    207
#define IDC_USER_NAME                   208

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         204
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
