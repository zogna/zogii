//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UTFtp.rc
//
#define IDS_PROJNAME                    100
#define IDB_FTP                         101
#define IDR_FTP                         102
#define IDS_TITLEFtpPropPage            103
#define IDS_HELPFILEFtpPropPage         104
#define IDS_DOCSTRINGFtpPropPage        105
#define IDR_FTPPROPPAGE                 106
#define IDD_ABOUTDLG                    108
#define IDD_FTPPROPPAGE                 109
#define IDC_EDITCONNECT_TO              201
#define IDI_ICON_FTP                    201
#define IDC_FIRE_WALL_MODE              203
#define IDC_VERSION_TEXT                204
#define IDC_HOST_NAME                   204
#define IDC_BLOCKING_MODE               205
#define IDC_ACCOUNT                     206
#define IDC_PASSWORD                    207
#define IDC_USER_NAME                   208

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         209
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
