//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UTFinger.rc
//
#define IDS_PROJNAME                    100
#define IDB_FINGER                      101
#define IDR_FINGER                      102
#define IDS_TITLEFingerProp             103
#define IDS_HELPFILEFingerProp          104
#define IDS_DOCSTRINGFingerProp         105
#define IDR_FINGERPROP                  106
#define IDD_FINGERPROP                  107
#define IDD_ABOUTDLG                    108
#define IDI_ICON_FINGER                 201
#define IDC_EDITCONNECT_TO              201
#define IDC_RECEIVE_TO                  202
#define IDD_ABOUT_DIALOG                203
#define IDC_VERSION_TEXT                204
#define IDC_BLOCKING_MODE               205

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         206
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
