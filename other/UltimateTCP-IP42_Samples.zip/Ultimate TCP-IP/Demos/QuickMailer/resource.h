//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by QuickMailer.rc
//
#define IDD_DIALOG_ABOUT                101
#define IDB_BITMAP_ABOUT                102
#define IDD_DIALOG_MAIN                 103
#define IDR_MENU_TASKBAR_ICON           106
#define IDD_DIALOG_ADDMAILRECIPIENT     107
#define IDD_DIALOG_PROPERTIES           108
#define IDI_ICON_QUICK_MAILER           111
#define IDR_MENU_LIST                   113
#define IDD_DIALOG_SEND                 113
#define IDD_SPLASH                      114
#define IDB_BITMAP1                     115
#define IDI_ICON_QUICK_MAILER_SMALL     141
#define IDC_LIST_NAMES                  1001
#define IDC_EDIT_FROM                   1002
#define IDC_EDIT_NAME                   1003
#define IDC_EDIT_ADDRESS                1005
#define IDC_EDIT_MESSAGE                1006
#define IDC_EDIT_SEND_TO                1007
#define IDC_EDIT_SERVER                 1008
#define IDC_COMBO_SUBJECT               1010
#define IDC_CHECK_AUTO_RUN              1011
#define ID_TASKBAR_ADDMAILRECIPIENT     40005
#define ID_TASKBAR_PROPERTIES           40006
#define ID_TASKBAR_ABOUT                40007
#define ID_TASKBAR_EXIT                 40008
#define ID_TASKBAR_DELETEMAILRECIPIENTS 40009
#define ID_TASKBAR_SENDMAIL             40010
#define ID_TASKBAR_EDITMAILRECIPIENT    40011
#define ID_TASKBAR_HELP                 40012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
