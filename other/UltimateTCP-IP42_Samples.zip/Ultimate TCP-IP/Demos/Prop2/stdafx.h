// nothing
#ifndef __STDAX_JHHJJHGHJJH


#define _WINSOCK_2_0_
    // WINSOCK 2.0
    // When you you want to include winsock 2.0
    // the you need to link or load ws2_32.lib 
    // (There is only a 32 bit version of it )
#pragma comment(lib, "ws2_32.lib")
#include <winsock2.h>     //use for Winsock v2.x
#define WINSOCKVER    MAKEWORD(2,0)

#include <windows.h>
// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <commctrl.h>
#include <process.h>

#include "stdutfx.h"

#endif __STDAX_JHHJJHGHJJH


