// About.h: interface for the About class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ABOUT_H__94C985D9_8095_11D3_8B8C_0050BAAAE90D__INCLUDED_)
#define AFX_ABOUT_H__94C985D9_8095_11D3_8B8C_0050BAAAE90D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "UCPage.h"

class About : public CUCPage  
{
public:
	About(LPTSTR title);
	virtual ~About();

};

#endif // !defined(AFX_ABOUT_H__94C985D9_8095_11D3_8B8C_0050BAAAE90D__INCLUDED_)
