//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by test1.rc
//
#define IDD_DIALOG1                     101
#define IDI_ICON1                       102
#define IDD_DNS_PAGE                    103
#define IDD_FINGER_PAGE                 104
#define IDI_DNS                         105
#define IDD_PING_PAGE                   106
#define IDD_TRACE_PAGE1                 107
#define IDD_VERIFY_EMAIL                108
#define IDD_WHO_IS                      109
#define IDD_PING_PAGE2                  110
#define IDD_CONTACT                     111
#define IDD_SPLASH                      115
#define IDB_BITMAP1                     118
#define IDC_LIST1                       1000
#define IDC_HISTORY_DNS                 1001
#define IDC_QUERY_COMBO                 1002
#define IDC_USE_TCP                     1003
#define IDC_AUTHLOOKUPBTN               1004
#define IDC_LOOKUPBTN                   1005
#define IDC_DNSSERVER                   1006
#define IDC_LOOKUP                      1007
#define IDC_WHOISSERVER                 1008
#define IDC_WHO_IS_HISTORY              1009
#define IDC_WHO_IS_BTN                  1010
#define IDC_WHOIS_QUERY                 1011
#define IDC_USER_NDOMAIN                1014
#define IDC_FINGER_BTN                  1015
#define IDC_FINGER_HISTORY              1016
#define IDC_WHOIS_LOG_FILE              1017
#define IDC_WHOIS_ENABLE_LOOG           1018
#define IDC_DNS_LOG_FILE                1020
#define IDC_DNS_ENABLE_LOG              1021
#define IDC_FINGER_LOG_FILE             1023
#define IDC_FINGER_ENABLE_LOG           1024
#define IDC_BUTTON2                     1026
#define IDC_BUTTON1                     1027
#define IDC_DNS_ABOUT                   1027
#define IDC_FINGER_ABOUT                1027
#define IDC_PING_ABOUT                  1027
#define IDC_TRACE_ABOUT                 1027
#define IDC_WHOIS_ABOUT                 1027
#define IDC_PING_HISTORY                1028
#define IDC_PING_NDOMAIN                1029
#define IDC_PING_ENABLE_LOG             1030
#define IDC_PING_LOG_FILE               1031
#define IDC_PING_BTN                    1032
#define IDC_PING_INTERVALS              1033
#define IDC_PING_TIME_OUT               1034
#define IDC_PING_DATA_SIZE              1035
#define IDC_PING_NUMBER_HITS            1036
#define IDC_PING_NUMBER_TIMEOUTS        1038
#define IDC_PING_SHOW_NAME              1039
#define IDC_TRACE_NDOMAIN               1040
#define IDC_TRACE_BTN                   1041
#define IDC_TRACE_TIME_OUT              1043
#define IDC_TRACE_DATA_SIZE             1044
#define IDC_TRACE_NUMBER_HITS           1045
#define IDC_TRACE_LOG_FILE              1047
#define IDC_TRACE_ENABLE_LOG            1048
#define IDC_TRACE_SHOW_NAME             1049
#define IDC_TRACE_HISTORY               1050
#define IDC_VERIFY_EMAIL_TARGET         1051
#define IDC_VERIFY_BTN                  1052
#define IDC_VERIFY_HISTORY              1053
#define IDC_USING_EMAIL                 1054
#define IDC_VERIFY_SERVER               1055

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        119
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1057
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
