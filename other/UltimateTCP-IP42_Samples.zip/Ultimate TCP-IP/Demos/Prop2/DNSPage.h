// DNSPage.h: interface for the CDNSPage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DNSPAGE_H__3272A6F6_7140_11D3_8871_0080C86498A0__INCLUDED_)
#define AFX_DNSPAGE_H__3272A6F6_7140_11D3_8871_0080C86498A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "UCWnd.h"

class CDNSPage : public CUCWnd  
{
public:
	CDNSPage();
	virtual ~CDNSPage();

};

#endif // !defined(AFX_DNSPAGE_H__3272A6F6_7140_11D3_8871_0080C86498A0__INCLUDED_)
