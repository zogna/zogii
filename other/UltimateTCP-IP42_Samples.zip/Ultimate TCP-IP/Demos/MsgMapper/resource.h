//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MsgMapper.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_MSGMAPPER_FORM              101
#define IDR_MAINFRAME                   128
#define IDR_MsgMapperTYPE               129
#define IDC_EDITTEXT                    1001
#define IDC_TEXTBTN                     1005
#define IDC_HTMLBTN                     1006
#define IDC_BUTTON3                     1007
#define IDC_RAWBTN                      1007
#define ID_VIEW_                        32771
#define ID_VIEW_TEXT                    32772
#define ID_VIEW_RAW                     32773
#define IDS_VIEW_RAW                    32773
#define ID_VIEW_HTML                    32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
