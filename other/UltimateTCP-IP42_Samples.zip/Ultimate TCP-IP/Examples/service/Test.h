/******************************************************

  Ultimate Service Class Test Project - header file

*******************************************************/

int CALLBACK WinMain(HINSTANCE hInstance,HINSTANCE ,LPSTR ,int );
long CALLBACK DlgProc(HWND hwnd,UINT message,WPARAM wParam,LPARAM);
void EntryFunction(void * cus);
void StopFunction(void * cus);
