#ifndef STDAFX_SERVERTEST_
#define STDAFX_SERVERTEST_
#include <windows.h>
#include <process.h>

#include "stdutfx.h"	// standard ultimate TCP macros etc


#endif STDAFX_SERVERTEST_

