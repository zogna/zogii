//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Test.rc
//
#define IDD_DIALOG2                     101
#define IDI_ICON1                       102
#define IDD_ABOUT                       102
#define IDD_PASSOWRD_DLG                105
#define IDC_APPENDLINE                  1000
#define IDC_BUTTON2                     1000
#define IDC_HEAD                        1000
#define IDC_ADDLINE                     1001
#define IDC_BUTTON1                     1001
#define IDC_FINGER                      1001
#define IDC_GET                         1001
#define IDC_DATESTAMP                   1002
#define IDC_BUTTON3                     1002
#define IDC_DELETE                      1002
#define IDC_GETTAGSTRING                1002
#define IDC_CLEAR                       1003
#define IDC_DEL                         1003
#define IDC_EXIT                        1004
#define IDC_EDIT                        1005
#define IDC_HISTORY                     1006
#define IDC_ALIGN                       1007
#define IDC_TEXTCOLOR                   1008
#define IDC_BACKCOLOR                   1009
#define IDC_BUTTON4                     1010
#define IDC_PUT                         1010
#define IDC_GETTAGCOUNT                 1010
#define IDC_POST                        1011
#define IDC_PLACE                       1012
#define IDC_QUERY                       1014
#define IDC_ADD_HEADER                  1015
#define IDC_HEADER_CB                   1017
#define ID_ADD                          1018
#define IDC_HEADER                      1019
#define IDC_COMMAND                     1021
#define IDC_DATA                        1022
#define IDC_SEND_CUSTOM                 1023
#define IDC_PUT_CMD                     1024
#define IDC_DELETE_BTN                  1025
#define IDC_PUT_FROM_FILE               1026
#define IDC_ABOUT                       1027
#define IDC_PROXY                       1029
#define IDC_PROXY_ADDRESS               1030
#define IDC_PORT                        1031
#define IDC_RELEAM                      1033
#define IDC_USER_NAME                   1034
#define IDC_PASSWORD                    1035
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
