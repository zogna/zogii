
#ifndef __TEST_H__INCLUDED
#define __TEST_H__INCLUDED

#include "resource.h"

BOOL CALLBACK AboutProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DlgProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK AddHeaderBox(HWND, UINT, WPARAM, LPARAM);


#endif // __TEST_H__INCLUDED




