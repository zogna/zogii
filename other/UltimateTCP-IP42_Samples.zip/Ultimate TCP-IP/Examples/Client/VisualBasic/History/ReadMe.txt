********************************************************************
Dundas Software - History ActiveX Control 3.0 - Demo Application
********************************************************************


1)  General Information
2)  Features
2)  Compatibility - Visual Basic versions
3)  How to Use the Demo


********************************************************************

GENERAL INFORMATION

	The Ultimate TCP/IP History Control 3.0 is a versatile control 
that allows developers to output formatted text to the end-user on a 
line-by-line basis.  

********************************************************************

FEATURES
	
	- ability to set the background/foreground colors of 
	  each line of text.
	- optional logging of text to a log file.  
	- optional appendage of stamped lines to existing text.
	- control the number of lines of text to be displayed in the 
          control.
	
********************************************************************

COMPATIBILITY	

	This demo was written using Visual Basic 6. No VB 6 specific
functions were used.

********************************************************************

HOW TO USE THE DEMO

	1) Run the application and change the text colors to your liking.
	
	2) Utilize the tooltiptext for additional information.

