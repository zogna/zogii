//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IMAPClient.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_IMAPCLTYPE                  129
#define IDD_CONNECT                     130
#define IDD_MESSAGE                     131
#define IDD_CREATE_FOLDER_DIALOG        134
#define IDC_CONNECT_SERVER              1000
#define IDC_CONNECT_LOGIN               1001
#define IDC_CONNECT_PASSWORD            1002
#define IDC_MESSAGE_HEADERS             1003
#define IDC_MESSAGE_ATTACHMENT_LIST     1005
#define IDC_MESSAGE_SAVE_ATTACHMENT     1006
#define IDC_MESSAGE_BODY                1007
#define IDC_HEADER_LIST                 1008
#define IDC_FOLDER_NAME                 1009
#define IDM_FILE_CONNECT                32771
#define IDM_FILE_DISCONNECT             32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
