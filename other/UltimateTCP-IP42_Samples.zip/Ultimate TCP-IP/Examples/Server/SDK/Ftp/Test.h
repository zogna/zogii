
#ifndef __TEST_H__INCLUDED
#define __TEST_H__INCLUDED

#include "resource.h"

#define IDC_STATUS		110

BOOL CALLBACK AboutProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DlgProc(HWND, UINT, WPARAM, LPARAM);


#endif // __TEST_H__INCLUDED









