#ifndef __ACCESSCONTROL_DEMOHEADER
#define __ACCESSCONTROL_DEMOHEADER

#include <windows.h>

#include "stdutfx.h"	// standard ultimate TCP macros etc


#ifndef CUT_ACCESSCONTROL_BASE_CLASS
#define	CUT_ACCESSCONTROL_BASE_CLASS	MY_UT_ACCESS_CONTROL_CLASS_BASE
#define MYACCESS_CONTROL_HEADER		"MyAccessControl.h"
#endif


#endif
