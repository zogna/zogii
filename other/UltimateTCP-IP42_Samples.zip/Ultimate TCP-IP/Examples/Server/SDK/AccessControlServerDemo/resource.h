//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDD_DIALOG1                     101
#define IDD_ACCESS_CONTROL_CONFIG       102
#define IDD_ADD_IP_DLG                  103
#define IDI_ICON1                       104
#define IDD_ABOUT                       104
#define IDC_HISTORY                     1000
#define IDC_EXIT                        1001
#define IDC_START                       1002
#define IDC_CONTROL_ACCESS              1003
#define IDC_IP_LIST                     1006
#define IDC_BLOCKED                     1010
#define IDC_ALLOWED                     1011
#define IDC_TEMP_BLOCKED                1012
#define IDC_ADD                         1013
#define IDC_RANGE                       1016
#define IDC_REFRESH                     1017
#define IDC_END_STATIC                  1018
#define IDC_IPADDRESS1                  1023
#define IDC_IPADDRESS2                  1024
#define IDC_EDIT                        1025
#define IDC_DELETE                      1026
#define IDC_ABOUT                       1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
