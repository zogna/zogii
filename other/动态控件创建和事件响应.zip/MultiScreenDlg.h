// MultiScreenDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "ScreenPannel.h"
#include "ShortCutsDlg.h"

#define	CUR_SPLIT	SPLIT16
//����ָ�����
enum{
	SPLIT1 = 0,
	SPLIT4,
	SPLIT9,
	SPLIT16,	
	SPLIT_TOTAL
};


// CMultiScreenDlg dialog
class CMultiScreenDlg : public CDialog
{
// Construction
public:
	CMultiScreenDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MULTISCREEN_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

public:
	int					m_curScreen;		//��ǰ��ʾ�������
	CScreenPannel		m_screenPannel;		//������Ļ�װ壭�Ӵ���
	CShortCutsDlg		m_shortCuts;		//��ݲ˵���
	CRect				m_clientRect;		//�����������λ��
// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	void SwitchMultiWnd(int nSplit);
	afx_msg void OnOnePlaywin();
	afx_msg void OnFourPlaywin();
	afx_msg void OnNinePlaywin();
	afx_msg void OnSixtenPlaywin();
	afx_msg void UpdatePannelPosition();
	afx_msg void OnBnClickedBtnStart();
	CStatic m_videownd;
};
