// MultiScreenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MultiScreen.h"
#include "MultiScreenDlg.h"
#include "MessageText-eng.h"
#include"dhnetsdk.h"

#pragma comment( lib, "dhnetsdk.lib")

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


void __stdcall DisConnectFunc(LONG lLoginID, char *pchDVRIP, LONG nDVRPort, DWORD dwUser)
{
	printf("Device disconn, IP=%s+++++++++++++++++++++++\n", pchDVRIP);
}

void __stdcall HaveReConnectFunc(LONG lLoginID, char *pchDVRIP, LONG nDVRPort, DWORD dwUser)
{
	printf("Device connect, IP=%s-----------------------\n", pchDVRIP);
}

void __stdcall SubDisConnectFunc(EM_INTERFACE_TYPE emInterfaceType, BOOL bOnline, LONG lOperateHandle, LONG lLoginID, DWORD dwUser)
{
	switch(emInterfaceType)
	{
	case DH_INTERFACE_REALPLAY:
		printf("ʵʱ���ӽӿ�: Short connect is %d\n", bOnline);
		break;
	case DH_INTERFACE_PREVIEW:
		printf("�໭��Ԥ���ӿ�: Short connect is %d\n", bOnline);
		break;
	case DH_INTERFACE_PLAYBACK:
		printf("�طŽӿ�: Short connect is %d\n", bOnline);
		break;
	case DH_INTERFACE_DOWNLOAD:
		printf("���ؽӿ�: Short connect is %d\n", bOnline);
		break;
	default:
		break;
	}
}


void __stdcall RealDataCallBackEx(LONG lRealHandle, DWORD dwDataType, BYTE *pBuffer,DWORD dwBufSize, LONG lParam, DWORD dwUser)
{
	BOOL bInput=FALSE;
	if(0 != lRealHandle)
	{
		FILE *fp=fopen("dahua.txt","a+");
		if(fp)
		{
			fprintf(fp,"input data type: %d\n",dwDataType);
			fclose(fp);
		}
		//printf("input data type: %d\n", dwDataType);
		switch(dwDataType) {
		case 0:
			//ԭʼ����Ƶ�������
			break;
		case 1:
			//��׼��Ƶ����
			
			break;
		case 2:
			//yuv ����
			
			break;
		case 3:
			//pcm ��Ƶ����
			
			break;
		case 4:
			//ԭʼ��Ƶ����
			
			break;
		default:
			break;
		}	
	}
}

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CMultiScreenDlg dialog




CMultiScreenDlg::CMultiScreenDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMultiScreenDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMultiScreenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_VIDEO, m_videownd);
}

BEGIN_MESSAGE_MAP(CMultiScreenDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_ONE_PLAYWIN, &CMultiScreenDlg::OnOnePlaywin)
	ON_COMMAND(ID_FOUR_PLAYWIN, &CMultiScreenDlg::OnFourPlaywin)
	ON_COMMAND(ID_NINE_PLAYWIN, &CMultiScreenDlg::OnNinePlaywin)
	ON_COMMAND(ID_SIXTEN_PLAYWIN, &CMultiScreenDlg::OnSixtenPlaywin)
	ON_BN_CLICKED(IDC_BTN_START, &CMultiScreenDlg::OnBnClickedBtnStart)
END_MESSAGE_MAP()


// CMultiScreenDlg message handlers

BOOL CMultiScreenDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	UpdatePannelPosition();
	CLIENT_Init(DisConnectFunc, 0);
	CLIENT_SetSubconnCallBack(SubDisConnectFunc, 0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMultiScreenDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMultiScreenDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMultiScreenDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

int CMultiScreenDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	//���Ŵ���
	m_screenPannel.Create(
		NULL,
		NULL,
		WS_CHILD|WS_VISIBLE, 
		CRect(0,0,0,0), 
		this, 
		0xffff);
	m_shortCuts.Create(IDD_SHORTCUTS_DIALOG,this);

	m_screenPannel.ShowWindow(SW_SHOW);
	m_shortCuts.ShowWindow(SW_SHOW);
	m_screenPannel.SetShowPlayWin(CUR_SPLIT, m_curScreen);	
	return 0;
}

//���ڸı�ʱ�Ĵ���
void CMultiScreenDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);

	//������С���봰�ڴ�С�ޱ仯������
	if ((cx ==0 && cy == 0) || 
		(cx == m_clientRect.Width() && cy == m_clientRect.Height())) 
	{
		return;
	}
	else
	{
		UpdatePannelPosition();
		Invalidate();
	}
}

void CMultiScreenDlg::UpdatePannelPosition()
{
	GetClientRect(&m_clientRect);
	//��Ļ��
	CRect m_screenRect;			//���Ŵ��ڵ�λ��
	m_screenRect.top = m_clientRect.top;
	m_screenRect.bottom = m_clientRect.bottom-120;
	m_screenRect.left = m_clientRect.left+200;
	m_screenRect.right = m_clientRect.right-55;
	m_screenPannel.MoveWindow(m_screenRect);

	CRect m_shortCutsRect;			//���Ŵ��ڵ�λ��
	m_shortCutsRect.top = m_clientRect.top;
	m_shortCutsRect.bottom = m_clientRect.bottom;
	m_shortCutsRect.left = m_screenRect.right;
	m_shortCutsRect.right = m_clientRect.right;
	m_shortCuts.MoveWindow(m_shortCutsRect);
}

void CMultiScreenDlg::SwitchMultiWnd(int nSplit)
{
	if (SPLIT1 == nSplit)
	{
		m_screenPannel.SetMultiScreen(FALSE);
		return ;
	}
	else
	{
		m_screenPannel.SetMultiScreen(TRUE);
		m_screenPannel.SetShowPlayWin(nSplit, m_curScreen);
	}	
}

void CMultiScreenDlg::OnOnePlaywin()
{
	// TODO: Add your command handler code here
	SwitchMultiWnd(SPLIT1);
}

void CMultiScreenDlg::OnFourPlaywin()
{
	// TODO: Add your command handler code here
	SwitchMultiWnd(SPLIT4);
}

void CMultiScreenDlg::OnNinePlaywin()
{
	// TODO: Add your command handler code here
	SwitchMultiWnd(SPLIT9);
}

void CMultiScreenDlg::OnSixtenPlaywin()
{
	// TODO: Add your command handler code here
	SwitchMultiWnd(SPLIT16);
}

void CMultiScreenDlg::OnBnClickedBtnStart()
{
	// TODO: Add your control notification handler code here
	NET_DEVICEINFO stDevInfo = {0};
	int nError = 0;
	LLONG lLoginHandle = 0;
	LLONG lRealHandle = {0};
	int nPort = 37777;
	int nChannelID = 0; // Ԥ��ͨ����

	lLoginHandle = CLIENT_Login("183.250.26.136", nPort, "admin", "admin", &stDevInfo, &nError);

	if (lLoginHandle != 0)
	{
		CWnd* pWnd = m_screenPannel.GetPage(0);
		if (!pWnd)
		{
			return ;
		}
		lRealHandle = CLIENT_RealPlay(lLoginHandle, nChannelID, m_videownd.m_hWnd);
		if (lRealHandle == 0)
		{
			printf("CLIENT_RealPlay: failed!\n");
		}

		// ���ûص�������������
		CLIENT_SetRealDataCallBackEx(lRealHandle, RealDataCallBackEx, 0, 0x00000006);
	}
}
