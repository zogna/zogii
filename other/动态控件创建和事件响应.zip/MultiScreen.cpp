// MultiScreen.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "MultiScreen.h"
#include "MultiScreenDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMultiScreenApp

BEGIN_MESSAGE_MAP(CMultiScreenApp, CWinApp)
	ON_COMMAND(ID_HELP, &CWinApp::OnHelp)
END_MESSAGE_MAP()


// CMultiScreenApp construction

CMultiScreenApp::CMultiScreenApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CMultiScreenApp object

CMultiScreenApp theApp;


// CMultiScreenApp initialization

BOOL CMultiScreenApp::InitInstance()
{
	// InitCommonControlsEx() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// Set this to include all the common control classes you want to use
	// in your application.
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinApp::InitInstance();

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	CMultiScreenDlg dlg;
	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}


//��ȡ����·��
//���ļ��Ի���󣬵�ǰ·���ᷢ���仯��������Ҫ��ʼ���Ի����ʱ�򱣴�·��
TCHAR* g_GetIniPath(void)
{
	static TCHAR* pszIniPath = NULL;//��ָ�����׳�ʼ��,
	if( NULL == pszIniPath)
	{
		TCHAR szDirBuf[512] = {0};
		pszIniPath = new TCHAR[512];//���ͷž��ڴ�й¶
		memset(pszIniPath, 0, 512);
		GetCurrentDirectory(512, szDirBuf);
		sprintf(pszIniPath, "%s\\langchn.ini", szDirBuf);
	}
	return pszIniPath;
}

//��Ӣ���ַ�����ת��Ϊ����ǰ�������͵��ַ�����
CString ConvertString(CString strText)
{
	char *val = new char[200];
	CString strIniPath,strRet;

	memset(val,0,200);
	GetPrivateProfileString("String", strText, "", val, 200, g_GetIniPath());
	strRet = val;
	if(strRet.GetLength()==0)
	{
		//���ini�ļ��в����ڶ�Ӧ���ַ���������ΪĬ��ֵ��Ӣ�ģ�
		strRet=strText;
	}
	delete val;
	return strRet;
}

/*
 *	��Ͽ�����ת��
 */
void ConvertComboBox(CComboBox &stuComboBox)
{
	int nCount = stuComboBox.GetCount();
	if(nCount <= 0)
	{
		return;
	}
	CString* strText = new CString[nCount];
	int i;
	for( i = 0; i < nCount;i++)
	{
		stuComboBox.GetLBText(i, strText[i]);
		strText[i] = ConvertString(strText[i]);
	}
	stuComboBox.ResetContent();
	for(i = 0; i< nCount; i++)
	{
		stuComboBox.AddString(strText[i]);
	}
	delete []strText;
}

