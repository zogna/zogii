//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MultiScreen.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MULTISCREEN_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDR_MENU_SYSTEM                 130
#define IDD_SHORTCUTS_DIALOG            131
#define IDB_BMP_MODE1                   132
#define IDB_BMP_MODE1_DIS               134
#define IDB_BMP_MODE1_PUSH              135
#define IDB_BMP_MODE4                   136
#define IDB_BMP_MODE4_DIS               137
#define IDB_BMP_MODE4_PUSH              138
#define IDB_BMP_MODE9                   139
#define IDB_BMP_MODE9_DIS               140
#define IDB_BMP_MODE9_PUSH              141
#define IDB_BMP_MODE16                  142
#define IDB_BMP_MODE16_DIS              143
#define IDB_BMP_MODE16_PUSH             144
#define IDC_BUTTON_MODE1                1003
#define IDC_BUTTON_MODE4                1004
#define IDC_BTN_START                   1004
#define IDC_BUTTON_MODE9                1005
#define IDC_STATIC_VIDEO                1005
#define IDC_BUTTON_MODE16               1006
#define IDC_BUTTON_FULL                 1007
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_32780                        32780
#define ID_32781                        32781
#define ID_32782                        32782
#define ID_32783                        32783
#define ID_32784                        32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_32787                        32787
#define ID_32788                        32788
#define ID_32789                        32789
#define ID_32790                        32790
#define ID_32791                        32791
#define ID_32792                        32792
#define ID_32793                        32793
#define ID_ONE_PLAYWIN                  32794
#define ID_FOUR_PLAYWIN                 32795
#define ID_NINE_PLAYWIN                 32796
#define ID_SIXTEN_PLAYWIN               32797

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32798
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
