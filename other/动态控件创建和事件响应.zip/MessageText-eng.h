

#define MSG_DEMODLG_SPLITTYPE_1			"single"
#define MSG_DEMODLG_SPLITTYPE_4			"split-4"
#define MSG_DEMODLG_SPLITTYPE_9			"split-9"
#define MSG_DEMODLG_SPLITTYPE_16		"split-16"