#pragma once
#include "afxwin.h"


// CShortCutsDlg dialog

class CShortCutsDlg : public CDialog
{
	DECLARE_DYNAMIC(CShortCutsDlg)

public:
	CShortCutsDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CShortCutsDlg();

// Dialog Data
	enum { IDD = IDD_SHORTCUTS_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
public:
	CBitmapButton btnSingle;
	CBitmapButton btnSplit4;
	CBitmapButton btnSplit9;
	CBitmapButton btnSplit16;
	afx_msg void OnBnClickedButtonMode1();
	afx_msg void OnBnClickedButtonMode4();
	afx_msg void OnBnClickedButtonMode9();
	afx_msg void OnBnClickedButtonMode16();
	afx_msg void OnBnClickedButtonFull();
};
