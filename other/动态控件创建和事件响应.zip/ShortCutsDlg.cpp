// ShortCutsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MultiScreen.h"
#include "ShortCutsDlg.h"
#include "MultiScreenDlg.h"


// CShortCutsDlg dialog

IMPLEMENT_DYNAMIC(CShortCutsDlg, CDialog)

CShortCutsDlg::CShortCutsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CShortCutsDlg::IDD, pParent)
{

}

CShortCutsDlg::~CShortCutsDlg()
{
}

void CShortCutsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTON_MODE1, btnSingle);
	DDX_Control(pDX, IDC_BUTTON_MODE4, btnSplit4);
	DDX_Control(pDX, IDC_BUTTON_MODE9, btnSplit9);
	DDX_Control(pDX, IDC_BUTTON_MODE16, btnSplit16);
}


BEGIN_MESSAGE_MAP(CShortCutsDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_MODE1, &CShortCutsDlg::OnBnClickedButtonMode1)
	ON_BN_CLICKED(IDC_BUTTON_MODE4, &CShortCutsDlg::OnBnClickedButtonMode4)
	ON_BN_CLICKED(IDC_BUTTON_MODE9, &CShortCutsDlg::OnBnClickedButtonMode9)
	ON_BN_CLICKED(IDC_BUTTON_MODE16, &CShortCutsDlg::OnBnClickedButtonMode16)
	ON_BN_CLICKED(IDC_BUTTON_FULL, &CShortCutsDlg::OnBnClickedButtonFull)
END_MESSAGE_MAP()

BOOL CShortCutsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
	btnSingle.LoadBitmaps(IDB_BMP_MODE1,IDB_BMP_MODE1_PUSH,NULL,NULL);
	btnSingle.SizeToContent();		//����ӦͼƬ��С
	btnSplit4.LoadBitmaps(IDB_BMP_MODE4,IDB_BMP_MODE4_PUSH,NULL,NULL);
	btnSplit4.SizeToContent();
	btnSplit9.LoadBitmaps(IDB_BMP_MODE9,IDB_BMP_MODE9_PUSH,NULL,NULL);
	btnSplit9.SizeToContent();
	btnSplit16.LoadBitmaps(IDB_BMP_MODE16,IDB_BMP_MODE16_PUSH,NULL,NULL);
	btnSplit16.SizeToContent();
	return TRUE;  // return TRUE  unless you set the focus to a control
}


// CShortCutsDlg message handlers

void CShortCutsDlg::OnBnClickedButtonMode1()
{
	// TODO: Add your control notification handler code here
	((CMultiScreenDlg *)GetParent())->OnOnePlaywin();
}

void CShortCutsDlg::OnBnClickedButtonMode4()
{
	// TODO: Add your control notification handler code here
	((CMultiScreenDlg *)GetParent())->OnFourPlaywin();
}

void CShortCutsDlg::OnBnClickedButtonMode9()
{
	// TODO: Add your control notification handler code here
	((CMultiScreenDlg *)GetParent())->OnNinePlaywin();
}

void CShortCutsDlg::OnBnClickedButtonMode16()
{
	// TODO: Add your control notification handler code here
	((CMultiScreenDlg *)GetParent())->OnSixtenPlaywin();
}

void CShortCutsDlg::OnBnClickedButtonFull()
{
	// TODO: Add your control notification handler code here
}
